using Godot;
using System.Collections.Generic;

// ============================================================
// ExpeditionManager.cs
//
// Purpose:        Top-level controller for ONE bounded expedition
//                 onto the persistent world. Replaces the region-
//                 generation lifecycle of OverworldRunManager with
//                 the single-world model:
//                   DEPLOY  — build a radius-R window of WorldData
//                             around the chosen staging point.
//                   OPERATE — move / fight / negotiate inside the
//                             window; reveal tiles, which write
//                             straight back into Cycle.World.
//                   EXTRACT — voluntary or range-exhausted; bank
//                             discoveries + new staging points,
//                             save, return to the strategic view.
//                 The world is authoritative and resident in
//                 CycleState.World, so there is NO seed reproduction
//                 and NO fog save/restore — combat round-trips just
//                 rebuild the same window from the same world.
// Layer:          System
// Collaborators:  WorldWindowBuilder.cs (builds the window),
//                 OverworldHexGrid.cs (WindowMode container),
//                 OverworldPartyToken / FogOfWarManager /
//                 OverworldFactionManager (unchanged interaction),
//                 EncounterRouter.cs (combat resource round-trip),
//                 PlayerSession (staging point handoff),
//                 SaveManager.ActiveSave.Cycle.World (the world)
// See:            single_world_refactor_v2.docx §4.1, §6 (lifecycle)
// ============================================================

/// <summary>Controls one expedition: deploy a window from a staging point,
/// operate inside it, extract by writing discovery back to the persistent world.</summary>
public partial class ExpeditionManager : Node2D
{
    [Export] public int WindowRadius = 12;
    [Export] public int OperatingRange = 40;   // step budget for one sortie (crosses a window + probes onward)
    [Export] public int ExhaustionDamagePerStep = 10;

    // ── W1: sliding window (claude/expedition_window_sliding_v1) ─────────
    /// <summary>Debug A/B lever: true restores the old fixed-perimeter window
    /// (no sliding). Off by default — the wall is gone; range is governed by
    /// the step/HP economy plus the W3 supply leash below.</summary>
    [Export] public bool HardWindowMode = false;

    /// <summary>Hexes of party drift from the window center before the loaded
    /// window slides to follow. Small enough that the loaded edge always stays
    /// far beyond vision range; large enough that pacing doesn't thrash.</summary>
    [Export] public int RecenterThreshold = 3;

    // ── W3: soft leash — the supply line ──────────────────────────────────
    /// <summary>Hex distance from the nearest supply anchor (this expedition's
    /// staging tile, or any Available staging point — including outposts
    /// secured mid-run) within which no leash drain applies.</summary>
    [Export] public int SupplyRange = 12;

    /// <summary>Width in hexes of each leash band beyond SupplyRange.</summary>
    [Export] public int LeashBandWidth = 3;

    /// <summary>HP-pool drain per step, per band beyond supply. Deliberately
    /// NOT reducible by HazardWard/CorruptionWard (Q3) — the leash is its own
    /// attrition axis; the deferred §7b Provisioner family is its future
    /// mitigation. Wards reducing it would trivialize the leash exactly the
    /// way the hard wall trivialized Pathfinder.</summary>
    [Export] public int LeashDrainPerBand = 1;

    /// <summary>Maximum leash bands (drain caps at LeashBandCap × LeashDrainPerBand).</summary>
    [Export] public int LeashBandCap = 3;

    /// <summary>Grid-local coord the loaded window is currently centered on.</summary>
    private Vector2I _windowCenterLocal = Vector2I.Zero;

    /// <summary>Supply band after the last step (0 = in supply). Lets band
    /// crossings announce themselves once instead of every step.</summary>
    private int _lastSupplyBand = 0;

    /// <summary>Two-step confirm for emergency extraction (W3 ruling).</summary>
    private ConfirmationDialog _emergencyConfirm;

    // ── S2: overworld spellcasting (overworld_spell_system_v1_1) ─────────
    private OverworldSpellManager _spells;
    private GrimoirePanel _grimoirePanel;
    private Label _essenceLabel;

    // ── S3: Retrace memory (Chronomancer) — the last committed move, so the
    // sole G1 exception can undo it. Cleared when a scene swap makes the
    // "last step" ambiguous (combat/negotiation) and after use. ─────────────
    private Vector2I _lastMoveFrom;
    private int _lastMoveStepCost;
    private bool _hasLastMove = false;

    // ── Runtime resource state (rides EncounterRouter across combat) ─────
    public int StepsRemaining { get; set; }
    public int CurrentHP { get; set; }
    public int MaxHP { get; set; }

    /// <summary>Casualty summary from the most recent §5b wipe roll, consumed
    /// by FailExpedition's banner so the human cost is visible at the moment
    /// of failure (K2 UX).</summary>
    private string _casualtyNote;
    public int GoldEarned { get; set; }
    public int SplinterEarned { get; set; }
    public int EncountersWon { get; set; }
    public bool ExpeditionComplete { get; private set; }

    // ── World + window ──────────────────────────────────────────────────
    private WorldData _world;
    private WorldWindowBuilder _window;
    private int _stagingCol, _stagingRow;

    // ── Nodes ───────────────────────────────────────────────────────────
    private OverworldHexGrid _grid;
    private FogOfWarManager _fog;
    private OverworldPartyToken _party;
    private OverworldFactionManager _factionManager;
    private Camera2D _camera;
    private NarrativeEncounterPanel _narrativePanel;
    private ScoutReportPanel _scoutPanel;
    private LedgerPanel _ledgerPanel;
    private List<NarrativeEncounterData> _encounterPool;

    // ── Pending combat (scout panel) ────────────────────────────────────
    private Vector2I? _pendingCombatHexCoord = null;
    private EncounterDefinition _pendingEncounter = null;
    private string _pendingTerrain = null;
    private float _scaledDifficultyMult = 1.0f;
    private bool _ambushPending = false;
    private const int PatrolRecoverySteps = 8;
    private const int PatrolShakeSteps = 5;

    // ── UI ──────────────────────────────────────────────────────────────
    private Label _stepLabel, _hpLabel, _infoLabel, _windowLabel;
    private Button _extractButton, _returnButton, _ledgerButton;
    private bool _cameraFreeMode = false;
    private const float CameraPanSpeed = 400f;

    private const string StrategicScenePath = "res://Scenes/Overworld/StrategicScene.tscn";
    private Label _hoverTooltip;

    // ── Autosave throttle ───────────────────────────────────────────────
    // The cycle file holds the whole world array (~2MB+), so per-move saves
    // stutter. Autosave at most once per interval; checkpoints save directly.
    private const double AutosaveIntervalSec = 3.0;
    private double _lastAutosaveMsec = 0;

    [Signal] public delegate void ExpeditionEndedEventHandler(bool extracted);

    // ── Accessors for EncounterRouter ───────────────────────────────────
    public Vector2I GetPartyCoord() => _party.CurrentCoord;
    public OverworldHexGrid GetGrid() => _grid;

    public override void _Ready()
    {
        EnsureEncounterRouter();
        var router = EncounterRouter.Instance;

        // ── World comes from the resident cycle ──────────────────────────
        var cycle = SaveManager.ActiveSave?.Cycle;
        if (cycle == null)
        {
            GD.PrintErr("ExpeditionManager: no active cycle — cannot deploy.");
            return;
        }
        _world = cycle.World;

        // ── Staging point + radius from the deploy handoff ───────────────
        _stagingCol = PlayerSession.ExpeditionStagingCol;
        _stagingRow = PlayerSession.ExpeditionStagingRow;
        if (PlayerSession.ExpeditionWindowRadius > 0)
            WindowRadius = PlayerSession.ExpeditionWindowRadius;

        BuildEquipmentLoadouts();

        // ── Build the window grid (WindowMode = no self-generation) ──────
        _grid = new OverworldHexGrid { Name = "WindowGrid", WindowMode = true };
        AddChild(_grid);

        _window = new WorldWindowBuilder(_world, _stagingCol, _stagingRow, WindowRadius);

        // On a combat/negotiation return the party may be far outside the base
        // disc — build the initial window around where they'll actually be
        // placed, instead of 469 tiles at staging that the restore recenter
        // would immediately free. (Fresh deploys — and HardWindowMode, where
        // the party can never leave the base disc — build at staging.)
        bool pendingReturn = router != null && router.HasPendingReturn;
        Vector2I initialCenter = (pendingReturn && !HardWindowMode)
            ? GridLocalOf(router.SavedPartyCoord)
            : _window.PartyStartLocal;
        _window.Build(_grid, initialCenter);
        _windowCenterLocal = initialCenter;

        // Fog manager (child of grid, same as before)
        _fog = new FogOfWarManager { Name = "FogOfWar" };
        _grid.AddChild(_fog);

        // Faction patrols — keyed to the staging tile's kingdom, if any.
        _factionManager = new OverworldFactionManager { Name = "FactionManager" };
        _grid.AddChild(_factionManager);
        // Patrols key off the TEMPLATE REGION (the campaign's archmage map is
        // keyed by region names like 'dustreach', not 'kingdom_N' ids).
        _factionManager.Initialize(_grid, StagingTemplateRegion(), cycle.Campaign);
        _factionManager.PatrolCapturedPlayer += OnPatrolCapturedPlayer;

        // Party token
        _party = new OverworldPartyToken { Name = "PartyToken" };
        _grid.AddChild(_party);

        // Camera
        _camera = new Camera2D
        {
            Name = "ExpeditionCamera",
            Zoom = new Vector2(1.2f, 1.2f),
            PositionSmoothingEnabled = true,
            PositionSmoothingSpeed = 5f,
        };
        AddChild(_camera);
        _camera.CallDeferred("make_current");

        BuildHud();

        // ── Resource state ───────────────────────────────────────────────
        MaxHP = ComputePartyBaseHP();
        CurrentHP = MaxHP;
        StepsRemaining = OperatingRange;
        GoldEarned = 0;
        SplinterEarned = 0;
        EncountersWon = 0;
        ExpeditionComplete = false;

        PlayerSession.ClearRunState();
        var bonuses = BuildingEffectApplier.CalculateRunBonuses(SaveManager.ActiveSave);
        BuildingEffectApplier.ApplyCampusEffects(SaveManager.ActiveSave);
        MaxHP += bonuses.BonusHP;
        CurrentHP = MaxHP;
        StepsRemaining += bonuses.BonusSteps;
        GoldEarned += bonuses.BonusGold;

        PlayerSession.IsOnExpedition = true;
        if (PlayerSession.DebugMode && PlayerSession.StartWithGold)
            GoldEarned += 5000;
        if (PlayerSession.DebugMode && PlayerSession.StartWithSplinters)
            SplinterEarned += 5000;

        // ── Place party / restore from combat ────────────────────────────
        if (router != null && router.HasPendingReturn)
        {
            RestoreFromCombat(router);
        }
        else
        {
            // K2.5: fresh expedition — everyone starts whole. (Combat returns
            // take the other branch and must NOT reset carried HP.)
            CompanionInjurySystem.ResetExpeditionHP(SaveManager.ActiveSave);

            _party.Initialize(_grid, _fog, _window.PartyStartLocal);
            // Reveal-on-deploy: the staging tile and its vision write to World.
            WriteVisibleToWorld();
            ShowInfo("Expedition deployed. Explore the region; extract before your range runs out.");

            if (PlayerSession.DebugMode && PlayerSession.NoFog)
                RevealAllFog();
        }

        // ── S2: overworld spellcasting — manager + Grimoire panel ────────
        // Fresh deploys reset the Essence pool / cast counts / beacons;
        // combat and negotiation returns keep them (they ride the save).
        _spells = new OverworldSpellManager { Name = "SpellManager" };
        AddChild(_spells);
        _spells.Initialize(this, _grid, cycle.Grimoire, freshDeploy: !pendingReturn);
        _spells.ApplyAttunement(_party.CurrentCoord);
        WriteVisibleToWorld(); // attunement silhouettes chart immediately

        _grimoirePanel = new GrimoirePanel { Name = "GrimoirePanel" };
        GetHudCanvas().AddChild(_grimoirePanel);
        _grimoirePanel.Initialize(_spells);

        // Narrative panel + pool (keyed to the staging kingdom)
        _narrativePanel = new NarrativeEncounterPanel { Visible = false };
        GetHudCanvas().AddChild(_narrativePanel);

        // Favor ledger panel (C3): read-only ledger + the call-in action.
        _ledgerPanel = new LedgerPanel { Name = "LedgerPanel" };
        GetHudCanvas().AddChild(_ledgerPanel);
        _ledgerPanel.GetIneligibilityReason = CallInIneligibility;
        _ledgerPanel.OnCallIn = OnLedgerCallIn;
        _encounterPool = NarrativeEncounterLoader.LoadForRegion(StagingTemplateRegion());

        // Wire signals
        _grid.HexClicked += OnHexClicked;
        _grid.HexHovered += OnHexHovered;
        _grid.HexUnhovered += OnHexUnhovered;
        _party.PartyMoved += OnPartyMoved;
        _party.PartyArrived += OnPartyArrived;

        CenterCamera();
        UpdateUI();
    }

    // ════════════════════════════════════════════════════════════════════
    // Discovery write-back — the heart of the single-world model
    // ════════════════════════════════════════════════════════════════════

    /// <summary>Push every currently-revealed window tile into Cycle.World as
    /// Explored, and mark any revealed POIs discovered. Called after each move
    /// (and on deploy). Cheap: only flips tiles that changed. Marks the save
    /// dirty so the periodic SaveIfDirty flush persists it.</summary>
    private void WriteVisibleToWorld()
    {
        bool changed = false;

        foreach (var kvp in _grid.Hexes)
        {
            var local = kvp.Key;
            var hex = kvp.Value;

            // W4 (§5 keystone extension): silhouette = terrain-only knowledge =
            // Charted. As the sliding window travels, its vision fringe leaves a
            // persistent Charted corridor on the strategic map — the route
            // itself becomes a legible artifact of the expedition.
            if (hex.Fog == OverworldHex.FogState.Silhouette)
            {
                if (_window.TryLocalToWorld(local, out int scol, out int srow) &&
                    _world.TryIndex(scol, srow, out int sidx) &&
                    _world.Tiles[sidx].Discovery == TileDiscovery.Unseen)
                {
                    _world.Tiles[sidx].Discovery = TileDiscovery.Charted;
                    changed = true;
                }
                continue;
            }

            if (hex.Fog != OverworldHex.FogState.Revealed)
                continue;
            if (!_window.TryLocalToWorld(local, out int col, out int row))
                continue;

            // Tile discovery → Explored.
            if (_world.TryIndex(col, row, out int idx))
            {
                if (_world.Tiles[idx].Discovery != TileDiscovery.Explored)
                {
                    _world.Tiles[idx].Discovery = TileDiscovery.Explored;
                    changed = true;
                }
            }

            // POI discovery → discovered (shows on the strategic map).
            var poi = _world.PoiAt(col, row);
            if (poi != null && !poi.Discovered)
            {
                poi.Discovered = true;
                changed = true;

                // Settlements grant staging the moment they're DISCOVERED — a
                // friendly hub, no fight needed. (Outposts/seats still grant on
                // being secured, via OnPartyArrived/GrantStagingPointAt.)
                if (poi.Kind == PoiKind.Settlement && poi.GrantsStaging)
                    GrantStagingPointAt(local);
            }
        }

        if (changed)
            SaveManager.MarkDirty();
    }

    /// <summary>Flush a dirty save at most once per AutosaveIntervalSec. Keeps the
    /// large cycle file from being written every move. Real checkpoints (combat
    /// entry, outpost secured, extract) bypass this and save directly.</summary>
    private void ThrottledAutosave()
    {
        double now = Time.GetTicksMsec();
        if (now - _lastAutosaveMsec < AutosaveIntervalSec * 1000.0)
            return;
        _lastAutosaveMsec = now;
        SaveManager.SaveIfDirty();
    }

    /// <summary>Mark a world POI consumed (resolved) so it isn't re-offered.</summary>
    private void ConsumeWorldPoi(Vector2I local)
    {
        if (!_window.TryLocalToWorld(local, out int col, out int row))
            return;
        var poi = _world.PoiAt(col, row);
        if (poi != null && !poi.Consumed)
        {
            poi.Consumed = true;
            SaveManager.MarkDirty();
        }
    }

/// <summary>Securing a staging-granting POI adds a new launch point to the
    /// world. Called when such a POI is resolved.</summary>
    private void GrantStagingPointAt(Vector2I local)
    {
        if (!_window.TryLocalToWorld(local, out int col, out int row))
            return;
        GrantStagingPointAtWorld(col, row);
    }

    /// <summary>World-coordinate core of the staging grant, so remote reveals
    /// (Spymaster chart packets, court intelligence) can grant staging for
    /// settlements discovered outside the current window.</summary>
    private void GrantStagingPointAtWorld(int col, int row)
    {
        var poi = _world.PoiAt(col, row);
        if (poi == null || !poi.GrantsStaging)
            return;

        // Already a staging point? Skip.
        foreach (var sp in _world.StagingPoints)
            if (sp.X == col && sp.Y == row)
                return;

        string name = poi.Kind switch
        {
            PoiKind.Outpost => "Outpost",
            PoiKind.Settlement => "Settlement",
            PoiKind.Seat => "Secured Seat",
            _ => "Staging Point",
        };
        _world.StagingPoints.Add(new StagingPoint
        {
            X = col,
            Y = row,
            Name = name,
            Source = "Secured",
            Available = true,
        });
        if (_world.TryIndex(col, row, out int idx))
            _world.Tiles[idx].IsStagingPoint = true;

        SaveManager.MarkDirty();
        ShowInfo($"New staging point secured: {name}. Future expeditions can launch from here.");
    }

    // ════════════════════════════════════════════════════════════════════
    // Debug / dev-mode helpers
    // ════════════════════════════════════════════════════════════════════

    public override void _UnhandledInput(InputEvent @event)
    {
        if (!PlayerSession.DebugMode || ExpeditionComplete)
            return;

        // F: mint test favors for the kingdom under the party (C3 testing).
        if (@event is InputEventKey { Pressed: true, Keycode: Key.F })
        {
            string kid = KingdomIdAt(_party.CurrentCoord);
            if (string.IsNullOrEmpty(kid))
            {
                ShowInfo("[DEBUG] No kingdom here — cannot mint test favors.");
            }
            else
            {
                CouncilLedger.DebugMintTestFavors(SaveManager.ActiveSave.Cycle, kid);
                SaveManager.SaveIfDirty();
                ShowInfo($"[DEBUG] Test favors minted for '{kid}'.");
                _ledgerPanel?.RefreshRows();
            }
            GetViewport().SetInputAsHandled();
            return;
        }

        // E: dump echoes in flight (C4 verification).
        if (@event is InputEventKey { Pressed: true, Keycode: Key.E })
        {
            CouncilDebug.DumpEchoes();
            ShowInfo("[DEBUG] Echo flight dumped to Output.");
            GetViewport().SetInputAsHandled();
            return;
        }

        // R: dump court Regard for the kingdom underfoot (all courts in wilds).
        if (@event is InputEventKey { Pressed: true, Keycode: Key.R })
        {
            string rkid = KingdomIdAt(_party.CurrentCoord);
            CouncilDebug.DumpRegard(string.IsNullOrEmpty(rkid) ? null : rkid);
            ShowInfo("[DEBUG] Court Regard dumped to Output.");
            GetViewport().SetInputAsHandled();
            return;
        }

        // C: paint world corruption on the party tile + its six neighbours
        //    (Session C setup). C = 30 (minor band), Shift+C = 60 (major band),
        //    Ctrl+C = 0 (clear).
        if (@event is InputEventKey { Pressed: true, Keycode: Key.C } cKey)
        {
            byte value = cKey.CtrlPressed ? (byte)0 : (cKey.ShiftPressed ? (byte)60 : (byte)30);
            int painted = DebugPaintCorruption(_party.CurrentCoord, value);
            ShowInfo(painted > 0
                ? $"[DEBUG] Painted corruption {value} on {painted} tile(s)."
                : "[DEBUG] Could not paint corruption here.");
            GetViewport().SetInputAsHandled();
            return;
        }

        if (!PlayerSession.DebugGrantStagingArmed)
            return;          
        if (@event is InputEventKey { Pressed: true, Keycode: Key.G })
        {
            DebugGrantStagingHere();
            GetViewport().SetInputAsHandled();
        }
    }

    private void DebugGrantStagingHere()
    {
        var local = _party.CurrentCoord;
        if (!_window.TryLocalToWorld(local, out int col, out int row))
        {
            ShowInfo("[DEBUG] Can't resolve current tile to world.");
            return;
        }
        foreach (var sp in _world.StagingPoints)
            if (sp.X == col && sp.Y == row)
            { ShowInfo("[DEBUG] Already a staging point here."); return; }

        _world.StagingPoints.Add(new StagingPoint
        {
            X = col,
            Y = row,
            Name = "Debug Staging",
            Source = "Debug",
            Available = true,
        });
        if (_world.TryIndex(col, row, out int idx))
            _world.Tiles[idx].IsStagingPoint = true;

        string kid = _world.GetTile(col, row).KingdomId ?? "";
        SaveManager.MarkDirty();
        SaveManager.SaveIfDirty();
        ShowInfo($"[DEBUG] Staging granted at ({col},{row}), kingdom '{kid}'.");
        GD.Print($"[DEBUG] Granted staging at ({col},{row}), kingdom '{kid}'.");
    }

    /// <summary>Debug: set world corruption on the party's tile and its six
    /// neighbours (skipping water). Writes the same field EmitCombatDeed and
    /// CorruptionDrainAt read. Note: CorruptionSpread's flood only raises, so
    /// a Ctrl+C clear may be re-raised toward the kingdom's territory level at
    /// the next boundary. Returns the number of tiles painted.</summary>
    private int DebugPaintCorruption(Vector2I local, byte value)
    {
        if (!_window.TryLocalToWorld(local, out int col, out int row))
            return 0;

        int painted = 0;
        void Paint(int x, int y)
        {
            if (!_world.TryIndex(x, y, out int idx))
                return;
            if (_world.Tiles[idx].IsWater)
                return;
            _world.Tiles[idx].Corruption = value;
            painted++;
        }

        Paint(col, row);
        foreach (var (nx, ny) in HexCoord.Neighbors(col, row, _world.Width, _world.Height))
            Paint(nx, ny);

        if (painted > 0)
            SaveManager.MarkDirty();
        GD.Print($"[DEBUG] Corruption {value} painted on {painted} tile(s) around world ({col},{row}).");
        return painted;
    }

    // ════════════════════════════════════════════════════════════════════
    // Movement / POI handlers (lifted from OverworldRunManager, de-objectived)
    // ════════════════════════════════════════════════════════════════════

private void OnPartyMoved(Vector2I newCoord, Vector2I oldCoord)
    {
        // Border-cross feedback: name the territory being entered. Fired
        // first so hazard/corruption warnings on the same step overwrite it —
        // damage outranks geography.
        string fromKingdom = KingdomIdAt(oldCoord);
        string toKingdom = KingdomIdAt(newCoord);
        if (toKingdom != fromKingdom)
        {
            ShowInfo(string.IsNullOrEmpty(toKingdom)
                ? "You cross into unclaimed wilds."
                : $"You cross into the territory of {KingdomDisplayName(toKingdom)}.");
        }

        int stepCost = 1, hpDrain = 0;
        if (_grid.Hexes.TryGetValue(newCoord, out var hex))
        {
            hpDrain = GetTerrainHPDrain(hex.Terrain);
            // Q3 (§4b): HazardWard reduces terrain drain, floored at 1 whenever the
            // terrain drains at all — relief is bought, immunity does not exist.
            if (hpDrain > 0)
                hpDrain = Mathf.Max(1, hpDrain - EquipmentLoadout.PartyHazardWard());
            // Edge-aware step cost: destination terrain, cheapened by a road on the
            // traveled edge, surcharged by an unbridged river ford. Read the shared
            // edge off the tile we're leaving (masks live on both sides). Q3 (§7b):
            // Pathfinder cheapens the matching terrain (floor 1 inside StepCost).
            _grid.Hexes.TryGetValue(oldCoord, out var fromHex);
            stepCost = OverworldMovementCost.StepCost(hex.Terrain, fromHex, oldCoord, newCoord,
                EquipmentLoadout.PartyPathfinder(hex.Terrain.ToString()));
        }

        // S3 (Retrace): remember this move so it can be undone. Records the
        // cost actually charged (0 on the exhaustion path — HP is not refunded).
        _lastMoveFrom = oldCoord;
        _lastMoveStepCost = (!(PlayerSession.DebugMode && PlayerSession.UnlimitedSteps) &&
                             StepsRemaining > 0) ? Mathf.Min(StepsRemaining, stepCost) : 0;
        _hasLastMove = true;

        if (!(PlayerSession.DebugMode && PlayerSession.UnlimitedSteps))
        {
            if (StepsRemaining > 0)
                StepsRemaining = Mathf.Max(0, StepsRemaining - stepCost);
            else
            {
                // Range exhausted: each further step costs HP. Forced extraction
                // when HP would run out is handled below.
                CurrentHP -= ExhaustionDamagePerStep;
                if (CurrentHP <= 0)
                { CurrentHP = 0; FailExpedition("Stranded beyond your range."); return; }
            }

            // S2: an active warding spell (Ember Ward) negates the terrain's
            // bite entirely — bounded window, not immunity (G4).
            if (hpDrain > 0 && OverworldSpellEffects.DrainSuppressed(hex.Terrain))
            {
                GD.Print($"[Spellcraft] Ward negates {hpDrain} terrain drain on {hex.Terrain}.");
                hpDrain = 0;
            }

            if (hpDrain > 0)
            {
                CurrentHP -= hpDrain;
                ShowInfo($"Hazardous terrain! Lost {hpDrain} HP.");
                if (CurrentHP <= 0)
                { CurrentHP = 0; FailExpedition("Lost to the wilds."); return; }
            }

            // Corruption attrition: crossing corrupted ground bleeds you. Light at
            // the creeping edge, heavy in the convergence core — so the spreading
            // corruption is a hostile zone to route around, not stroll through.
            int corruptionDrain = CorruptionDrainAt(newCoord);
            // S2: Purifying Rite suppresses corruption attrition for its
            // window — bounded relief, never immunity (G4).
            if (corruptionDrain > 0 && OverworldSpellEffects.CorruptionSuppressed())
            {
                GD.Print($"[Spellcraft] Purifying Rite holds — {corruptionDrain} corruption drain suppressed.");
                corruptionDrain = 0;
            }
            if (corruptionDrain > 0)
            {
                // Q3 (§4b): CorruptionWard reduces the bleed, but Σ ward is CAPPED
                // at (tile corruption tier × 2) and drain never drops below 1 —
                // deep stacking is pointless past the tier you're actually walking.
                int tier = CorruptionTierAt(newCoord);
                int ward = Mathf.Min(EquipmentLoadout.PartyCorruptionWard(), tier * 2);
                corruptionDrain = Mathf.Max(1, corruptionDrain - ward);
                CurrentHP -= corruptionDrain;
                ShowInfo($"The corruption sears you! Lost {corruptionDrain} HP.");
                if (CurrentHP <= 0)
                { CurrentHP = 0; FailExpedition("Consumed by corruption."); return; }
            }

            // W3: the soft leash. Past supply range of the nearest anchor, each
            // step bleeds the pool — +1 HP per band of LeashBandWidth hexes,
            // capped. NOT ward-reducible (see the export's doc comment); the
            // supply line is priced in pool HP the wards can't buy back.
            int band = SupplyBandAt(newCoord);
            if (band != _lastSupplyBand)
            {
                if (band > 0 && _lastSupplyBand == 0)
                    ShowInfo("You pass beyond your supply line. Each step out here drains the party.");
                else if (band == 0 && _lastSupplyBand > 0)
                    ShowInfo("You are back within your supply line.");
                _lastSupplyBand = band;
            }
            if (band > 0)
            {
                int leashDrain = band * LeashDrainPerBand;
                CurrentHP -= leashDrain;
                ShowInfo($"Beyond your supply line ({(band > 1 ? $"band {band}" : "the fringe")}). Lost {leashDrain} HP.");
                if (CurrentHP <= 0)
                { CurrentHP = 0; FailExpedition("Lost beyond the supply line."); return; }
            }
        }

        // W1: slide the loaded window to follow the party once it drifts far
        // enough from the current center. Fires at move START (this handler),
        // so tiles stream in while the token animates across the hex.
        if (!HardWindowMode &&
            _grid.Distance(_party.CurrentCoord, _windowCenterLocal) >= RecenterThreshold)
            RecenterWindow(_party.CurrentCoord);

        // S2: spell-effect windows tick per committed step; Arcane Ground
        // feeds the pool (+1, §5 — a terrain property); the school Attunement
        // re-applies around the new position BEFORE the discovery write so
        // its silhouettes chart in the same pass.
        OverworldSpellEffects.TickStep();
        if (_spells != null)
        {
            if (hex != null && hex.Terrain == OverworldHex.TerrainType.ArcaneGround)
                _spells.AddEssence(1, "Arcane Ground");
            _spells.ApplyAttunement(_party.CurrentCoord);
        }

        // Reveal-on-move writes straight into World.
        WriteVisibleToWorld();

        // Patrols tick once per step.
        if (_factionManager != null && !ExpeditionComplete)
            _factionManager.Tick(_party.CurrentCoord);

        // Durability flush — THROTTLED. The cycle file is large (the whole world
        // array), so saving every move stutters. Autosave at most once every few
        // seconds; real checkpoints (combat entry, outpost, extract) save directly.
        ThrottledAutosave();

        // Range warning + auto-extract offer.
        if (StepsRemaining == 0 && !ExpeditionComplete)
            ShowInfo("Operating range spent. Extract now, or press on at the cost of HP.");

        CenterCamera();
        UpdateUI();
    }

    private void OnHexClicked(Vector2I axial)
    {
        if (ExpeditionComplete)
            return;
        // S2: an active spell-targeting session consumes grid clicks first.
        if (_spells != null && _spells.HandleHexClicked(axial))
            return;
        _party.TryMoveTo(axial);
    }
    private Vector2I? _hoveredCoord = null;

    private void OnHexHovered(Vector2I axial)
    {
        _hoveredCoord = axial;
        if (_hoverTooltip == null || !_grid.Hexes.TryGetValue(axial, out var hex))
            return;

        // Fog gate: don't reveal terrain the player hasn't explored.
        if (hex.Fog != OverworldHex.FogState.Revealed)
        {
            _hoverTooltip.Text = hex.Fog == OverworldHex.FogState.Silhouette
                ? "Charted — unexplored" + (_spells?.TooltipSilhouetteExtra(hex) ?? "")
                : "Unexplored";
        }
        else
        {
            string line = TerrainDisplayName(hex.Terrain);
            if (hex.POI != OverworldHex.POIType.None && !hex.POIConsumed)
                line += $"  ·  {hex.POI}{_spells?.TooltipPoiExtra(hex) ?? ""}";
            // Corruption readout if the underlying world tile is corrupted.
            if (_window.TryLocalToWorld(axial, out int col, out int row) &&
                _world.TryIndex(col, row, out int idx) && _world.Tiles[idx].Corruption >= 20)
                line += $"  ·  corrupted ({_world.Tiles[idx].Corruption})";
            _hoverTooltip.Text = line;
        }

        _hoverTooltip.Visible = true;
        PositionTooltip();
    }

    private void OnHexUnhovered(Vector2I axial)
    {
        // Only clear if we're leaving the tile we're actually showing (enter/exit
        // can interleave as the mouse crosses a shared edge).
        if (_hoveredCoord == axial)
        {
            _hoveredCoord = null;
            if (_hoverTooltip != null)
                _hoverTooltip.Visible = false;
        }
    }

    private void PositionTooltip()
    {
        if (_hoverTooltip == null || _grid == null)
            return;

        // Resolve the tile under the cursor from the mouse position, every frame.
        // (Area2D MouseEntered/Exited is unreliable here; InputEvent gives no exit
        // event — so we poll, which also fixes "tooltip won't hide off-grid".)
        Vector2 mouseWorld = _grid.GetGlobalMousePosition();
        Vector2I axial = _grid.WorldToAxial(_grid.ToLocal(mouseWorld));

        if (!_grid.Hexes.TryGetValue(axial, out var hex))
        {
            _hoverTooltip.Visible = false;
            return;
        }

        // Fog gate: don't reveal terrain the player hasn't explored.
        if (hex.Fog != OverworldHex.FogState.Revealed)
        {
            _hoverTooltip.Text = hex.Fog == OverworldHex.FogState.Silhouette
                ? "Charted — unexplored" + (_spells?.TooltipSilhouetteExtra(hex) ?? "")
                : "Unexplored";
        }
        else
        {
            string line = TerrainDisplayName(hex.Terrain);
            if (hex.POI != OverworldHex.POIType.None && !hex.POIConsumed)
                line += $"  ·  {hex.POI}{_spells?.TooltipPoiExtra(hex) ?? ""}";
            if (_window.TryLocalToWorld(axial, out int col, out int row) &&
                _world.TryIndex(col, row, out int idx) && _world.Tiles[idx].Corruption >= 20)
                line += $"  ·  corrupted ({_world.Tiles[idx].Corruption})";
            _hoverTooltip.Text = line;
        }

        _hoverTooltip.Visible = true;
        _hoverTooltip.Position = _hudCanvas.GetViewport().GetMousePosition() + new Vector2(16, 12);
    }

    private void OnPartyArrived(Vector2I coord)
    {
        if (ExpeditionComplete || _ambushPending)
            return;
        if (!_grid.Hexes.TryGetValue(coord, out var hex))
            return;

        // S3 (Deploy Waystation): standing on a deployed waystation consumes
        // its one rest charge — quarter-heal + 3 Essence, then it breaks down
        // (marker removed; it stops being a supply anchor).
        if (_window.TryLocalToWorld(coord, out int wcol, out int wrow))
        {
            var grimWs = SaveManager.ActiveSave?.Cycle?.Grimoire;
            string wsMark = $"{wcol},{wrow}";
            if (grimWs != null && grimWs.ActiveWaystations.Remove(wsMark))
            {
                int wsHeal = MaxHP / 4;
                CurrentHP = Mathf.Min(CurrentHP + wsHeal, MaxHP);
                _spells?.AddEssence(3, "Waystation");
                _grid.GetNodeOrNull($"WaystationMarker_{wcol}_{wrow}")?.QueueFree();
                SaveManager.MarkDirty();
                ShowInfo($"The waystation serves its purpose and breaks down. Recovered {wsHeal} HP.");
                UpdateUI();
            }
        }

        if (hex.POI == OverworldHex.POIType.None || hex.POIConsumed)
            return;

        var poiType = hex.POI;
        if (PlayerSession.DebugMode && PlayerSession.ForceNextEncounterType >= 0)
        {
            poiType = (OverworldHex.POIType)PlayerSession.ForceNextEncounterType;
            PlayerSession.ForceNextEncounterType = -1;
        }

        switch (poiType)
        {
            case OverworldHex.POIType.Combat:
                OpenScoutReport(coord, hex);
                break;

            case OverworldHex.POIType.Rest:
                int heal = MaxHP / 4;
                // S2: Campward (§8) — the armed charge makes this Rest heal
                // +50% and grant +2 extra Essence, then is consumed.
                bool campward = OverworldSpellEffects.ConsumeCampward();
                if (campward)
                    heal += MaxHP / 8;
                CurrentHP = Mathf.Min(CurrentHP + heal, MaxHP);
                _spells?.AddEssence(3 + (campward ? 2 : 0), campward ? "Rest + Campward" : "Rest");
                hex.POIConsumed = true;
                hex.RefreshVisuals();
                ConsumeWorldPoi(coord);
                int restSpl = SplinterDropTable.RestSite();
                SplinterEarned += restSpl;
                GoldEarned += 15;
                ShowInfo($"Rest site{(campward ? " (Campward)" : "")}. Recovered {heal} HP. " +
                         $"+{restSpl} Arcane Splinters.");
                UpdateUI();
                break;

            case OverworldHex.POIType.Narrative:
                TriggerNarrativeEncounter(hex, coord);
                break;

            case OverworldHex.POIType.Negotiation:
                TriggerNegotiationEncounter(hex, coord);
                break;

            case OverworldHex.POIType.Prison:
                // Imprisonment rescue (§8): storming the gaol is a combat. Winning
                // releases the captive — handled on combat return in
                // RestoreFromCombat via ReleaseImprisonedAt(resultHex). Routes
                // through the ordinary scout->commit path so difficulty scaling and
                // patrol attribution behave normally.
                OpenScoutReport(coord, hex);
                break;

            case OverworldHex.POIType.Outpost:
                // Full-heal checkpoint + grants a staging point (world-scale reward).
                CurrentHP = MaxHP;
                _spells?.RestoreEssenceFull(); // S2: Outpost = full Essence (§5)
                hex.POIConsumed = true;
                hex.RefreshVisuals();
                ConsumeWorldPoi(coord);
                GrantStagingPointAt(coord);
                int outSpl = SplinterDropTable.RestSite();
                SplinterEarned += outSpl;
                GoldEarned += 25;
                SaveManager.SaveIfDirty(); // checkpoint
                ShowInfo($"Outpost secured. Fully rested. +{outSpl} Arcane Splinters.");
                UpdateUI();
                break;
        }
    }

    // ════════════════════════════════════════════════════════════════════
    // Combat routing (verbatim from OverworldRunManager, world-sourced)
    // ════════════════════════════════════════════════════════════════════

    private void OpenScoutReport(Vector2I coord, OverworldHex hex)
    {
        string terrainType = hex.Terrain.ToString();
        string regionId = StagingTemplateRegion();
        var tier = EncounterTier.Battle;
        var arch = RollArchmageAt(coord);   // resident archmage rolls for its own forces
        if (PlayerSession.DebugMode)
            GD.Print($"[ArchmageEncounter] POI tile kingdom-archmage='{KingdomArchmageAt(coord)}', " +
                     $"draw={(arch != null ? arch.Id : "(region pool)")}");

        // 2c: archmage groups own their authored difficulty (mult 1.0). Region-tier
        // scaling applies only to the generic region-pool fallback.
        // SEAM: a future corrupted-archmage variant would swap `arch` here based on
        // the tile's corruption level before the draw — same call shape, different def.
        _scaledDifficultyMult = DifficultyMultAt(coord);
        var encounterDef =
            (arch != null
                ? EncounterPoolLoader.PickFromArchmage(arch, regionId, tier, terrainType, 1.0f)
                : null)
            ?? EncounterPoolLoader.Pick(regionId, tier, terrainType, _scaledDifficultyMult);
        _pendingCombatHexCoord = coord;
        _pendingEncounter = encounterDef;
        _pendingTerrain = terrainType;

        _scoutPanel.OnEngage = () =>
        {
            if (_pendingCombatHexCoord.HasValue && _pendingEncounter != null)
                CommitCombat(_pendingCombatHexCoord.Value, _pendingEncounter, _pendingTerrain);
            _pendingCombatHexCoord = null;
            _pendingEncounter = null;
            _pendingTerrain = null;
        };
        _scoutPanel.OnRetreat = () =>
        {
            ShowInfo("You fall back. The encounter remains.");
            _pendingCombatHexCoord = null;
            _pendingEncounter = null;
            _pendingTerrain = null;
        };

        int stepCost = GetTerrainStepCost(hex.Terrain);
        _scoutPanel.Show(encounterDef, hex.Terrain.ToString(), stepCost);
    }

    private void CommitCombat(Vector2I hexCoord, EncounterDefinition encounterDef, string terrainType)
    {
        var router = EncounterRouter.Instance;
        if (router == null)
        { GD.PrintErr("ExpeditionManager: EncounterRouter missing."); return; }

        // S3 (Retrace): a scene swap makes "the last step" ambiguous — forget it.
        _hasLastMove = false;

        // Save only the RESOURCE state — the world (and thus the map) is resident.
        router.SavedStepsRemaining = StepsRemaining;
        router.SavedCurrentHP = CurrentHP;
        router.SavedGoldEarned = GoldEarned;
        router.SavedSplinterEarned = SplinterEarned;
        router.SavedEncountersWon = EncountersWon;
        router.SavedPartyCoord = _party.CurrentCoord;
        router.SavedCombatHexCoord = hexCoord;
        router.HasPendingReturn = false;
        // Reset ambush attribution — OnPatrolCapturedPlayer re-marks it AFTER
        // this call for genuine patrol fights. Without this reset, the flag
        // from a previous ambush survives on the scene-persistent router and
        // every later ordinary win re-emits patrol_slain.
        router.SavedCombatWasPatrolAmbush = false;
        router.SavedCombatPatrolArchmageId = "";

        if (_factionManager != null)
        {
            router.SavedPatrolPositions = _factionManager.GetPatrolPositions();
            router.SavedPatrolCooldowns = _factionManager.GetPatrolCooldowns();
            router.SavedPatrolArchmageId = _factionManager.GetArchmageId();
        }

        // Persist discovery so far before leaving the scene.
        SaveManager.SaveIfDirty();

        // Vista world-adjacency (combat_environments §5): capture what surrounds
        // this fight on the overworld, per hex direction. HexCoord.AxialDirections
        // matches the combat grid's HexDirs order 1:1, so index k here becomes
        // vista side k in HexGridManager.VistaTerrainBias directly.
        string[] neighborTerrains = null;
        if (_grid != null)
        {
            neighborTerrains = new string[6];
            var (q, r) = HexCoord.OffsetToAxial(hexCoord.X, hexCoord.Y);
            for (int k = 0; k < HexCoord.AxialDirections.Length; k++)
            {
                var (dq, dr) = HexCoord.AxialDirections[k];
                var (nc, nr) = HexCoord.AxialToOffset(q + dq, r + dr);
                if (_grid.Hexes.TryGetValue(new Vector2I(nc, nr), out var nHex))
                    neighborTerrains[k] = nHex.Terrain.ToString();
            }
        }

        EncounterContextCarrier.Set(encounterDef);
        EncounterContextCarrier.SetContext(terrainType, encounterDef.Tier, neighborTerrains);
        router.SetCurrentTier(encounterDef.Tier);

        ShowInfo("Entering combat...");
        GetTree().ChangeSceneToFile(router.CombatScenePath);
    }

    private void OnPatrolCapturedPlayer(Vector2I coord, string archmageId)
    {
        if (ExpeditionComplete || _ambushPending)
            return;
        if (!_grid.Hexes.TryGetValue(coord, out var hex))
            return;

        // S3 (Parley Compulsion, Enchanter): an armed compulsion converts this
        // interception into a negotiation instead of an ambush. Once per
        // expedition (the cast carries the cap); the outcome writes stance and
        // echoes exactly as any negotiation.
        var grim = SaveManager.ActiveSave?.Cycle?.Grimoire;
        if (grim != null && grim.ParleyArmed)
        {
            grim.ParleyArmed = false;
            SaveManager.MarkDirty();
            ShowInfo("The compulsion takes hold — the patrol will talk instead of fight.");
            TriggerPatrolNegotiation(hex, coord);
            return;
        }

        _ambushPending = true;
        ShowInfo("A patrol has intercepted you!");
        string regionId = StagingTemplateRegion();
        string terrainType = hex.Terrain.ToString();
        // The patrol BELONGS to this archmage (passed by the signal) — its forces
        // are always the archmage's own, NO chance roll. Region pool only backstops
        // an archmage that has no authored skirmish group.
        var arch = ArchmageDefById(archmageId);
        if (PlayerSession.DebugMode)
            GD.Print($"[ArchmageEncounter] patrol archmageId='{archmageId}', " +
                     $"draw={(arch != null ? arch.Id : "(region pool)")}");

        _scaledDifficultyMult = DifficultyMultAt(coord);
        var encounterDef =
            (arch != null
                ? EncounterPoolLoader.PickFromArchmage(arch, regionId, EncounterTier.Skirmish, terrainType, 1.0f)
                : null)
            ?? EncounterPoolLoader.Pick(regionId, EncounterTier.Skirmish, terrainType, _scaledDifficultyMult);
        CommitCombat(coord, encounterDef, terrainType);
        // Mark AFTER CommitCombat (which resets the flag): this combat is a
        // patrol ambush, and whose soldiers they are (C4 deed emission).
        EncounterRouter.Instance.SavedCombatWasPatrolAmbush = true;
        EncounterRouter.Instance.SavedCombatPatrolArchmageId = archmageId;
    }

    // ════════════════════════════════════════════════════════════════════
    // Combat return — rebuild the SAME window; no seed/fog replay
    // ════════════════════════════════════════════════════════════════════

    private void RestoreFromCombat(EncounterRouter router)
    {
        StepsRemaining = router.SavedStepsRemaining;
        // K1 clamp (2026-07-09): MaxHP was recomputed in _Ready from the LIVE
        // roster — a companion permadying in the combat we're returning from
        // shrinks the pool, and the saved HP must not exceed the new ceiling.
        CurrentHP = Mathf.Min(router.SavedCurrentHP, MaxHP);
        GoldEarned = router.SavedGoldEarned;
        SplinterEarned = router.SavedSplinterEarned;
        EncountersWon = router.SavedEncountersWon;

        // The window was rebuilt fresh in _Ready from World; discovery is already
        // correct (it lives in World). W1: _Ready already built the initial disc
        // around this saved coord (return-aware Build) — this recenter is a
        // cheap idempotent safety net (adds/frees 0 tiles when Build did its
        // job) that also guarantees the tile exists before party placement.
        var savedLocal = GridLocalOf(router.SavedPartyCoord);
        if (!HardWindowMode)
            RecenterWindow(savedLocal);
        _party.Initialize(_grid, _fog, savedLocal);
        _lastSupplyBand = SupplyBandAt(savedLocal);
        WriteVisibleToWorld();

        var resultHex = router.SavedCombatHexCoord;

        if (NegotiationContext.HasResult)
        {
            OnNegotiationReturned(resultHex);
        }
        else if (router.CombatWon)
        {
            GoldEarned += router.GoldReward;
            SplinterEarned += router.SplinterReward;
            EncountersWon++;
            if (_grid.Hexes.TryGetValue(resultHex, out var hex))
            { hex.POIConsumed = true; hex.RefreshVisuals(); }
            ConsumeWorldPoi(resultHex);
            GrantStagingPointAt(resultHex); // securing a seat/settlement via combat can grant staging
            ShowInfo($"Victory! +{router.GoldReward} gold, +{router.SplinterReward} Splinters.");
            EmitCombatDeed(router, resultHex);
            ReleaseImprisonedAt(resultHex); // if this was a prison, free the captive

            // S3 (Deathsight, Necromancer): every won combat leaves a Remnant
            // for the rest of the expedition — Bone Scout / Speak with the
            // Fallen cast from these. Recorded school-agnostically (cheap);
            // markers draw only when a necromancer can use them.
            if (_window.TryLocalToWorld(resultHex, out int rcol, out int rrow))
            {
                var grimR = SaveManager.ActiveSave?.Cycle?.Grimoire;
                string mark = $"{rcol},{rrow}";
                if (grimR != null && !grimR.ActiveRemnants.Contains(mark))
                {
                    grimR.ActiveRemnants.Add(mark);
                    SaveManager.MarkDirty();
                }
            }
        }
        else
        {
            // K2 (§5b): a LOST combat downs the whole fielded party (defeat
            // requires allPlayersDead in CheckCombatEnd) — one roll each at the
            // combat hex's territory tier; boss encounters roll at 40%.
            _casualtyNote = CompanionInjurySystem.ApplyWipe(SaveManager.ActiveSave,
                TerritoryTierAt(resultHex),
                bossContext: router.CurrentTier == EncounterTier.Boss,
                "defeated in combat");

            if (_grid.Hexes.TryGetValue(resultHex, out var hex))
            { hex.POIConsumed = true; hex.RefreshVisuals(); }
            ConsumeWorldPoi(resultHex);

            // RULED (2026-07-09): defeat ENDS the expedition. The old path
            // subtracted router.DamageTaken (which arrived as 0) and carried on
            // — a fully dead party "respawned" at full pool. A party that lost
            // everyone does not keep exploring. GodModeHP (debug) is the only
            // escape: the run survives at 1 HP.
            if (PlayerSession.DebugMode && PlayerSession.GodModeHP)
            {
                CurrentHP = Mathf.Max(1, CurrentHP - router.DamageTaken);
                ShowInfo("Defeated... (GodMode: the expedition staggers on.)");
            }
            else
            {
                CurrentHP = 0;
                FailExpedition("Your party was defeated in the field.", injuriesAlreadyRolled: true);
                return;
            }
        }

        router.HasPendingReturn = false;

        if (_factionManager != null && router.SavedPatrolPositions.Count > 0)
        {
            _factionManager.RestorePatrolPositions(router.SavedPatrolPositions);
            _factionManager.RestorePatrolCooldowns(router.SavedPatrolCooldowns);
            _factionManager.DisengagePatrolsAt(router.SavedCombatHexCoord,
                router.CombatWon ? PatrolRecoverySteps : PatrolShakeSteps);
            router.SavedPatrolPositions.Clear();
            router.SavedPatrolCooldowns.Clear();
        }

        SaveManager.SaveIfDirty();
    }

    // ════════════════════════════════════════════════════════════════════
    // Narrative / Negotiation (lifted; world-sourced ids)
    // ════════════════════════════════════════════════════════════════════

    private void TriggerNarrativeEncounter(OverworldHex hex, Vector2I coord)
    {
        string terrainName = hex.Terrain.ToString();
        var completedIds = SaveManager.ActiveSave?.CompletedEvents;
        var encounter = NarrativeEncounterLoader.PickRandom(_encounterPool, terrainName, completedIds);

        hex.POIConsumed = true;
        hex.RefreshVisuals();
        ConsumeWorldPoi(coord);

        if (encounter == null)
        {
            int gold = 15 + (int)(GD.Randf() * 20);
            GoldEarned += gold;
            ShowInfo($"You find something of value here. (+{gold} gold)");
            UpdateUI();
            return;
        }
        _narrativePanel.ShowEncounter(encounter);
        _narrativePanel.OnCompleted = (choice) => OnNarrativeCompleted(encounter, choice);
    }

    private void OnNarrativeCompleted(NarrativeEncounterData encounter, EncounterChoice choice)
    {
        if (choice == null)
            return;
        if (choice.GoldDelta != 0)
            GoldEarned = Mathf.Max(0, GoldEarned + choice.GoldDelta);
        if (choice.HPDelta != 0)
        {
            CurrentHP = Mathf.Clamp(CurrentHP + choice.HPDelta, 0, MaxHP);
            if (PlayerSession.DebugMode && PlayerSession.GodModeHP)
                CurrentHP = Mathf.Max(1, CurrentHP);
            if (CurrentHP <= 0)
            { FailExpedition("Lost to a fateful choice."); return; }
        }
        if (choice.StepDelta != 0)
            StepsRemaining = Mathf.Max(0, StepsRemaining + choice.StepDelta);

        int spl = SplinterDropTable.Narrative();
        SplinterEarned += spl;

        if (SaveManager.ActiveSave != null && !string.IsNullOrEmpty(encounter.Id))
            if (!SaveManager.ActiveSave.CompletedEvents.Contains(encounter.Id))
                SaveManager.ActiveSave.CompletedEvents.Add(encounter.Id);

        if (choice.SetFlags != null && SaveManager.ActiveSave != null)
            foreach (var flag in choice.SetFlags)
                if (!SaveManager.ActiveSave.CompletedEvents.Contains(flag))
                    SaveManager.ActiveSave.CompletedEvents.Add(flag);

        ShowInfo($"Encounter resolved. +{spl} Arcane Splinters.");
        UpdateUI();
    }

    /// <summary>S3 (Parley Compulsion): a patrol interception converted into a
    /// negotiation. Same setup as a Negotiation POI, minus POI consumption —
    /// the patrol's hex owns no POI. The patrol itself disengages via the
    /// standard post-negotiation restore path.</summary>
    private void TriggerPatrolNegotiation(OverworldHex hex, Vector2I coord)
    {
        string kingdomId = StagingTemplateRegion();
        string terrain = hex.Terrain.ToString();
        var encounter = NegotiationEncounterLoader.PickForTerrain(terrain, kingdomId);
        if (encounter == null)
        { ShowInfo("The patrol shakes off the compulsion — nothing to say."); UpdateUI(); return; }

        NegotiationContext.Clear();
        NegotiationContext.EncounterId = encounter.Id;
        NegotiationContext.HexCoordKey = $"{coord.X},{coord.Y}";
        NegotiationContext.NpcArchetype = encounter.Archetype.ToString();
        NegotiationContext.OriginKingdomId = KingdomIdAt(coord);
        ConsumeBeguileIfArmed();

        var router = EncounterRouter.Instance;
        if (router != null)
        {
            router.SavedStepsRemaining = StepsRemaining;
            router.SavedCurrentHP = CurrentHP;
            router.SavedGoldEarned = GoldEarned;
            router.SavedSplinterEarned = SplinterEarned;
            router.SavedEncountersWon = EncountersWon;
            router.SavedPartyCoord = _party.CurrentCoord;
            router.SavedCombatHexCoord = coord;
            router.SavedCombatWasPatrolAmbush = false;
            router.SavedCombatPatrolArchmageId = "";
            router.HasPendingReturn = true;
            if (_factionManager != null)
            {
                router.SavedPatrolPositions = _factionManager.GetPatrolPositions();
                router.SavedPatrolCooldowns = _factionManager.GetPatrolCooldowns();
                router.SavedPatrolArchmageId = _factionManager.GetArchmageId();
            }
        }
        _hasLastMove = false; // S3 (Retrace): scene swap forgets the last step
        SaveManager.SaveIfDirty();
        ShowInfo($"Negotiation: {encounter.Title}");
        GetTree().ChangeSceneToFile("res://Scenes/Negotiation/NegotiationScene.tscn");
    }

    /// <summary>S3 (Beguile): consume an armed charm into the tension shift
    /// the negotiation layer applies on open. One band ≈ 2 tension.</summary>
    private void ConsumeBeguileIfArmed()
    {
        var grim = SaveManager.ActiveSave?.Cycle?.Grimoire;
        if (grim == null || !grim.BeguileArmed)
            return;
        grim.BeguileArmed = false;
        NegotiationContext.TensionShift = 2;
        SaveManager.MarkDirty();
        GD.Print("[Spellcraft] Beguile takes effect — the table opens a band more favorable.");
    }

    private void TriggerNegotiationEncounter(OverworldHex hex, Vector2I coord)
    {
        hex.POIConsumed = true;
        hex.RefreshVisuals();
        ConsumeWorldPoi(coord);

        string kingdomId = StagingTemplateRegion();
        string terrain = hex.Terrain.ToString();
        var encounter = NegotiationEncounterLoader.PickForTerrain(terrain, kingdomId);
        if (encounter == null)
        { ShowInfo("A potential contact slips away."); UpdateUI(); return; }

        NegotiationContext.Clear();
        NegotiationContext.EncounterId = encounter.Id;
        NegotiationContext.HexCoordKey = $"{coord.X},{coord.Y}";
        NegotiationContext.NpcArchetype = encounter.Archetype.ToString();
        // Kingdom of the tile we're standing on — drives court-standing
        // starting tension and the deal-deed echo route. "" for wilds.
        NegotiationContext.OriginKingdomId = KingdomIdAt(coord);
        ConsumeBeguileIfArmed(); // S3

        var router = EncounterRouter.Instance;
        if (router != null)
        {
            router.SavedStepsRemaining = StepsRemaining;
            router.SavedCurrentHP = CurrentHP;
            router.SavedGoldEarned = GoldEarned;
            router.SavedSplinterEarned = SplinterEarned;
            router.SavedEncountersWon = EncountersWon;
            router.SavedPartyCoord = _party.CurrentCoord;
            router.SavedCombatHexCoord = coord;
            router.SavedCombatWasPatrolAmbush = false;
            router.SavedCombatPatrolArchmageId = "";
            router.HasPendingReturn = true;
        }
        _hasLastMove = false; // S3 (Retrace): scene swap forgets the last step
        SaveManager.SaveIfDirty();
        ShowInfo($"Negotiation: {encounter.Title}");
        GetTree().ChangeSceneToFile("res://Scenes/Negotiation/NegotiationScene.tscn");
    }

    private void OnNegotiationReturned(Vector2I hexCoord)
    {
        if (NegotiationContext.DealAccepted)
        {
            GoldEarned = Mathf.Max(0, GoldEarned + NegotiationContext.GoldDelta);
            var cycle = SaveManager.ActiveSave?.Cycle;
            string kingdom = NegotiationContext.OriginKingdomId;
            bool kingdomAligned = cycle != null &&
                                  !string.IsNullOrEmpty(kingdom) &&
                                  cycle.Kingdoms.ContainsKey(kingdom);
            if (kingdomAligned)
            {
                // Kingdom-aligned: the deal echoes to the court (C4). Routed
                // on OriginKingdomId (the tile's kingdom), NOT the authored
                // FactionId — encounter JSONs carry non-kingdom faction keys,
                // so keying on FactionId here was structurally dead (Session D).
                // FactionReputation no longer stores kingdom feeling; court
                // standing is the single source of truth.
                int rep = NegotiationContext.ReputationDelta;
                if (rep != 0)
                {
                    string tag = (rep > 0 ? CouncilEcho.DealFair : CouncilEcho.DealExploit)
                                 + ":" + NegotiationContext.NpcArchetype;
                    string toast = CouncilEcho.EmitDeed(cycle, kingdom, tag, rep > 0, isMajor: false);
                    if (toast != null)
                        ShowInfo(toast);
                }
            }
            else if (SaveManager.ActiveSave != null)
            {
                // Non-kingdom faction (wilds, convergence, faction-specific
                // NPC): FactionReputation keeps its job, keyed by the
                // encounter's authored FactionId.
                string f = NegotiationContext.FactionId;
                if (!string.IsNullOrEmpty(f))
                {
                    var repDict = SaveManager.ActiveSave.FactionReputation;
                    repDict[f] = repDict.TryGetValue(f, out int cur)
                        ? cur + NegotiationContext.ReputationDelta
                        : NegotiationContext.ReputationDelta;
                }
            }
            ShowInfo($"Deal struck. Gold: {(NegotiationContext.GoldDelta >= 0 ? "+" : "")}{NegotiationContext.GoldDelta}");
        }
        else
            ShowInfo("No deal reached.");
        NegotiationContext.Clear();
        UpdateUI();
    }

    // ════════════════════════════════════════════════════════════════════
    // Extraction / failure
    // ════════════════════════════════════════════════════════════════════

    /// <summary>Extract-button router (W3 ruling): free extraction only while
    /// standing ON a supply anchor; anywhere else offers the emergency path
    /// behind a confirm. The return leg is the tension the step budget was
    /// built for — walking home is the cheap way out.</summary>
    private void OnExtractPressed()
    {
        if (ExpeditionComplete)
            return;
        if (OnSupplyAnchor())
        {
            Extract();
            return;
        }
        _emergencyConfirm?.PopupCentered();
    }

    /// <summary>W3 emergency extraction — the party abandons the field and
    /// straggles home. Costs: +1 lunation (CycleState.PendingStraggleLunations,
    /// advanced with the full world tick by StrategicView on return) and one
    /// §5b roll per companion at the tier-2 band (15% death, Sworn −10; the
    /// rest injured 1–2 lunations). AMENDS K2.5's "no death risk outside
    /// losing fights" — this is the price of extraction beyond the line.
    /// Spoils and discoveries ARE kept: the cost is time and bodies, not loot.</summary>
    private void EmergencyExtract()
    {
        if (ExpeditionComplete)
            return;
        ExpeditionComplete = true;
        PlayerSession.IsOnExpedition = false;

        if (EncounterRouter.Instance != null)
        {
            EncounterRouter.Instance.HasSavedSeed = false;
            EncounterRouter.Instance.HasPendingReturn = false;
        }

        OverworldSpellEffects.Clear(); // S2: timed spell windows end with the expedition

        _casualtyNote = CompanionInjurySystem.ApplyWipe(SaveManager.ActiveSave,
            territoryTier: 2, bossContext: false, "emergency extraction");
        CompanionInjurySystem.ResetExpeditionHP(SaveManager.ActiveSave);

        var cycle = SaveManager.ActiveSave?.Cycle;
        if (cycle != null)
            cycle.PendingStraggleLunations += 1;

        BankResources(extracted: true);
        string casualties = string.IsNullOrEmpty(_casualtyNote) ? "" : $" {_casualtyNote}";
        ShowInfo($"Emergency extraction. The party straggles home — a lunation will pass. " +
                 $"Gold: {GoldEarned}, Splinters: {SplinterEarned}.{casualties}");
        _casualtyNote = null;
        ShowReturnButton();
        EmitSignal(SignalName.ExpeditionEnded, true);
    }

    /// <summary>Voluntary or range-forced extraction: bank everything, save,
    /// return to the strategic view. Discoveries are already in World.</summary>
    private void Extract()
    {
        if (ExpeditionComplete)
            return;
        ExpeditionComplete = true;
        PlayerSession.IsOnExpedition = false;

        if (EncounterRouter.Instance != null)
        {
            EncounterRouter.Instance.HasSavedSeed = false;
            EncounterRouter.Instance.HasPendingReturn = false;
        }

        OverworldSpellEffects.Clear(); // S2: timed spell windows end with the expedition

        // K2.5 ruling: extraction infirmary check — who came home broken?
        // Stabilized (downed in a won fight) → 1–2 lunations; below 25% of
        // BaseHP → 1. Resets ExpeditionHP. No death risk on extraction.
        string extractCasualties = CompanionInjurySystem.ApplyExtractionCheck(SaveManager.ActiveSave);

        BankResources(extracted: true);
        ShowInfo($"Extracted. Gold: {GoldEarned}, Splinters: {SplinterEarned}, Encounters: {EncountersWon}." +
                 $"{(string.IsNullOrEmpty(extractCasualties) ? "" : " " + extractCasualties)}");
        ShowReturnButton();
        EmitSignal(SignalName.ExpeditionEnded, true);
    }

    private void FailExpedition(string reason, bool injuriesAlreadyRolled = false)
    {
        if (ExpeditionComplete)
            return;
        ExpeditionComplete = true;
        PlayerSession.IsOnExpedition = false;

        // K2 (§5b): the pool hit 0 — an expedition wipe. One roll per fielded
        // companion at the territory tier under the party's feet. Skipped when
        // the combat-loss return already rolled this wipe (one roll per wipe).
        if (!injuriesAlreadyRolled)
            _casualtyNote = CompanionInjurySystem.ApplyWipe(SaveManager.ActiveSave,
                TerritoryTierAt(_party?.CurrentCoord ?? Vector2I.Zero),
                bossContext: false, reason);

        // K2.5: expedition over — the wipe rolls above are the injury
        // accounting on this path; carried HP just clears.
        CompanionInjurySystem.ResetExpeditionHP(SaveManager.ActiveSave);
        OverworldSpellEffects.Clear(); // S2: timed spell windows end with the expedition

        if (EncounterRouter.Instance != null)
        {
            EncounterRouter.Instance.HasSavedSeed = false;
            EncounterRouter.Instance.HasPendingReturn = false;
        }

        // Failure still banks DISCOVERY (it's in World) but forfeits unbanked gold.
        BankResources(extracted: false);
        // The casualty note makes the human cost part of the banner — WHO was
        // hurt and for how long, not just that the run died (K2 UX).
        string casualties = string.IsNullOrEmpty(_casualtyNote) ? "" : $" {_casualtyNote}";
        ShowInfo($"Expedition failed: {reason} Discoveries retained; unbanked spoils lost.{casualties}");
        _casualtyNote = null;
        ShowReturnButton();
        EmitSignal(SignalName.ExpeditionEnded, false);
    }

    /// <summary>Write expedition results into the cycle save. Discovery is already
    /// resident in World; this handles the economy + stats.</summary>
    private void BankResources(bool extracted)
    {
        var save = SaveManager.ActiveSave;
        if (save == null)
            return;

        save.TotalRuns++;
        save.TotalEncountersWon += EncountersWon;
        save.TotalGoldEarned += GoldEarned;

        if (extracted)
        {
            save.Gold += GoldEarned;
            save.ArcaneSplinters += SplinterEarned;
            save.RunsWon++;
        }
        else
        {
            // Failure: keep a fraction, or nothing — design knob. Keep splinters,
            // lose loose gold, to match "discoveries retained, spoils lost."
            save.ArcaneSplinters += SplinterEarned;
            save.RunsLost++;
        }

        RunResultData.Set(extracted, GoldEarned, EncountersWon, CurrentHP, SplinterEarned);
        SaveManager.Save();
    }

    // ════════════════════════════════════════════════════════════════════
    // HUD
    // ════════════════════════════════════════════════════════════════════

    private CanvasLayer _hudCanvas;
    private CanvasLayer GetHudCanvas() => _hudCanvas;

    private void BuildHud()
    {
        _hudCanvas = new CanvasLayer { Name = "UI" };
        AddChild(_hudCanvas);

        var hudPanel = new PanelContainer
        {
            OffsetLeft = 12,
            OffsetTop = 12 + HudManager.BarHeight, // clear the global top bar
            OffsetRight = 300,
            OffsetBottom = 12,
        };
        var hudStyle = new StyleBoxFlat
        {
            BgColor = UITheme.OverworldHudBg,
            BorderColor = UITheme.OverworldHudBorder,
            BorderWidthTop = 1,
            BorderWidthBottom = 1,
            BorderWidthLeft = 1,
            BorderWidthRight = 1,
            CornerRadiusTopLeft = 6,
            CornerRadiusTopRight = 6,
            CornerRadiusBottomLeft = 6,
            CornerRadiusBottomRight = 6,
        };
        hudPanel.AddThemeStyleboxOverride("panel", hudStyle);
        _hudCanvas.AddChild(hudPanel);

        // Hover tooltip — follows the mouse, names the tile under it (fog-gated).
        _hoverTooltip = new Label { Visible = false, ZIndex = 100 };
        _hoverTooltip.AddThemeFontSizeOverride("font_size", UITheme.OverworldUIFontSize - 2);
        _hoverTooltip.AddThemeColorOverride("font_color", UITheme.TextPrimary);
        _hoverTooltip.AddThemeColorOverride("font_outline_color", UITheme.WorldDeep);
        _hoverTooltip.AddThemeConstantOverride("outline_size", 5);
        _hudCanvas.AddChild(_hoverTooltip);

        var margin = new MarginContainer();
        margin.AddThemeConstantOverride("margin_left", 12);
        margin.AddThemeConstantOverride("margin_right", 12);
        margin.AddThemeConstantOverride("margin_top", 10);
        margin.AddThemeConstantOverride("margin_bottom", 10);
        hudPanel.AddChild(margin);

        var vbox = new VBoxContainer();
        vbox.AddThemeConstantOverride("separation", 4);
        margin.AddChild(vbox);

        _stepLabel = MakeHudLabel();
        vbox.AddChild(_stepLabel);
        _hpLabel = MakeHudLabel();
        vbox.AddChild(_hpLabel);
        // S2: the second scarcity, read beside the first (§12).
        _essenceLabel = MakeHudLabel();
        _essenceLabel.AddThemeColorOverride("font_color", UITheme.EssenceText);
        vbox.AddChild(_essenceLabel);
        vbox.AddChild(new HSeparator());
        _windowLabel = MakeHudLabel();
        vbox.AddChild(_windowLabel);
        vbox.AddChild(new HSeparator());
        _infoLabel = MakeHudLabel();
        _infoLabel.Modulate = UITheme.OverworldInfoLabelTint;
        _infoLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
        vbox.AddChild(_infoLabel);

        // Extract button. W3: free extraction only ON a supply anchor; anywhere
        // else routes through the emergency-extraction confirm (OnExtractPressed).
        _extractButton = new Button
        {
            Text = "Extract",
            AnchorLeft = 1f,
            AnchorTop = 0f,
            AnchorRight = 1f,
            AnchorBottom = 0f,
            GrowHorizontal = Control.GrowDirection.Begin,
            OffsetLeft = -150,
            OffsetRight = -12,
            OffsetTop = 12 + HudManager.BarHeight, // clear the global top bar
            OffsetBottom = 52 + HudManager.BarHeight,
        };
        _extractButton.AddThemeFontSizeOverride("font_size", UITheme.OverworldUIFontSize);
        UITheme.ApplyButtonStyle(_extractButton, isPrimary: true);

        _extractButton.Pressed += OnExtractPressed;
        _hudCanvas.AddChild(_extractButton);

        // W3: emergency-extraction confirm. Free extraction happens only on a
        // supply anchor; anywhere else the party straggles home at real cost.
        _emergencyConfirm = new ConfirmationDialog
        {
            Title = "Emergency Extraction",
            DialogText = "You are away from any supply anchor. The party abandons\n" +
                         "the field and straggles home overland:\n\n" +
                         "  · One full lunation passes before you reach the campus.\n" +
                         "  · Every companion risks injury — or worse — on the road.\n\n" +
                         "Spoils and discoveries are kept. Extract anyway?",
            OkButtonText = "Extract",
        };
        _emergencyConfirm.Confirmed += EmergencyExtract;
        _hudCanvas.AddChild(_emergencyConfirm);

        // Ledger button (C3), stacked under Extract.
        _ledgerButton = new Button
        {
            Text = "Ledger",
            AnchorLeft = 1f,
            AnchorTop = 0f,
            AnchorRight = 1f,
            AnchorBottom = 0f,
            GrowHorizontal = Control.GrowDirection.Begin,
            OffsetLeft = -150,
            OffsetRight = -12,
            OffsetTop = 60 + HudManager.BarHeight, // clear the global top bar
            OffsetBottom = 100 + HudManager.BarHeight,
        };
        _ledgerButton.AddThemeFontSizeOverride("font_size", UITheme.OverworldUIFontSize);
        UITheme.ApplyButtonStyle(_ledgerButton, isPrimary: false);
        _ledgerButton.Pressed += () => _ledgerPanel?.Toggle();
        _hudCanvas.AddChild(_ledgerButton);

        // Scout panel.
        _scoutPanel = new ScoutReportPanel { Name = "ScoutPanel" };
        _hudCanvas.AddChild(_scoutPanel);

        // Return button (hidden until expedition ends).
        _returnButton = new Button
        {
            Text = "Return to Strategic Map",
            Visible = false,
            AnchorLeft = 0.5f,
            AnchorTop = 0.82f,
            AnchorRight = 0.5f,
            AnchorBottom = 0.82f,
            GrowHorizontal = Control.GrowDirection.Both,
            GrowVertical = Control.GrowDirection.Both,
            OffsetLeft = -150,
            OffsetRight = 150,
            OffsetTop = -26,
            OffsetBottom = 26,
        };
        _returnButton.AddThemeFontSizeOverride("font_size", UITheme.OverworldUIFontSize);
        UITheme.ApplyButtonStyle(_returnButton, isPrimary: true);
        _returnButton.Pressed += () => GetTree().ChangeSceneToFile(StrategicScenePath);
        _hudCanvas.AddChild(_returnButton);
    }

    private void ShowReturnButton()
    {
        if (_extractButton != null)
            _extractButton.Visible = false;
        if (_ledgerButton != null)
            _ledgerButton.Visible = false;
        if (_ledgerPanel != null)
            _ledgerPanel.Close();
        if (_returnButton != null)
            _returnButton.Visible = true;
    }

    private Label MakeHudLabel()
    {
        var l = new Label { AutowrapMode = TextServer.AutowrapMode.Off };
        l.AddThemeFontSizeOverride("font_size", UITheme.OverworldUIFontSize);
        return l;
    }

    // ════════════════════════════════════════════════════════════════════
    // Process / camera / UI
    // ════════════════════════════════════════════════════════════════════

    public override void _Process(double delta)
    {
        if (ExpeditionComplete || _camera == null)
            return;
        HandleCameraPan((float)delta);
        PositionTooltip();
    }

    private void HandleCameraPan(float delta)
    {
        var dir = Vector2.Zero;
        if (Input.IsActionPressed("ui_right") || Input.IsKeyPressed(Key.D))
            dir.X += 1f;
        if (Input.IsActionPressed("ui_left") || Input.IsKeyPressed(Key.A))
            dir.X -= 1f;
        if (Input.IsActionPressed("ui_down") || Input.IsKeyPressed(Key.S))
            dir.Y += 1f;
        if (Input.IsActionPressed("ui_up") || Input.IsKeyPressed(Key.W))
            dir.Y -= 1f;
        if (dir != Vector2.Zero)
        {
            _cameraFreeMode = true;
            _camera.Position += dir.Normalized() * CameraPanSpeed * delta / _camera.Zoom.X;
        }
    }

    private void CenterCamera()
    {
        if (_camera != null)
        { _camera.Position = _party.Position; _cameraFreeMode = false; }
    }

    private void UpdateUI()
    {
        _stepLabel.Text = (PlayerSession.DebugMode && PlayerSession.UnlimitedSteps)
            ? "Range: ∞ [DEBUG]"
            : $"Range: {StepsRemaining} / {OperatingRange}";
        _stepLabel.Modulate = StepsRemaining > 5 ? Colors.White : UITheme.OverworldLowResourceWarning;

        _hpLabel.Text = $"HP: {CurrentHP} / {MaxHP}";
        _hpLabel.Modulate = CurrentHP > MaxHP / 3 ? Colors.White : UITheme.OverworldLowResourceWarning;

        // S2: the Essence pool, beside the other scarcities (§12).
        var grimoire = SaveManager.ActiveSave?.Cycle?.Grimoire;
        if (_essenceLabel != null && grimoire != null)
        {
            _essenceLabel.Text = $"Essence: {grimoire.EssenceCurrent} / {grimoire.EssenceMax}";
            _essenceLabel.Modulate = grimoire.EssenceCurrent > 2
                ? Colors.White : UITheme.OverworldLowResourceWarning;
        }

        // W3: supply readout replaces the old fixed-window explored counter
        // (the loaded set now slides and grows — a ratio over it is noise).
        int supplyDist = SupplyDistanceAt(_party.CurrentCoord);
        int supplyBand = SupplyBandAt(_party.CurrentCoord);
        _windowLabel.Text = supplyBand == 0
            ? $"Supply: in range ({supplyDist}/{SupplyRange})"
            : $"Supply: {supplyDist - SupplyRange} beyond the line (−{supplyBand * LeashDrainPerBand} HP/step)";
        _windowLabel.Modulate = supplyBand == 0 ? Colors.White : UITheme.OverworldLowResourceWarning;

        if (_grid.Hexes.TryGetValue(_party.CurrentCoord, out var cur))
            _windowLabel.Text += $"  |  {cur.Terrain}";
        string curKingdom = KingdomIdAt(_party.CurrentCoord);
        _windowLabel.Text += $"  |  {(string.IsNullOrEmpty(curKingdom) ? "Unclaimed" : KingdomDisplayName(curKingdom))}";

        // W3: the button tells the truth about which extraction you'd get.
        if (_extractButton != null && !ExpeditionComplete)
            _extractButton.Text = OnSupplyAnchor() ? "Extract" : "Emergency Extract";

        // S2: affordability / surcharge / active-effect readout.
        _grimoirePanel?.Refresh();
    }

    private void ShowInfo(string message)
    {
        _infoLabel.Text = message;
        GD.Print($"[Expedition] {message}");
    }

    // ════════════════════════════════════════════════════════════════════
    // Helpers
    // ════════════════════════════════════════════════════════════════════

    private string StagingKingdom()
        => _world.GetTile(_stagingCol, _stagingRow).KingdomId ?? "frontier_wilds";

    /// <summary>The content template region for the staging kingdom — the real
    /// region name (e.g. "frontier_wilds") that encounter/narrative pools are
    /// filed under, NOT the "kingdom_N" id. Resolves via the kingdom's
    /// TemplateRegionId set at world generation; falls back to the borderlands.</summary>
    private string StagingTemplateRegion()
    {
        string kid = StagingKingdom();
        if (_world != null && SaveManager.ActiveSave?.Cycle?.Kingdoms != null &&
            SaveManager.ActiveSave.Cycle.Kingdoms.TryGetValue(kid, out var ks) &&
            !string.IsNullOrEmpty(ks.TemplateRegionId))
        {
            return ks.TemplateRegionId;
        }
        return "frontier_wilds";
    }

    // ── Archmage faction encounters ─────────────────────────────────────

    /// <summary>The non-villain archmage definition for an id, or null.</summary>
    private ArchmageDefinition ArchmageDefById(string archmageId)
    {
        if (string.IsNullOrEmpty(archmageId))
            return null;
        var def = ArchmageRegistry.Get(archmageId);
        return (def == null || def.IsVillainFaction) ? null : def;
    }

    /// <summary>Archmage controlling the kingdom that owns the given window-local
    /// tile, or "" if none. Per-tile (NOT staging-keyed) so a border-straddling
    /// window fights whoever actually holds the ground you're standing on.</summary>
    private string KingdomArchmageAt(Vector2I local)
    {
        if (!_window.TryLocalToWorld(local, out int col, out int row))
            return "";
        string kid = _world.GetTile(col, row).KingdomId ?? "";
        if (!string.IsNullOrEmpty(kid) &&
            SaveManager.ActiveSave?.Cycle?.Kingdoms != null &&
            SaveManager.ActiveSave.Cycle.Kingdoms.TryGetValue(kid, out var ks))
            return ks.ArchmageId ?? "";
        return "";
    }

    /// <summary>Roll the resident archmage's ArchmageFactionChance for an ordinary
    /