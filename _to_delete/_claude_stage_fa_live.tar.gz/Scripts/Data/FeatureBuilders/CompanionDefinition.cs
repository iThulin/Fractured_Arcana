using System.Collections.Generic;

// ============================================================
// CompanionDefinition.cs
//
// Purpose:        Companion data model. Holds identity, school,
//                 recruitment/loyalty/arc state, unit class
//                 (Arcane / Fighter / Ranger / None levy),
//                 base combat stats, trained stances, and the
//                 cards contributed to the active wizard's deck.
//                 Persists across runs in GuildSaveData.
// Layer:          Data
// Collaborators:  CompanionLoader.cs (JSON parser),
//                 CompanionRoster.cs (collection wrapper),
//                 GuildSaveData.cs (persistence),
//                 StanceDefinition.cs (ActiveStance), Unit.cs
// See:            README §4.5 (Adding a Companion)
// ============================================================

/// <summary>One companion's full data: identity, recruitment status, arc progression, unit class, base combat stats, trained stances, and run-scoped runtime state. Companions persist across runs; arc and loyalty progression lives here.</summary>
public class Companion
{
    // ── Identity ────────────────────────────────────────────────────────
    public string Id = "";              // unique key, e.g. "elara_stormcaller"
    public string Name = "";
    public string School = "Elementalist";
    public string PersonalityTrait = ""; // flavor: "Reckless", "Stoic", "Curious"
    public string Backstory = "";

    // ── State ───────────────────────────────────────────────────────────
    public bool IsRecruited = false;
    public bool IsAvailable = false;     // is recruitment unlocked?
    public bool IsPermadead = false;
    public int Loyalty = 50;             // 0-100
    public int ArcStage = 0;             // 0 = not started, 1-3 in progress, 4 complete

    // ── Injury (K2, §5b) ─────────────────────────────────────────────────
    // Lunations left in the infirmary. >0 = excluded from all three demands
    // (expedition, court dispatch — recovery IS the third). Serialized;
    // round-trip asserted in CompanionInjurySystem.
    public int InjuredLunationsRemaining = 0;

    [System.Text.Json.Serialization.JsonIgnore]
    public bool IsInjured => InjuredLunationsRemaining > 0;

    // ── Expedition HP (K2.5 ruling, 2026-07-09) ──────────────────────────
    // Combat HP persists BETWEEN fights within one expedition: unit HP is
    // the fights, the party pool is the journey. -1 = fresh/full. 0 = downed
    // in a WON fight — stabilized, cannot field again this expedition.
    // Set on combat end, consumed at spawn, resolved by the extraction
    // infirmary check (below 25% of BaseHP → recovery time), reset at
    // expedition launch/end. Serialized for mid-expedition saves.
    public int ExpeditionHP = -1;

    // ── Unit class ───────────────────────────────────────────────────────
    // "Arcane" = wizard-type (card-based, has mana)
    // "Fighter" = melee martial
    // "Ranger" = ranged martial
    // "None" = unclassed levy (default for new companions)
    public string UnitClass = "None";

    // ── Combat stats (base values at levy tier) ──────────────────────────
    // Wizards: these are ignored — wizard stats come from PlayerSession/school
    // Martials: these are the starting levy stats, boosted by Training Grounds
    public int BaseHP = 12;
    public int BaseSpeed = 2;
    public int BaseArmor = 0;
    public int BaseAttackDamage = 3;
    public int BaseAttackRange = 1;
    public int BaseMana = 0;   // always 0 for martials

    // ── Martial progression (saved per companion) ────────────────────────
    // Which stances this companion has been trained in at the campus.
    // Populated by the Training tab — not from JSON templates.
    [System.Text.Json.Serialization.JsonPropertyName("availableStanceIds")]
    public List<string> TrainedStanceIds = new();

    // AP pool — set by Training Grounds tier at run start
    // Stored here so the UI can show it between runs
    public i