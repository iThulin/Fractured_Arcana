using Godot;
using System;
using System.Collections.Generic;

// ============================================================
// CombatUI.cs
//
// Purpose:        CanvasLayer hosting all in-combat HUD panels.
//                 Fully procedural — no .tscn layout dependencies.
//                 All children built via CallDeferred(nameof(BuildUI))
//                 to satisfy Mac + Metal Compatibility mode rules.
//
// Layout:
//   Top-left  (280px wide, shrinks to content)
//             ┌─ Left Panel ──────────────────────────┐
//             │  ROUND 1 - PLAYER TURN                │
//             │  ─────────────────────────────────── │
//             │  Wizard_1  (large name)               │
//             │  HP ████████░░  12/20                 │
//             │  MP ████░░░░░░   4/10                 │
//             │  ARM 3  AP ●●○  SPD 4                 │
//             │  🔥 ❄ (status icons)                  │
//             │  ── LOG ─────────────────────────── │
//             │  Ranger_1 repositions.                │
//             │  Wizard_3 begins channelling...       │
//             │  ── PARTY ───────────────────────── │
//             │  [Wiz1 ●●●][Wiz2 ●○○]                │
//             │  [Deck 5]  [Grave 2]                  │
//             │  [     End Turn     ]                 │
//             └───────────────────────────────────────┘
//
//   Top-right (220px wide, shrinks to content)
//             ┌─ Enemy Roster ────────────────────────┐
//             │  ─ ENEMIES ─                          │
//             │  Ranger_1   ████████░░  18/20         │
//             │  Wizard_3   ████░░░░░░  10/20         │
//             └───────────────────────────────────────┘
//
//   Cards sit at the bottom of the screen with no bar below them.
//
// Layer:          UI
// Collaborators:  CombatManager.cs, Unit.cs, UITheme.cs
// See:            README §8 (Godot 4.6 compat — CallDeferred rules)
// ============================================================

public partial class CombatUI : CanvasLayer
{
	// ── Signals ──────────────────────────────────────────────────────────
	[Signal] public delegate void ConfirmDeploymentPressedEventHandler();
	[Signal] public delegate void EndTurnPressedEventHandler();
	[Signal] public delegate void UnitButtonPressedEventHandler(int unitIndex);
	[Signal] public delegate void EnemyButtonPressedEventHandler(int unitIndex);
	/// <summary>U3: the player surrenders priority during an enemy-trigger window.</summary>
	[Signal] public delegate void PriorityPassPressedEventHandler();

	// ── Layout constants (design-space px — V1 resolution ruling) ────────
	private const int LeftPanelWidth = 280;
	private const int RightPanelWidth = 220;
	private const int PanelPadding = 10;
	private const int BarHeight = 10;
	private const int ManaBarHeight = 8;
	private const int LogLineCount = 3;          // V1: 3-line ticker (was 6-line panel section)
	private const int LogHistoryCap = 200;       // full-history popup buffer
	private const int UnitButtonWidth = 110;
	private const int EnemyBarWidth = 90;
	private const int BottomLeftWidth = 360;     // party chips + ticker block (chips may overflow right — they sit above the deck button's row, so nothing collides until 5+ chips)
	private const int EndTurnWidth = 180;
	private const int FlankButtonWidth = 96;     // deck/grave beside the fan

	// ── Left panel nodes ─────────────────────────────────────────────────
	private PanelContainer _leftPanel;
	private Label _phaseLabel;
	private Label _unitNameLabel;
	private ProgressBar _hpBar;
	private Label _hpText;
	private ProgressBar _mpBar;
	private Label _mpText;
	private Label _statLine;
	private Label _stanceLine;
	private HBoxContainer _statusIconRow;
	private VBoxContainer _logBox;
	private Label[] _logLines;
	private Label _hintLabel;
	private HBoxContainer _playerUnitBar;
	private Button _deckButton;
	private Button _graveButton;
	private Button _endTurnButton;
	private Button _confirmDeploymentButton;

	// Pending selected unit state for when ShowSelectedUnit arrives before BuildUI
	private Unit _pendingUnit = null;
	private int _pendingMana = 0;
	private bool _unitPending = false;

	private VBoxContainer _attunementSection;
	private VBoxContainer _inspectBlock;   // V2: enemy behavior/ability/faction blocks

	// ── Right panel nodes ────────────────────────────────────────────────
	private PanelContainer _rightPanel;
	private VBoxContainer _enemyRosterBox;

	// ── Popups ───────────────────────────────────────────────────────────
	private PopupPanel _gravePopup;
	private ItemList _graveList;
	private PopupPanel _deckPopup;
	private ItemList _deckList;

	// ── Log ring buffer ──────────────────────────────────────────────────
	private readonly Queue<string> _logQueue = new Queue<string>();
	// V1: full history behind the ticker (click to open), capped.
	private readonly List<string> _logHistory = new List<string>();
	private PopupPanel _logPopup;
	private ItemList _logHistoryList;

	// ── Pending state for calls that arrive before BuildUI fires ─────────
	private List<EnemyIntelEntry> _pendingIntel = null;

	// ── Build / pending state ─────────────────────────────────────────────
	private bool _built = false;
	private bool _pendingDeploymentMode = false;
	private bool _deploymentModePending = false;

	/// <summary>True once BuildUI has run. CombatManager's skip-deploy handoff
	/// waits on this before pushing selection/roster state (2026-07-09) — calls
	/// that land before the build either drop silently or hit empty panels.</summary>
	public bool IsBuilt => _built;

	// ── Status display map ───────────────────────────────────────────────
	private static readonly Dictionary<string, (string symbol, Color color)> StatusDisplay = new()
	{
		{ "burn",                 ("🔥", new Color(1.0f,  0.45f, 0.1f))  },
		{ "frozen",               ("❄",  new Color(0.4f,  0.8f,  1.0f))  },
		{ "poisoned",             ("☠",  new Color(0.5f,  0.9f,  0.2f))  },
		{ "stunned",              ("★",  new Color(1.0f,  0.95f, 0.3f))  },
		{ "rooted",               ("⊕",  new Color(0.55f, 0.85f, 0.3f))  },
		{ "slowed",               ("↓",  new Color(0.6f,  0.6f,  0.9f))  },
		{ "haunted",              ("✦",  new Color(0.7f,  0.4f,  1.0f))  },
		{ "bound",                ("⛓",  new Color(0.75f, 0.65f, 0.4f))  },
		{ "arcane_mark",          ("◈",  new Color(0.4f,  0.7f,  1.0f))  },
		{ "chaining",             ("⚡",  new Color(0.9f,  0.85f, 0.2f))  },
		{ "vigil",                ("👁",  new Color(0.85f, 0.85f, 1.0f))  },
		{ "undying_turn",         ("↺",  new Color(0.9f,  0.7f,  0.3f))  },
		{ "undying_full_restore", ("✙",  new Color(0.9f,  0.7f,  0.3f))  },
	};

	// ════════════════════════════════════════════════════════════════════
	// Lifecycle
	// ════════════════════════════════════════════════════════════════════

	public override void _Ready()
	{
		CallDeferred(nameof(BuildUI));
	}

	/// <summary>V1: Enter / keypad-Enter ends the turn (or confirms deployment —
	/// same morph as the button). The bottom-right corner is a long mouse trip
	/// every turn; the key is the fix. Suppressed while any popup or the U3
	/// priority prompt is open so Enter can never blind-pass a stack window.</summary>
	public override void _UnhandledInput(InputEvent @event)
	{
		if (@event is not InputEventKey { Pressed: true, Echo: false } key)
			return;
		if (key.Keycode != Key.Enter && key.Keycode != Key.KpEnter)
			return;
		if (_endTurnButton == null || !_endTurnButton.Visible || _endTurnButton.Disabled)
			return;
		if (StackWindowInteractive)
			return;
		if ((_deckPopup?.Visible ?? false) || (_gravePopup?.Visible ?? false) || (_logPopup?.Visible ?? false))
			return;

		if (_endTurnButton.Text == "Confirm Deployment")
			EmitSignal(SignalName.ConfirmDeploymentPressed);
		else
			EmitSignal(SignalName.EndTurnPressed);
		GetViewport().SetInputAsHandled();
	}

	private void BuildUI()
	{
		if (_built)
			return;
		_built = true;

		// V1 layout (combat_ui_v2 §5): banner top-center, End Turn bottom-right,
		// log ticker + party chips bottom-left, hint + deck/grave flanking the
		// bottom-center hand, left panel slimmed to unit card + attunement.
		BuildTopBanner();
		BuildLeftPanel();
		BuildRightPanel();
		BuildBottomLeft();
		BuildBottomRight();
		BuildBottomCenter();
		BuildPopups();

		RedrawLog();

		if (_unitPending)
			ApplySelectedUnit(_pendingUnit, _pendingMana);

		if (_pendingIntel != null)
			BuildEnemyIntelRows(_pendingIntel);

		if (_deploymentModePending)
			ApplyDeploymentMode();

		// Roster replay (2026-07-09): RefreshEnemyRoster calls that arrived
		// before the build used to drop silently — the skip-deploy handoff's
		// roster load was lost until the next damage event re-refreshed it.
		if (_lastRosterEnemies != null)
			RefreshEnemyRoster(_lastRosterEnemies);

		// Phase banner / hint replay (2026-07-09): same pre-build drop.
		if (_lastPhaseText != null)
			SetPhaseText(_lastPhaseText);
		if (_lastHintText != null)
			SetHintText(_lastHintText);
	}
	// ════════════════════════════════════════════════════════════════════
	// Left panel
	// ════════════════════════════════════════════════════════════════════

	private void BuildLeftPanel()
	{
		_leftPanel = new PanelContainer
		{
			Name = "LeftPanel",
			AnchorLeft = 0f,
			AnchorTop = 0f,
			AnchorRight = 0f,
			AnchorBottom = 0f,
			OffsetTop = HudManager.BarHeight, // clear the global top bar
			OffsetRight = LeftPanelWidth,
			GrowHorizontal = Control.GrowDirection.End,
			GrowVertical = Control.GrowDirection.End,
		};
		_leftPanel.AddThemeStyleboxOverride("panel",
			UITheme.MakePanelStyle(UITheme.BgBase, UITheme.Violet));
		AddChild(_leftPanel);

		var margin = new MarginContainer { Name = "Margin" };
		margin.AddThemeConstantOverride("margin_left", PanelPadding);
		margin.AddThemeConstantOverride("margin_right", PanelPadding);
		margin.AddThemeConstantOverride("margin_top", PanelPadding);
		margin.AddThemeConstantOverride("margin_bottom", PanelPadding);
		margin.SizeFlagsVertical = Control.SizeFlags.ShrinkBegin;
		_leftPanel.AddChild(margin);

		var vbox = new VBoxContainer { Name = "VBox" };
		vbox.AddThemeConstantOverride("separation", 6);
		margin.AddChild(vbox);

		// (V1: phase banner moved to top center — BuildTopBanner.)

		// ── Unit name ────────────────────────────────────────────────
		_unitNameLabel = MakeLabel("—", UITheme.FontSizeLarge, UITheme.TextPrimary);
		_unitNameLabel.HorizontalAlignment = HorizontalAlignment.Center;
		_unitNameLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
		vbox.AddChild(_unitNameLabel);

		// ── HP bar ───────────────────────────────────────────────────
		vbox.AddChild(MakeBarRow("HP", BarHeight,
			out _hpBar, out _hpText,
			UITheme.StatBarHealth, UITheme.BgDeep));

		// ── MP bar ───────────────────────────────────────────────────
		vbox.AddChild(MakeBarRow("MP", ManaBarHeight,
			out _mpBar, out _mpText,
			UITheme.StatBarMana, UITheme.BgDeep));

		// ── Stat line ────────────────────────────────────────────────
		_statLine = MakeLabel("", UITheme.FontSizeSmall, UITheme.TextSecondary);
		_statLine.HorizontalAlignment = HorizontalAlignment.Center;
		vbox.AddChild(_statLine);

		// ── Stance (martial only) ────────────────────────────────────
		_stanceLine = MakeLabel("", UITheme.FontSizeSmall, UITheme.Gold);
		_stanceLine.HorizontalAlignment = HorizontalAlignment.Center;
		_stanceLine.AutowrapMode = TextServer.AutowrapMode.WordSmart;
		_stanceLine.Visible = false;
		vbox.AddChild(_stanceLine);

		// ── Status icons ─────────────────────────────────────────────
		_statusIconRow = new HBoxContainer { Name = "StatusIcons" };
		_statusIconRow.AddThemeConstantOverride("separation", 4);
		_statusIconRow.Alignment = BoxContainer.AlignmentMode.Center;
		vbox.AddChild(_statusIconRow);

		// ── V2 inspect block (enemies only): behavior line, ability blocks,
		// role/faction line (combat_ui_v2 §7b) ───────────────────────
		_inspectBlock = new VBoxContainer { Name = "InspectBlock", Visible = false };
		_inspectBlock.AddThemeConstantOverride("separation", 4);
		vbox.AddChild(_inspectBlock);

		// Attunement slot — populated by SchoolAttunementUI.UseExternalContainer()
		vbox.AddChild(MakeDivider(UITheme.VioletDim));
		_attunementSection = new VBoxContainer { Name = "AttunementSection" };
		_attunementSection.AddThemeConstantOverride("separation", 4);
		_attunementSection.Visible = false;   // hidden until a school with an attunement is selected
		GD.Print($"[CombatUI] AttunementSection built: {_attunementSection != null}");
		vbox.AddChild(_attunementSection);

		// (V1: log, party chips, deck/grave, and End Turn all moved out — the
		// left column stops being a junk drawer. §5: log+party → bottom left,
		// deck/grave → flanking the hand, End Turn → bottom right.)
	}

	// ════════════════════════════════════════════════════════════════════
	// V1: top-center banner (phase line; V4 adds the context strip below)
	// ════════════════════════════════════════════════════════════════════

	private void BuildTopBanner()
	{
		var banner = new PanelContainer
		{
			Name = "TopBanner",
			AnchorLeft = 0.5f, AnchorRight = 0.5f, AnchorTop = 0f, AnchorBottom = 0f,
			OffsetLeft = -260, OffsetRight = 260,
			OffsetTop = HudManager.BarHeight + 6,
			GrowHorizontal = Control.GrowDirection.Both,
			GrowVertical = Control.GrowDirection.End,
		};
		banner.AddThemeStyleboxOverride("panel",
			UITheme.MakePanelStyle(UITheme.BgBase, UITheme.Violet));
		AddChild(banner);

		var margin = new MarginContainer { Name = "Margin" };
		margin.AddThemeConstantOverride("margin_left", PanelPadding);
		margin.AddThemeConstantOverride("margin_right", PanelPadding);
		margin.AddThemeConstantOverride("margin_top", 4);
		margin.AddThemeConstantOverride("margin_bottom", 4);
		banner.AddChild(margin);

		var vbox = new VBoxContainer { Name = "VBox" };
		vbox.AddThemeConstantOverride("separation", 2);
		margin.AddChild(vbox);

		_phaseLabel = MakeLabel("", UITheme.FontSizeNormal, UITheme.Violet);
		_phaseLabel.HorizontalAlignment = HorizontalAlignment.Center;
		vbox.AddChild(_phaseLabel);

		// Hint line rides the banner (V1 fix: its first home above the fan sat
		// exactly on the card tops — unreadable and mid-hand). V4's context
		// strip takes this slot later; the hint then moves or dies.
		_hintLabel = MakeLabel("", UITheme.FontSizeSmall, UITheme.TextDim);
		_hintLabel.Name = "HintLabel";
		_hintLabel.HorizontalAlignment = HorizontalAlignment.Center;
		_hintLabel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
		vbox.AddChild(_hintLabel);
	}

	// ════════════════════════════════════════════════════════════════════
	// V1: bottom-left — party chips above a 3-line log ticker (click = full
	// history popup)
	// ════════════════════════════════════════════════════════════════════

	private void BuildBottomLeft()
	{
		var block = new VBoxContainer
		{
			Name = "BottomLeft",
			AnchorLeft = 0f, AnchorRight = 0f, AnchorTop = 1f, AnchorBottom = 1f,
			OffsetLeft = 12, OffsetRight = 12 + BottomLeftWidth,
			OffsetTop = -12, OffsetBottom = -12,
			GrowHorizontal = Control.GrowDirection.End,
			GrowVertical = Control.GrowDirection.Begin,
		};
		block.AddThemeConstantOverride("separation", 6);
		AddChild(block);

		// Party chips — slim row above the ticker (§5: ambient awareness).
		_playerUnitBar = new HBoxContainer { Name = "UnitBar" };
		_playerUnitBar.AddThemeConstantOverride("separation", 4);
		block.AddChild(_playerUnitBar);

		// Log ticker — 3 lines, panel-backed, clickable for full history.
		var logPanel = new PanelContainer { Name = "LogTicker" };
		logPanel.AddThemeStyleboxOverride("panel",
			UITheme.MakePanelStyle(UITheme.BgBase, UITheme.VioletDim));
		block.AddChild(logPanel);

		var logMargin = new MarginContainer { Name = "Margin" };
		logMargin.AddThemeConstantOverride("margin_left", 8);
		logMargin.AddThemeConstantOverride("margin_right", 8);
		logMargin.AddThemeConstantOverride("margin_top", 4);
		logMargin.AddThemeConstantOverride("margin_bottom", 4);
		logPanel.AddChild(logMargin);

		_logBox = new VBoxContainer { Name = "LogBox" };
		_logBox.AddThemeConstantOverride("separation", 2);
		logMargin.AddChild(_logBox);

		_logLines = new Label[LogLineCount];
		for (int i = 0; i < LogLineCount; i++)
		{
			var lbl = MakeLabel("", UITheme.FontSizeSmall,
				i == LogLineCount - 1 ? UITheme.TextPrimary : UITheme.TextDim);
			lbl.AutowrapMode = TextServer.AutowrapMode.WordSmart;
			lbl.CustomMinimumSize = new Vector2(BottomLeftWidth - 20, 0);
			_logLines[i] = lbl;
			_logBox.AddChild(lbl);
		}

		// Click catcher — the whole ticker opens the scrollable history.
		var clickCatcher = new Button
		{
			Name = "LogClickCatcher",
			Flat = true,
			Text = "",
			TooltipText = "Click for full combat log",
			MouseFilter = Control.MouseFilterEnum.Stop,
		};
		clickCatcher.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
		clickCatcher.AddThemeStyleboxOverride("normal", new StyleBoxEmpty());
		clickCatcher.AddThemeStyleboxOverride("hover", new StyleBoxEmpty());
		clickCatcher.AddThemeStyleboxOverride("pressed", new StyleBoxEmpty());
		clickCatcher.AddThemeStyleboxOverride("focus", new StyleBoxEmpty());
		clickCatcher.Pressed += OnLogTickerPressed;
		logPanel.AddChild(clickCatcher);
	}

	// ════════════════════════════════════════════════════════════════════
	// V1: bottom-right — End Turn / Confirm Deployment, standard tactics
	// corner position
	// ════════════════════════════════════════════════════════════════════

	private void BuildBottomRight()
	{
		var block = new VBoxContainer
		{
			Name = "BottomRight",
			AnchorLeft = 1f, AnchorRight = 1f, AnchorTop = 1f, AnchorBottom = 1f,
			OffsetLeft = -12 - EndTurnWidth, OffsetRight = -12,
			OffsetTop = -12, OffsetBottom = -12,
			GrowHorizontal = Control.GrowDirection.Begin,
			GrowVertical = Control.GrowDirection.Begin,
		};
		block.AddThemeConstantOverride("separation", 6);
		AddChild(block);

		// Confirm Deployment (hidden by default; End Turn also morphs as today)
		_confirmDeploymentButton = new Button
		{
			Name = "ConfirmDeployBtn",
			Text = "Confirm Deployment",
			Visible = false,
			CustomMinimumSize = new Vector2(EndTurnWidth, 40),
		};
		UITheme.ApplyButtonStyle(_confirmDeploymentButton, isPrimary: true);
		_confirmDeploymentButton.AddThemeFontSizeOverride("font_size", UITheme.FontSizeSmall);
		_confirmDeploymentButton.Pressed += () => EmitSignal(SignalName.ConfirmDeploymentPressed);
		block.AddChild(_confirmDeploymentButton);

		_endTurnButton = new Button
		{
			Name = "EndTurnButton",
			Text = "End Turn",
			TooltipText = "Enter",
			CustomMinimumSize = new Vector2(EndTurnWidth, 48),
		};
		StyleEndTurnButton(_endTurnButton);
		_endTurnButton.Pressed += () =>
		{
			if (_endTurnButton.Text == "Confirm Deployment")
				EmitSignal(SignalName.ConfirmDeploymentPressed);
			else
				EmitSignal(SignalName.EndTurnPressed);
		};
		block.AddChild(_endTurnButton);
	}

	// ════════════════════════════════════════════════════════════════════
	// V1: bottom-center — hint line above the fan, deck/grave flanking it
	// ════════════════════════════════════════════════════════════════════

	private void BuildBottomCenter()
	{
		// (V1 fix: the hint line moved into the top banner — above the fan it
		// sat on the card tops.)

		// Deck / Grave counters flank the fan left/right (§5) — placed just
		// INSIDE the hand reserves so they never collide with cards, the
		// bottom-left block, or the End Turn corner (see UITheme tiling note).
		_deckButton = MakeSmallButton("Deck —");
		_deckButton.Name = "DeckButton";
		_deckButton.AnchorLeft = 0f; _deckButton.AnchorRight = 0f;
		_deckButton.AnchorTop = 1f; _deckButton.AnchorBottom = 1f;
		_deckButton.OffsetLeft = UITheme.HandReserveLeft - 8 - FlankButtonWidth;
		_deckButton.OffsetRight = UITheme.HandReserveLeft - 8;
		_deckButton.OffsetTop = -52; _deckButton.OffsetBottom = -14;
		_deckButton.GrowVertical = Control.GrowDirection.Begin;
		_deckButton.Pressed += OnDeckButtonPressed;
		AddChild(_deckButton);

		_graveButton = MakeSmallButton("Grave —");
		_graveButton.Name = "GraveButton";
		_graveButton.AnchorLeft = 1f; _graveButton.AnchorRight = 1f;
		_graveButton.AnchorTop = 1f; _graveButton.AnchorBottom = 1f;
		_graveButton.OffsetLeft = -(UITheme.HandReserveRight - 8);
		_graveButton.OffsetRight = -(UITheme.HandReserveRight - 8 - FlankButtonWidth);
		_graveButton.OffsetTop = -52; _graveButton.OffsetBottom = -14;
		_graveButton.GrowHorizontal = Control.GrowDirection.Begin;
		_graveButton.GrowVertical = Control.GrowDirection.Begin;
		_graveButton.Pressed += OnGraveButtonPressed;
		AddChild(_graveButton);
	}

	// ════════════════════════════════════════════════════════════════════
	// Right panel — enemy roster
	// ════════════════════════════════════════════════════════════════════

	private void BuildRightPanel()
	{
		_rightPanel = new PanelContainer
		{
			Name = "RightPanel",
			AnchorLeft = 1f,
			AnchorTop = 0f,
			AnchorRight = 1f,
			AnchorBottom = 0f,
			OffsetTop = HudManager.BarHeight, // clear the global top bar
			OffsetLeft = -RightPanelWidth,
			GrowHorizontal = Control.GrowDirection.Begin,
			GrowVertical = Control.GrowDirection.End,
		};
		_rightPanel.AddThemeStyleboxOverride("panel",
			UITheme.MakePanelStyle(UITheme.BgBase, UITheme.VioletDim));
		AddChild(_rightPanel);

		var margin = new MarginContainer { Name = "Margin" };
		margin.AddThemeConstantOverride("margin_left", PanelPadding);
		margin.AddThemeConstantOverride("margin_right", PanelPadding);
		margin.AddThemeConstantOverride("margin_top", PanelPadding);
		margin.AddThemeConstantOverride("margin_bottom", PanelPadding);
		_rightPanel.AddChild(margin);

		var vbox = new VBoxContainer { Name = "VBox" };
		vbox.AddThemeConstantOverride("separation", 4);
		margin.AddChild(vbox);

		var header = MakeLabel("─ ENEMIES ─", UITheme.FontSizeSmall, UITheme.Violet);
		header.HorizontalAlignment = HorizontalAlignment.Center;
		vbox.AddChild(header);

		vbox.AddChild(MakeDivider(UITheme.VioletDim));

		_enemyRosterBox = new VBoxContainer { Name = "EnemyRoster" };
		_enemyRosterBox.AddThemeConstantOverride("separation", 5);
		vbox.AddChild(_enemyRosterBox);
	}

	// ════════════════════════════════════════════════════════════════════
	// Popups
	// ════════════════════════════════════════════════════════════════════

	private void BuildPopups()
	{
		_deckPopup = new PopupPanel { Name = "DeckPopup" };
		_deckList = new ItemList { Name = "DeckList" };
		_deckList.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
		_deckList.CustomMinimumSize = new Vector2(220, 300);
		_deckPopup.AddChild(_deckList);
		AddChild(_deckPopup);

		_gravePopup = new PopupPanel { Name = "GravePopup" };
		_graveList = new ItemList { Name = "GraveList" };
		_graveList.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
		_graveList.CustomMinimumSize = new Vector2(220, 300);
		_gravePopup.AddChild(_graveList);
		AddChild(_gravePopup);

		// V1: full combat-log history (ticker click).
		_logPopup = new PopupPanel { Name = "LogPopup" };
		_logHistoryList = new ItemList { Name = "LogHistoryList" };
		_logHistoryList.SetAnchorsAndOffsetsPreset(Control.LayoutPreset.FullRect);
		_logHistoryList.CustomMinimumSize = new Vector2(520, 420);
		_logPopup.AddChild(_logHistoryList);
		AddChild(_logPopup);
	}

	// ════════════════════════════════════════════════════════════════════
	// Public API — called by CombatManager
	// ════════════════════════════════════════════════════════════════════

	// ── Phase / hint ─────────────────────────────────────────────────────

	// Pending-replay (2026-07-09): phase/hint pushed before BuildUI used to
	// drop silently — skip-deploy launches showed a blank top banner all of
	// round 1 (RefreshPhaseUI fires from the handoff, pre-build; the next
	// re-push only comes at the round-2 phase change).
	private string _lastPhaseText;
	private string _lastHintText;

	public void SetPhaseText(string text)
	{
		_lastPhaseText = text;
		if (_phaseLabel != null)
			_phaseLabel.Text = text.ToUpper();
	}

	public void SetHintText(string text)
	{
		_lastHintText = text;
		if (_hintLabel != null)
			_hintLabel.Text = text;
	}

	// ── V3: the stack panel (§7c) — replaces the U3 interim prompt ─────────
	// Compact vertical strip, center-right above the hand: pending stack
	// objects top-down (source · name · one-line effect), resolving object
	// highlighted. Interactive only while the player holds priority; during
	// auto-pass it plays through with ZERO input.

	private PanelContainer _stackPanel;
	private VBoxContainer _stackList;
	private Button _stackPassBtn;

	private void EnsureStackPanel()
	{
		if (_stackPanel != null)
			return;

		_stackPanel = new PanelContainer
		{
			Name = "StackPanel",
			AnchorLeft = 1f, AnchorRight = 1f, AnchorTop = 1f, AnchorBottom = 1f,
			OffsetLeft = -12 - 320, OffsetRight = -12,
			OffsetTop = -12 - 380, OffsetBottom = -12 - 80,
			GrowHorizontal = Control.GrowDirection.Begin,
			GrowVertical = Control.GrowDirection.Begin,
			Visible = false,
		};
		_stackPanel.AddThemeStyleboxOverride("panel",
			UITheme.MakePanelStyle(UITheme.BgBase, UITheme.Gold));
		AddChild(_stackPanel);

		var margin = new MarginContainer();
		margin.AddThemeConstantOverride("margin_left", 8);
		margin.AddThemeConstantOverride("margin_right", 8);
		margin.AddThemeConstantOverride("margin_top", 6);
		margin.AddThemeConstantOverride("margin_bottom", 6);
		_stackPanel.AddChild(margin);

		var vbox = new VBoxContainer();
		vbox.AddThemeConstantOverride("separation", 4);
		margin.AddChild(vbox);

		var header = MakeLabel("─ THE STACK ─", UITheme.FontSizeSmall, UITheme.Gold);
		header.HorizontalAlignment = HorizontalAlignment.Center;
		vbox.AddChild(header);

		_stackList = new VBoxContainer { SizeFlagsVertical = Control.SizeFlags.ExpandFill };
		_stackList.AddThemeConstantOverride("separation", 3);
		vbox.AddChild(_stackList);

		_stackPassBtn = new Button { Text = "Pass", CustomMinimumSize = new Vector2(0, 32) };
		UITheme.ApplyButtonStyle(_stackPassBtn, isPrimary: true);
		_stackPassBtn.Pressed += () => EmitSignal(SignalName.PriorityPassPressed);
		vbox.AddChild(_stackPassBtn);
	}

	/// <summary>Renders the strip from top-of-stack down. <paramref name="items"/>
	/// = (source, name, effect); index 0 is the top (resolving next, highlighted).
	/// <paramref name="interactive"/> shows the Pass button (player holds priority);
	/// otherwise the strip is display-only and plays through with zero input.</summary>
	public void ShowStackStrip(List<(string source, string name, string effect)> items, bool interactive)
	{
		EnsureStackPanel();

		foreach (Node child in _stackList.GetChildren())
			child.QueueFree();

		for (int i = 0; i < items.Count; i++)
		{
			var (source, name, effect) = items[i];
			bool top = i == 0;

			var line1 = MakeLabel($"{name} — {source}", UITheme.FontSizeSmall,
				top ? UITheme.Gold : UITheme.TextSecondary);
			_stackList.AddChild(line1);

			if (!string.IsNullOrEmpty(effect))
			{
				var line2 = MakeLabel(effect, UITheme.FontSizeSmall - 1,
					top ? UITheme.TextPrimary : UITheme.TextDim);
				line2.AutowrapMode = TextServer.AutowrapMode.WordSmart;
				_stackList.AddChild(line2);
			}

			if (i < items.Count - 1)
				_stackList.AddChild(MakeDivider(UITheme.VioletDim));
		}

		_stackPassBtn.Visible = interactive;
		_stackPanel.Visible = items.Count > 0;
	}

	public void HideStackStrip()
	{
		if (_stackPanel != null)
			_stackPanel.Visible = false;
	}

	/// <summary>True while the strip is interactive — the Enter-to-end-turn guard
	/// reads this so Enter can never blind-pass a stack window.</summary>
	public bool StackWindowInteractive =>
		_stackPanel != null && _stackPanel.Visible && _stackPassBtn.Visible;

	// ── Deployment mode ──────────────────────────────────────────────────

	public void SetDeploymentMode(bool isDeployment)
	{
		_pendingDeploymentMode = isDeployment;
		_deploymentModePending = true;
		if (_endTurnButton != null)
			ApplyDeploymentMode();
	}

	private void ApplyDeploymentMode()
	{
		_endTurnButton.Text = _pendingDeploymentMode
			? "Confirm Deployment"
			: "End Turn";
		_deploymentModePending = false;
	}

	// ── Selected unit panel ──────────────────────────────────────────────

	public void ShowSelectedUnit(Unit unit, int mana)
	{
		if (_unitNameLabel == null)
		{
			_pendingUnit = unit;
			_pendingMana = mana;
			_unitPending = true;
			return;
		}
		_unitPending = false;
		ApplySelectedUnit(unit, mana);
	}

	private void ApplySelectedUnit(Unit unit, int mana)
	{
		if (_unitNameLabel == null)
			return;

		if (unit == null)
		{
			_unitNameLabel.Text = "—";
			_unitNameLabel.Modulate = UITheme.TextPrimary;
			if (_hpBar != null)
				SetBar(_hpBar, 1, 0, UITheme.StatBarHealth, UITheme.BgDeep);
			if (_mpBar != null)
				_mpBar.Visible = false;
			if (_mpText != null)
				_mpText.Visible = false;
			if (_statLine != null)
				_statLine.Text = "";
			if (_stanceLine != null)
				_stanceLine.Visible = false;
			ClearStatusIcons();
			RefreshInspectBlock(null, false);   // V2: hide enemy blocks
			return;
		}

		bool isEnemy = !unit.IsPlayerControlled;

		_unitNameLabel.Text = isEnemy ? $"[Enemy]  {unit.Name}" : unit.Name;
		_unitNameLabel.Modulate = isEnemy ? UITheme.Danger : UITheme.TextPrimary;

		float hpPct = unit.Stats.MaxHealth <= 0 ? 0f
			: Mathf.Clamp((float)unit.Stats.Health / unit.Stats.MaxHealth, 0f, 1f);
		Color hpCol = hpPct > 0.5f
			? UITheme.Success.Lerp(UITheme.Warning, (1f - hpPct) * 2f)
			: UITheme.Warning.Lerp(UITheme.Danger, (0.5f - hpPct) * 2f);
		SetBar(_hpBar, unit.Stats.MaxHealth, unit.Stats.Health, hpCol, UITheme.BgDeep);
		if (_hpText != null)
			_hpText.Text = $"{unit.Stats.Health}/{unit.Stats.MaxHealth}";

		bool hasMana = unit.Stats.MaxMana > 0;
		if (_mpBar != null)
			_mpBar.Visible = hasMana;
		if (_mpText != null)
			_mpText.Visible = hasMana;
		if (hasMana)
		{
			SetBar(_mpBar, unit.Stats.MaxMana, mana, UITheme.ArcaneBlue, UITheme.BgDeep);
			if (_mpText != null)
				_mpText.Text = $"{mana}/{unit.Stats.MaxMana}";
		}

		if (_statLine != null)
		{
			string apPips = "";
			if (!isEnemy)
				for (int i = 0; i < unit.MaxActionPoints; i++)
					apPips += i < unit.CurrentActionPoints ? "●" : "○";

			string armor = unit.Stats.Armor > 0 ? $"ARM {unit.Stats.Armor}  " : "";
			string shield = unit.Stats.Shield > 0 ? $"SHD {unit.Stats.Shield}  " : "";
			string ap = !isEnemy && unit.MaxActionPoints > 0 ? $"AP {apPips}  " : "";
			// SPD = the real per-move reach (MoveRange + movespeed grants, adjusted for
			// rooted/slowed) — the same value every movement path uses. Shows base→eff
			// when buffed/debuffed so Dash/Imbue/stance changes are visible.
			int spdEff = unit.EffectiveMoveRange;
			string spd = spdEff != unit.MoveRange
				? $"SPD {unit.MoveRange}→{spdEff}"
				: $"SPD {unit.MoveRange}";
			_statLine.Text = $"{armor}{shield}{ap}{spd}";
		}

		if (_stanceLine != null)
		{
			if (!isEnemy && unit.IsMartial && unit.ActiveStance != null)
			{
				_stanceLine.Text = $"[{unit.ActiveStance.DisplayName}]";
				_stanceLine.Visible = true;
			}
			else
			{
				_stanceLine.Visible = false;
			}
		}

		RefreshStatusIcons(unit.Stats.StatusEffects);
		RefreshInspectBlock(unit, isEnemy);
	}

	/// <summary>V2 (§7b): three enemy-only blocks — plain-language behavior line
	/// from BehaviorKey + tags, one block per ability (icon, name, intel), and
	/// the role/faction line. Strings live in UIContent — content, not code.</summary>
	private void RefreshInspectBlock(Unit unit, bool isEnemy)
	{
		if (_inspectBlock == null)
			return;

		foreach (Node child in _inspectBlock.GetChildren())
			child.QueueFree();

		if (!isEnemy)
		{
			_inspectBlock.Visible = false;
			return;
		}
		_inspectBlock.Visible = true;

		_inspectBlock.AddChild(MakeDivider(UITheme.VioletDim));

		// Behavior line — rules and reach, plain language.
		var behavior = MakeLabel(
			UIContent.DescribeBehavior(unit.BehaviorKey, unit.BehaviorTags),
			UITheme.FontSizeSmall, UITheme.TextSecondary);
		behavior.AutowrapMode = TextServer.AutowrapMode.WordSmart;
		_inspectBlock.AddChild(behavior);

		// One block per ability: icon + name, then the telegraph sentence.
		foreach (var ab in unit.Abilities)
		{
			var nameLine = MakeLabel(
				$"{UIContent.AbilityIcon(ab.Key)} {ab.Name}",
				UITheme.FontSizeSmall, UITheme.Gold);
			_inspectBlock.AddChild(nameLine);

			if (!string.IsNullOrEmpty(ab.IntelDescription))
			{
				var intel = MakeLabel(ab.IntelDescription, UITheme.FontSizeSmall, UITheme.TextDim);
				intel.AutowrapMode = TextServer.AutowrapMode.WordSmart;
				_inspectBlock.AddChild(intel);
			}
		}

		// Role · faction line ("Elite · The Long Table").
		string factionName = "";
		if (!string.IsNullOrEmpty(unit.FactionId)
			&& ArchmageRegistry.Get(unit.FactionId) is { } arch)
			factionName = arch.FactionName;

		string roleLine = string.IsNullOrEmpty(factionName)
			? UIContent.RoleDisplay(unit.Role)
			: $"{UIContent.RoleDisplay(unit.Role)} · {factionName}";
		var role = MakeLabel(roleLine, UITheme.FontSizeSmall,
			unit.Role == "elite" ? UITheme.RoleElite
			: unit.Role == "boss" ? UITheme.RoleBoss
			: UITheme.TextDim);
		role.HorizontalAlignment = HorizontalAlignment.Center;
		_inspectBlock.AddChild(role);
	}

	// ── Status icons ────────────────�