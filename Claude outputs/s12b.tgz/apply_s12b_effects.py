#!/usr/bin/env python3
# Slice 12b part 2: Enchanter effects (Maze of Mirrors, Puppeteer, The Architecture,
# Absolute Territory, Phase Shift, Glyph Warp, Rune Step, Dispel Walk, First Layer,
# Binding Chains' halving Name), registry, rules hooks. Repo root.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

def replace_class(rel, name, new_code):
    s = open(rel, encoding='utf-8').read()
    key = f"public sealed class {name}"
    if s.count(key) != 1:
        sys.exit(f"{rel}: class {name} found {s.count(key)} times")
    start = s.index(key)
    doc = s.rfind("\n/// <summary>", 0, start)
    gap = s[doc:start]
    if doc != -1 and "\n}\n" not in gap and "\npublic " not in gap:
        start = doc + 1
    end = s.index("\n}\n", s.index(key)) + 3
    s = s[:start] + new_code.strip("\n") + "\n" + s[end:]
    open(rel, 'w', encoding='utf-8').write(s)
    print("replaced", name, "in", rel)

E = 'Scripts/Cards/Effects/EnchanterEffects.cs'

replace_class(E, "SwapUnitsEffect", r'''
/// <summary>
/// Swap the positions of two units. Two-step targeting gives [first unit, second unit's
/// tile]. Each lands on the other's tile as a teleport, so glyphs there go off. Phase
/// Shift upgrades hurt and/or Name every enemy it moved.
/// JSON: { "type":"swap_units", "with_caster": bool, "damage_enemies": n, "name_enemy": bool }
/// </summary>
public sealed class SwapUnitsEffect : EffectBase
{
	/// <summary>Bolt-Hole mode (2026-07-29): with a single targeted unit, swap it
	/// with the CASTER instead of failing.</summary>
	public bool WithCaster;
	public int DamageEnemies;
	public bool NameEnemies;

	public SwapUnitsEffect(bool withCaster = false, int damageEnemies = 0, bool nameEnemies = false)
	{ WithCaster = withCaster; DamageEnemies = damageEnemies; NameEnemies = nameEnemies; }

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var units = new List<Unit>();
		if (targets?.Items != null)
			foreach (var o in targets.Items)
			{ var u = ResolveTargetUnit(s, o); if (u != null && !units.Contains(u)) units.Add(u); }
		var me = s.ActiveCasterUnit;
		if (units.Count == 1 && WithCaster && me != null && me != units[0])
			units.Insert(0, me);
		if (units.Count < 2)
		{ s.Log("[SwapUnits] need two units."); return; }
		var a = units[0];
		var b = units[1];
		var ta = a.CurrentTile;
		var tb = b.CurrentTile;
		if (ta == null || tb == null)
			return;
		// Clear both first so neither placement finds its destination occupied.
		a.PlaceOnTile(tb, MovementKind.Teleport);
		b.PlaceOnTile(ta, MovementKind.Teleport);
		s.Log($"[SwapUnits] swapped {a.Name} and {b.Name}.");

		int team = me?.TeamId ?? 0;
		foreach (var u in new[] { a, b })
		{
			if (u == null || !GodotObject.IsInstanceValid(u) || !u.Stats.IsAlive || u.TeamId == team)
				continue;
			if (DamageEnemies > 0)
				u.ApplyDamage(DamageEnemies);
			if (NameEnemies && u.Stats.IsAlive)
				u.ApplyStatus("named", 1);
		}
	}
}
''')

replace_class(E, "SwapGlyphsEffect", r'''
/// <summary>Swap two of your glyphs (tile then tile), optionally triggering both after,
/// each with bonus damage, or every glyph you control. Weave per glyph triggered.
/// { "type":"swap_glyphs", "trigger_after": bool, "bonus": n, "trigger_all_after": bool, "on_trigger_weave": n }</summary>
public sealed class SwapGlyphsEffect : EffectBase
{
	public bool TriggerAfter, TriggerAllAfter;
	public int Bonus, WeavePerGlyph;

	public SwapGlyphsEffect(bool triggerAfter = false, int bonus = 0, bool triggerAll = false, int weavePerGlyph = 0)
	{ TriggerAfter = triggerAfter; Bonus = bonus; TriggerAllAfter = triggerAll; WeavePerGlyph = weavePerGlyph; }

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		if (s?.Glyphs == null || targets?.Items == null)
			return;
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		var tiles = targets.Items.Select(o => InterfaceHelpers.ResolveTile(s, o)).Where(t => t != null).Distinct().ToList();
		if (tiles.Count < 2)
		{ s.Log("[SwapGlyphs] need two tiles."); return; }
		s.Glyphs.Swap(tiles[0], tiles[1]);
		s.Log("[SwapGlyphs] two glyphs trade places.");

		int fired = 0;
		if (TriggerAllAfter && owner != null)
			fired = s.Glyphs.TriggerAll(s, owner.TeamId, Bonus, consume: true);
		else if (TriggerAfter)
		{
			fired += s.Glyphs.TriggerTile(s, tiles[0], Bonus) ? 1 : 0;
			fired += s.Glyphs.TriggerTile(s, tiles[1], Bonus) ? 1 : 0;
		}
		if (WeavePerGlyph > 0 && fired > 0 && owner?.Attunement is WeaveAttunement w)
			w.Add(WeavePerGlyph * fired);
	}
}
''')

replace_class(E, "TeleportToGlyphEffect", r'''
/// <summary>Teleport the caster onto one of their glyphs: the targeted tile when it holds
/// one, else the nearest. Optionally set it off on arrival; "refresh" keeps it (re-armed)
/// even if it is single use.
/// { "type":"teleport_to_glyph", "trigger_on_arrive": bool, "refresh": bool }</summary>
public sealed class TeleportToGlyphEffect : EffectBase
{
	public bool TriggerOnArrive, Refresh;
	public TeleportToGlyphEffect(bool trigger, bool refresh = false) { TriggerOnArrive = trigger; Refresh = refresh; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var c = FindCasterUnit(s, caster);
		if (s?.Glyphs == null || c == null)
			return;
		TileData tile = null;
		if (targets?.Items != null && targets.Items.Count > 0)
		{
			var t = InterfaceHelpers.ResolveTile(s, targets.Items[0]);
			if (t?.Glyph != null && t.Glyph.OwnerTeam == c.TeamId)
				tile = t;
		}
		tile ??= s.Glyphs.NearestFriendly(c.TeamId, c.CurrentTile?.Axial ?? default);
		if (tile == null)
		{ s.Log("[TeleportToGlyph] no friendly glyph."); return; }
		if (tile.Occupant != null && tile.Occupant != c)
		{ s.Log("[TeleportToGlyph] that glyph is occupied."); return; }
		var glyph = tile.Glyph;
		c.PlaceOnTile(tile, MovementKind.Teleport);
		s.Log($"[TeleportToGlyph] {c.Name} steps onto a glyph.");
		if (TriggerOnArrive && glyph != null && tile.Glyph == glyph)
		{
			glyph.Fire(c, s);                 // caster is friendly: ally payload and payoffs
			bool keep = s.Glyphs.OnGlyphFired(s, tile, c);
			if (!keep && !Refresh)
				s.Glyphs.Remove(tile);
			else if (Refresh)
				glyph.Consumed = false;
		}
	}
}
''')

replace_class(E, "SummonIllusionEffect", r'''
/// <summary>
/// Maze of Mirrors: Count mirror copies of the caster on empty tiles nearby, each with Hp
/// health and Attack damage, lasting Duration turns (99 = the rest of the fight). While
/// copies stand, an enemy that picks the caster picks the caster or a copy at random
/// (CombatManager.FindTargetOverride). A copy that is hit can turn the blow back
/// (reflect_on_hit); a destroyed copy sets off the glyph under it.
/// JSON: { "type":"summon_illusion", "count":n, "hp":n, "duration":n, "copies_attack":n,
///         "reflect_on_hit":bool, "trigger_glyph_on_death":bool }
/// </summary>
public sealed class SummonIllusionEffect : EffectBase
{
	public int Count, Hp, Duration, Attack;
	public bool ReflectOnHit, TriggerGlyphOnDeath;

	public SummonIllusionEffect(int count, int hp, int duration, int attack, bool reflect, bool triggerGlyph)
	{
		Count = Math.Max(1, count); Hp = Math.Max(1, hp); Duration = Math.Max(1, duration);
		Attack = Math.Max(0, attack); ReflectOnHit = reflect; TriggerGlyphOnDeath = triggerGlyph;
	}

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		if (s.OnSummonRequested == null)
		{ s.Log("[SummonIllusion] No summon handler."); return; }
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (owner?.CurrentTile == null || s.Grid == null)
			return;

		var spots = s.Grid.Tiles.Values
			.Where(t => t != null && !t.IsBlocked && !t.IsOccupied && t.IsWalkable
						&& s.Grid.Distance(owner.CurrentTile.Axial, t.Axial) <= 2)
			.OrderBy(t => s.Grid.Distance(owner.CurrentTile.Axial, t.Axial))
			.ThenBy(t => t.Axial.X).ThenBy(t => t.Axial.Y)
			.Take(Count)
			.ToList();
		int made = 0;
		foreach (var spot in spots)
		{
			var copy = s.OnSummonRequested("Illusion", spot, owner.TeamId);
			if (copy == null)
				continue;
			copy.Stats.MaxHealth = Hp;
			copy.Stats.Health = Hp;
			copy.AttackDamage = Attack;
			copy.IllusionOwner = owner;
			copy.IllusionTurnsLeft = Duration >= 99 ? -1 : Duration;
			copy.ApplyStatus("illusion", Duration >= 99 ? 999 : Duration);
			copy.RefreshHealthBar();
			if (!s.UnitsInPlay.Contains(copy))
				s.UnitsInPlay.Add(copy);

			var me = copy;
			if (ReflectOnHit)
				me.OnAttacked += (target, source, amount) =>
				{
					if (source == null || !GodotObject.IsInstanceValid(source) || source == target
						|| !source.Stats.IsAlive || source.TeamId == target.TeamId || amount <= 0)
						return;
					source.ApplyDamage(amount);
					GD.Print($"[Mirror] {target.Name} turns {amount} back on {source.Name}.");
				};
			if (TriggerGlyphOnDeath)
				me.OnDied += dead =>
				{
					var tile = dead?.CurrentTile;
					if (tile?.Glyph == null || s?.Glyphs == null)
						return;
					if (s.Glyphs.TriggerTile(s, tile, 0))
						s.Log($"[Mirror] {dead.Name} shatters and sets off the glyph beneath it.");
				};
			made++;
		}
		s.Log($"[SummonIllusion] {made} mirror cop{(made == 1 ? "y" : "ies")} of {owner.Name} ({Hp} HP).");
	}
}
''')

replace_class(E, "GrandDesignPassiveLeafEffect", r'''
/// <summary>
/// The Architecture: for the rest of the fight, each glyph the caster prepares is also
/// prepared on every tile within SpreadRadius, glyph spells cost GlyphCostReduction less,
/// preparing banks WeavePerPrepare, and glyphs hit TriggerCount times as hard. Casting it
/// again keeps the strongest of each value.
/// JSON: { "type":"grand_design_passive", "spread_radius":n, "trigger_count":n,
///         "glyph_cost_reduction":n, "weave_per_prepare":n }
/// </summary>
public sealed class GrandDesignPassiveLeafEffect : EffectBase
{
	public int SpreadRadius, TriggerCount, GlyphCostReduction, WeavePerPrepare;
	public GrandDesignPassiveLeafEffect(int spread, int triggerCount, int costReduction, int weavePerPrepare)
	{ SpreadRadius = spread; TriggerCount = Math.Max(1, triggerCount); GlyphCostReduction = costReduction; WeavePerPrepare = weavePerPrepare; }

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var unit = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		s.ActiveEffects ??= new List<PersistentEffect>();
		var gd = s.GetActiveEffect<GrandDesignPersistentEffect>(caster);
		if (gd == null)
		{
			gd = new GrandDesignPersistentEffect(GrandDesignPersistentEffect.RestOfFight, caster, unit);
			s.ActiveEffects.Add(gd);
		}
		gd.SpreadRadius = Math.Max(gd.SpreadRadius, SpreadRadius);
		gd.TriggerCount = Math.Max(gd.TriggerCount, TriggerCount);
		gd.GlyphCostReduction = Math.Max(gd.GlyphCostReduction, GlyphCostReduction);
		gd.WeavePerPrepare = Math.Max(gd.WeavePerPrepare, WeavePerPrepare);
		s.Log($"[Architecture] For the rest of the fight: glyphs spread {gd.SpreadRadius}, hit x{gd.TriggerCount}"
			  + (gd.GlyphCostReduction > 0 ? $", glyph spells cost {gd.GlyphCostReduction} less" : "")
			  + (gd.WeavePerPrepare > 0 ? $", +{gd.WeavePerPrepare} Weave per glyph prepared." : "."));
	}
}
''')

replace_class(E, "AbsoluteTerritoryLeafEffect", r'''
/// <summary>
/// Absolute Territory: a zone of Radius around the caster for Turns (99 = rest of fight).
/// Enemies inside deal half damage, take DamagePerTile for every tile they walk in it, and
/// cannot teleport into or out of it; with NameEnemies they are also Named each round.
/// JSON: { "type":"absolute_territory", "radius":n, "damage_per_tile":n, "duration":n, "name_enemies":bool }
/// </summary>
public sealed class AbsoluteTerritoryLeafEffect : EffectBase
{
	public int Radius, DamagePerTile, Turns;
	public bool NameEnemies;

	public AbsoluteTerritoryLeafEffect(int r, int perTile, int turns, bool nameEnemies)
	{ Radius = r; DamagePerTile = perTile; Turns = turns; NameEnemies = nameEnemies; }

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var unit = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		var center = unit?.CurrentTile?.Axial ?? default;
		s.ActiveEffects ??= new List<PersistentEffect>();
		var zone = new AbsoluteTerritoryZone(center, Radius, DamagePerTile, Turns >= 99 ? AbsoluteTerritoryZone.RestOfFight : Turns,
											 caster, unit) { NameEnemies = NameEnemies };
		s.ActiveEffects.Add(zone);
		if (NameEnemies)
			zone.NameInside(s);
		s.Log($"[AbsoluteTerritory] r={Radius} around {center}: enemies deal half, take {DamagePerTile} per tile walked"
			  + (NameEnemies ? ", and are Named." : "."));
	}
}

/// <summary>
/// Puppeteer: for Turns, at each round's start every enemy walks (walked rules, so glyphs
/// fire) up to Tiles toward its nearest glyph of the caster's, or toward the caster when
/// there are none; with NameControlled it is Named until the next round.
/// JSON: { "type":"puppeteer", "turns":n, "move_tiles":n, "name_controlled":bool }
/// </summary>
public sealed class PuppeteerEffect : EffectBase
{
	public int Turns, Tiles;
	public bool NameControlled;
	public PuppeteerEffect(int turns, int tiles, bool nameControlled)
	{ Turns = Math.Max(1, turns); Tiles = Math.Max(1, tiles); NameControlled = nameControlled; }

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var unit = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		s.ActiveEffects ??= new List<PersistentEffect>();
		s.ActiveEffects.Add(new PuppeteerAura(Turns, Tiles, NameControlled, caster, unit));
		s.Log($"[Puppeteer] For {Turns} turn(s), enemies walk up to {Tiles} toward your glyphs each round.");
	}
}

/// <summary>Dispel Walk: strips buffs from every enemy beside the caster now, and from each
/// enemy the caster walks past for the rest of this round (CombatManager.Enchanter watches
/// the caster's steps). Each enemy is touched once per cast.
/// JSON: { "type":"dispel_walk", "count":n, "steal":bool }</summary>
public sealed class DispelWalkEffect : EffectBase
{
	public int Count; public bool Steal;
	public DispelWalkEffect(int count, bool steal) { Count = Math.Max(1, count); Steal = steal; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var c = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (c == null)
			return;
		c.DispelWalkRound = Names.Round;
		c.DispelWalkCount = Count;
		c.DispelWalkSteal = Steal;
		c.DispelWalkTouched.Clear();
		DispelEffect.DispelAdjacent(s, c);
	}
}

/// <summary>First Layer (§4): two enemies' locked attack tiles trade places.
/// JSON: { "type":"swap_locks" }, targeting unit_then_unit (enemies).</summary>
public sealed class SwapLocksEffect : EffectBase
{
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var units = new List<Unit>();
		if (targets?.Items != null)
			foreach (var o in targets.Items)
			{ var u = ResolveTargetUnit(s, o); if (u != null && !units.Contains(u)) units.Add(u); }
		if (units.Count < 2)
		{ s.Log("[SwapLocks] need two enemies."); return; }
		string err = IntentTime.SwapLocks(units[0], units[1]);
		if (err != null)
			s.Log($"[SwapLocks] {err}.");
	}
}
''')

replace_class(E, "GrandDesignPersistentEffect", r'''
public sealed class GrandDesignPersistentEffect : PersistentEffect
{
    /// <summary>Turns value used for "the rest of the fight": never ticks down.</summary>
    public const int RestOfFight = 9999;

    public Unit OwnerUnit;
    public int SpreadRadius;
    public int TriggerCount = 2;
    public int GlyphCostReduction;
    public int WeavePerPrepare;

    public GrandDesignPersistentEffect(int turns, Entity owner, Unit ownerUnit)
    {
        TurnsRemaining = turns;
        Owner = owner;
        OwnerUnit = ownerUnit;
    }

    public override void Tick(GameState s)
    {
        if (TurnsRemaining < RestOfFight)
            TurnsRemaining--;
    }

    /// <summary>The Architecture active for <paramref name="team"/>, or null.</summary>
    public static GrandDesignPersistentEffect For(GameState s, int team) =>
        s?.ActiveEffects?.OfType<GrandDesignPersistentEffect>()
            .Where(e => !e.IsExpired && e.OwnerUnit != null && e.OwnerUnit.TeamId == team)
            .OrderByDescending(e => e.TriggerCount)
            .FirstOrDefault();
}
''')

replace_class(E, "AbsoluteTerritoryZone", r'''
public sealed class AbsoluteTerritoryZone : PersistentEffect
{
    public const int RestOfFight = 9999;

    public Vector2I Center;
    public int Radius, DamagePerTile;
    public bool NameEnemies;
    public Unit OwnerUnit;

    public AbsoluteTerritoryZone(Vector2I center, int radius, int perTile, int turns,
        Entity owner, Unit ownerUnit)
    {
        Center = center;
        Radius = radius;
        DamagePerTile = perTile;
        TurnsRemaining = turns;
        Owner = owner;
        OwnerUnit = ownerUnit;
    }

    public override void Tick(GameState s)
    {
        if (TurnsRemaining < RestOfFight)
            TurnsRemaining--;
        if (NameEnemies && !IsExpired)
            NameInside(s);
    }

    public bool Contains(GameState s, Vector2I at) => s?.Grid != null && s.Grid.Distance(Center, at) <= Radius;

    /// <summary>Is <paramref name="u"/> an enemy of this zone's owner?</summary>
    public bool IsEnemy(Unit u) => u != null && OwnerUnit != null && u.TeamId != OwnerUnit.TeamId;

    public void NameInside(GameState s)
    {
        if (s?.UnitsInPlay == null)
            return;
        foreach (var u in s.UnitsInPlay)
            if (u != null && GodotObject.IsInstanceValid(u) && u.Stats.IsAlive && u.CurrentTile != null
                && IsEnemy(u) && Contains(s, u.CurrentTile.Axial))
                u.ApplyStatus("named", 1);
    }

    /// <summary>An active zone that holds <paramref name="at"/> and opposes <paramref name="u"/>.</summary>
    public static AbsoluteTerritoryZone Holding(GameState s, Unit u, Vector2I at) =>
        s?.ActiveEffects?.OfType<AbsoluteTerritoryZone>()
            .FirstOrDefault(z => !z.IsExpired && z.IsEnemy(u) && z.Contains(s, at));

    /// <summary>True when a teleport by <paramref name="u"/> to <paramref name="dest"/> starts
    /// or ends inside an opposing zone.</summary>
    public static bool BlocksTeleport(GameState s, Unit u, Vector2I dest) =>
        u?.CurrentTile != null && (Holding(s, u, u.CurrentTile.Axial) != null || Holding(s, u, dest) != null);
}

/// <summary>Puppeteer's round-start walk. Ticks once per round at the player's turn start,
/// before the enemies act.</summary>
public sealed class PuppeteerAura : PersistentEffect
{
    public Unit OwnerUnit;
    public int Tiles;
    public bool NameControlled;

    public PuppeteerAura(int turns, int tiles, bool nameControlled, Entity owner, Unit ownerUnit)
    {
        TurnsRemaining = turns;
        Tiles = tiles;
        NameControlled = nameControlled;
        Owner = owner;
        OwnerUnit = ownerUnit;
    }

    public override void Tick(GameState s)
    {
        TurnsRemaining--;
        if (s?.Grid == null || OwnerUnit == null || !GodotObject.IsInstanceValid(OwnerUnit))
            return;
        int team = OwnerUnit.TeamId;
        foreach (var e in s.UnitsInPlay.ToList())
        {
            if (e == null || !GodotObject.IsInstanceValid(e) || !e.Stats.IsAlive || e.CurrentTile == null || e.TeamId == team)
                continue;
            var goal = s.Glyphs?.NearestFriendly(team, e.CurrentTile.Axial)?.Axial
                       ?? OwnerUnit.CurrentTile?.Axial;
            if (goal == null)
                continue;
            bool onto = s.Glyphs?.NearestFriendly(team, e.CurrentTile.Axial) != null;
            var path = CompelWalk.Plan(s.Grid, e, Tiles, goal, null, onto);
            int walked = CompelWalk.Walk(s.Grid, e, path, s.Log);
            if (walked > 0)
                s.Log($"[Puppeteer] {e.Name} is walked {walked} tile(s).");
            if (NameControlled && e.Stats.IsAlive)
                e.ApplyStatus("named", 1);
        }
    }
}
''')

# Dispel: a shared helper for Dispel Walk.
edit(E, [
("""public sealed class DispelEffect : EffectBase
{
	public int Count; public bool Steal;
	public DispelEffect(int count, bool steal) { Count = count; Steal = steal; }""",
"""public sealed class DispelEffect : EffectBase
{
	public int Count; public bool Steal;
	public DispelEffect(int count, bool steal) { Count = count; Steal = steal; }

	/// <summary>Strips up to <paramref name="count"/> buffs from <paramref name="victim"/>,
	/// handing them to <paramref name="thief"/> when stealing. Returns how many.</summary>
	public static int Strip(Unit victim, Unit thief, int count, bool steal)
	{
		if (victim?.Stats?.StatusEffects == null)
			return 0;
		var buffs = victim.Stats.StatusEffects.Where(kv => !InterfaceHelpers.Debuffs.Contains(kv.Key))
											 .Select(kv => (kv.Key, kv.Value)).Take(count).ToList();
		foreach (var (name, dur) in buffs)
		{
			victim.RemoveStatus(name);
			if (steal && thief != null)
				thief.ApplyStatus(name, dur);
		}
		return buffs.Count;
	}

	/// <summary>Dispel Walk step: every enemy beside <paramref name="walker"/> it has not
	/// touched this cast loses its buffs.</summary>
	public static void DispelAdjacent(GameState s, Unit walker)
	{
		if (walker?.CurrentTile == null || s?.Grid == null || walker.DispelWalkRound != Names.Round)
			return;
		foreach (var n in s.Grid.GetNeighbors(walker.CurrentTile.Axial))
		{
			var e = s.Grid.GetTile(n)?.Occupant;
			if (e == null || !GodotObject.IsInstanceValid(e) || !e.Stats.IsAlive || e.TeamId == walker.TeamId
				|| walker.DispelWalkTouched.Contains(e))
				continue;
			walker.DispelWalkTouched.Add(e);
			int k = Strip(e, walker, walker.DispelWalkCount, walker.DispelWalkSteal);
			if (k > 0)
				s.Log($"[DispelWalk] {walker.Name} {(walker.DispelWalkSteal ? "steals" : "strips")} {k} buff(s) from {e.Name}.");
		}
	}"""),
])

# Names: Binding Chains' halving condition.
edit('Scripts/Cards/Effects/EnchanterEngine.cs', [
("""    /// <summary>Mana the Namer gains on each break (Mana Tithe's refund).</summary>
    public int OwnerMana;""",
"""    /// <summary>Mana the Namer gains on each break (Mana Tithe's refund).</summary>
    public int OwnerMana;
    /// <summary>Binding Chains (§4): an attack by the Named unit deals half damage.</summary>
    public bool HalveAttack;"""),
("""    /// <summary>Payoffs to the Namer on each break (Mana Tithe).</summary>
    public int OwnerMana, OwnerWeave;""",
"""    /// <summary>Payoffs to the Namer on each break (Mana Tithe).</summary>
    public int OwnerMana, OwnerWeave;
    /// <summary>The Named unit's attacks are halved (Binding Chains).</summary>
    public bool HalveAttack;"""),
("""                OwnerMana = OwnerMana,
                OwnerWeave = OwnerWeave,
            }, s.Log);""",
"""                OwnerMana = OwnerMana,
                OwnerWeave = OwnerWeave,
                HalveAttack = HalveAttack,
            }, s.Log);"""),
# Plan can walk ONTO a goal (Puppeteer's glyph), not just beside it.
("""    public static List<Vector2I> Plan(HexGridManager grid, Unit victim, int tiles,
                                      Vector2I? towards, Vector2I? direction)
    {""",
"""    public static List<Vector2I> Plan(HexGridManager grid, Unit victim, int tiles,
                                      Vector2I? towards, Vector2I? direction, bool onto = false)
    {"""),
("""                int here = grid.Distance(cur.Axial, towards.Value);
                if (here <= 1)
                    break;""",
"""                int here = grid.Distance(cur.Axial, towards.Value);
                if (here <= (onto ? 0 : 1))
                    break;"""),
])

edit('Scripts/UI/StatusCatalog.cs', [
("""            string words = name.TriggerWords();
            var info = new StatusInfo($"If it {words}: {name.Damage}",
                                      $"IF {words.ToUpperInvariant().Replace(" OR ", "/").Replace(", ", "/")}: {name.Damage}",
                                      StatusTone.Mark,
                                      $"Named by {name.Source}: if it {words}, it takes {name.Damage} damage (once a round). {{n}} turn(s) left.");""",
"""            string words = name.TriggerWords();
            string half = name.HalveAttack ? ", half" : "";
            var info = new StatusInfo($"If it {words}: {name.Damage}{half}",
                                      $"IF {words.ToUpperInvariant().Replace(" OR ", "/").Replace(", ", "/")}: {name.Damage}{half.ToUpperInvariant()}",
                                      StatusTone.Mark,
                                      $"Named by {name.Source}: if it {words}, it takes {name.Damage} damage (once a round)"
                                      + (name.HalveAttack ? ", and its attacks deal half damage" : "")
                                      + ". {n} turn(s) left.");"""),
])

# Unit fields.
edit('Scripts/Systems/Combat/Core/Unit.cs', [
("""    public int NextSpellBonusDamage = 0;
""",
"""    public int NextSpellBonusDamage = 0;

    /// <summary>Maze of Mirrors: the unit this copy mirrors (null for a real unit).</summary>
    public Unit IllusionOwner;
    /// <summary>Turns left before this copy fades; -1 lasts the fight. Ticked by CombatManager.</summary>
    public int IllusionTurnsLeft = -1;

    /// <summary>Dispel Walk: the round it was cast, how many buffs per enemy, whether
    /// they are stolen, and which enemies this cast has already touched.</summary>
    public int DispelWalkRound = -1;
    public int DispelWalkCount;
    public bool DispelWalkSteal;
    public readonly HashSet<Unit> DispelWalkTouched = new();
"""),
])

# Registry.
G = 'Scripts/Cards/Loader/CardScriptRegistry.Enchanter.cs'
edit(G, [
("""        RegisterEffect("swap_glyphs", _ => new SwapGlyphsEffect().WithTag("Glyph"));""",
"""        RegisterEffect("swap_glyphs", n =>
        {
            bool after = n.TryGetProperty("trigger_after", out var ta) && ta.ValueKind == JsonValueKind.True;
            int bonus = n.TryGetProperty("bonus", out var b) ? b.GetInt32() : 0;
            bool all = n.TryGetProperty("trigger_all_after", out var tl) && tl.ValueKind == JsonValueKind.True;
            int weave = n.TryGetProperty("on_trigger_weave", out var w) ? w.GetInt32() : 0;
            return new SwapGlyphsEffect(after, bonus, all, weave).WithTag("Glyph");
        });"""),
("""            bool trigger = n.TryGetProperty("trigger_on_arrive", out var t) && t.GetBoolean();
            return new TeleportToGlyphEffect(trigger).WithTag("Movement");""",
"""            bool trigger = n.TryGetProperty("trigger_on_arrive", out var t) && t.GetBoolean();
            bool refresh = n.TryGetProperty("refresh", out var rf) && rf.ValueKind == JsonValueKind.True;
            return new TeleportToGlyphEffect(trigger, refresh).WithTag("Movement");"""),
("""            bool withCaster = n.TryGetProperty("with_caster", out var w) && w.GetBoolean();
            return new SwapUnitsEffect(withCaster).WithTag("Movement");""",
"""            bool withCaster = n.TryGetProperty("with_caster", out var w) && w.GetBoolean();
            int dmg = n.TryGetProperty("damage_enemies", out var d) ? d.GetInt32() : 0;
            bool name = n.TryGetProperty("name_enemy", out var ne) && ne.ValueKind == JsonValueKind.True;
            return new SwapUnitsEffect(withCaster, dmg, name).WithTag("Movement");
        });

        // Dispel Walk: { "type": "dispel_walk", "count": n, "steal": bool }
        RegisterEffect("dispel_walk", n =>
        {
            int count = n.TryGetProperty("count", out var c) ? c.GetInt32() : 1;
            bool steal = n.TryGetProperty("steal", out var st) && st.ValueKind == JsonValueKind.True;
            return new DispelWalkEffect(count, steal).WithTag("Control");
        });

        // First Layer: { "type": "swap_locks" } with unit_then_unit targeting.
        RegisterEffect("swap_locks", _ => new SwapLocksEffect().WithTag("Control"));

        // Puppeteer: { "type": "puppeteer", "turns": n, "move_tiles": n, "name_controlled": bool }
        RegisterEffect("puppeteer", n =>
        {
            int turns = n.TryGetProperty("turns", out var t) ? t.GetInt32() : 2;
            int tiles = n.TryGetProperty("move_tiles", out var mt) ? mt.GetInt32() : 2;
            bool name = n.TryGetProperty("name_controlled", out var nc) && nc.ValueKind == JsonValueKind.True;
            return new PuppeteerEffect(turns, tiles, name).WithTag("Movement");"""),
("""            int dmg = n.TryGetProperty("damage", out var dm) ? dm.GetInt32() : 4;
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 2;
            return new NameConditionEffect(trig, dmg, dur).WithTag("Control");""",
"""            int dmg = n.TryGetProperty("damage", out var dm) ? dm.GetInt32() : 4;
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 2;
            bool halve = n.TryGetProperty("halve_attack", out var ha) && ha.ValueKind == System.Text.Json.JsonValueKind.True;
            return new NameConditionEffect(trig, dmg, dur) { HalveAttack = halve }.WithTag("Control");"""),
])

# Registry: replace the three legacy builders by key.
s = open(G, encoding='utf-8').read()
def replace_reg(s, key, body):
    k = f'RegisterEffect("{key}", n =>'
    if s.count(k) != 1:
        sys.exit(f"registry {key} found {s.count(k)}")
    a = s.index(k)
    b = s.index("\n        });", a) + len("\n        });")
    return s[:a] + body.strip() + s[b:]
s = replace_reg(s, "summon_illusion", '''RegisterEffect("summon_illusion", n =>
        {
            int Geti(string k, int d) => n.TryGetProperty(k, out var v) ? v.GetInt32() : d;
            bool Getb(string k) => n.TryGetProperty(k, out var v) && v.ValueKind == JsonValueKind.True;
            return new SummonIllusionEffect(Geti("count", 1), Geti("hp", 4), Geti("duration", 3),
                Geti("copies_attack", 0), Getb("reflect_on_hit"), Getb("trigger_glyph_on_death")).WithTag("Summon");
        });''')
s = replace_reg(s, "grand_design_passive", '''RegisterEffect("grand_design_passive", n =>
        {
            int Geti(string k, int d) => n.TryGetProperty(k, out var v) ? v.GetInt32() : d;
            return new GrandDesignPassiveLeafEffect(Geti("spread_radius", 0), Geti("trigger_count", 2),
                Geti("glyph_cost_reduction", 0), Geti("weave_per_prepare", 0)).WithTag("Glyph");
        });''')
s = replace_reg(s, "absolute_territory", '''RegisterEffect("absolute_territory", n =>
        {
            int Geti(string k, int d) => n.TryGetProperty(k, out var v) ? v.GetInt32() : d;
            bool name = n.TryGetProperty("name_enemies", out var ne) && ne.ValueKind == JsonValueKind.True;
            return new AbsoluteTerritoryLeafEffect(Geti("radius", 3), Geti("damage_per_tile", 2),
                Geti("duration", 2), name).WithTag("Control");
        });''')
open(G, 'w', encoding='utf-8').write(s)
print("patched", G, "(summon_illusion, grand_design_passive, absolute_territory)")

# GlyphData: hit x TriggerCount under The Architecture.
edit('Scripts/Systems/Combat/Glyphs/GlyphData.cs', [
("""        if (s?.ActiveEffects != null && OwnerTeam >= 0)
        {
            bool grandDesign = s.ActiveEffects.Any(e =>
                e is GrandDesignPersistentEffect gd &&
                gd.OwnerUnit?.TeamId == OwnerTeam &&
                !e.IsExpired);
            if (grandDesign)
                dmg *= 2;
        }
        return dmg;""",
"""        if (s?.ActiveEffects != null && OwnerTeam >= 0)
        {
            var arch = GrandDesignPersistentEffect.For(s, OwnerTeam);
            if (arch != null)
                dmg *= Math.Max(1, arch.TriggerCount);
        }
        return dmg;"""),
])

# GlyphManager: Architecture spread + Weave, and a single-tile trigger helper.
edit('Scripts/Systems/Combat/Glyphs/GlyphManager.cs', [
("""        // A ward prepared under an ally (Sanctuary around you) covers them at once;
        // nobody should have to step off and back on.""",
"""        // The Architecture: the same glyph on every tile within its spread, and Weave
        // banked per glyph the caster prepares. Copies do not spread again.
        if (stampFromCast && owner != null && !_spreading && _state != null)
        {
            var arch = GrandDesignPersistentEffect.For(_state, owner.TeamId);
            if (arch != null)
            {
                if (arch.WeavePerPrepare > 0 && owner.Attunement is WeaveAttunement aw)
                    aw.Add(arch.WeavePerPrepare);
                if (arch.SpreadRadius > 0 && _grid != null)
                {
                    _spreading = true;
                    try
                    {
                        foreach (var t in _grid.Tiles.Values.ToList())
                        {
                            if (t == tile || t.Glyph != null || t.IsBlocked)
                                continue;
                            if (_grid.Distance(tile.Axial, t.Axial) > arch.SpreadRadius)
                                continue;
                            Prepare(t, owner, configure, stampFromCast);
                        }
                    }
                    finally { _spreading = false; }
                }
            }
        }

        // A ward prepared under an ally (Sanctuary around you) covers them at once;
        // nobody should have to step off and back on."""),
("""    // ── Wards: auras by position (slice 12a) ─────────────────────────""",
"""    private bool _spreading;

    /// <summary>Sets off the glyph on one tile: on the enemy standing there, or for its
    /// owner's payoffs when nobody is. Handles links, cascades and removal. Returns true
    /// when a glyph was there to fire.</summary>
    public bool TriggerTile(GameState s, TileData tile, int bonus)
    {
        var g = tile?.Glyph;
        if (g == null)
            return false;
        var occ = tile.Occupant;
        var who = occ != null && GodotObject.IsInstanceValid(occ) && occ.Stats.IsAlive ? occ : null;
        g.Fire(who, s, bonus);
        if (!OnGlyphFired(s, tile, who))
            Remove(tile);
        return true;
    }

    /// <summary>The Architecture's discount on a glyph spell for <paramref name="u"/>.</summary>
    public static int ArchitectureDiscount(GameState s, Unit u, CardHalf half)
    {
        if (u == null || half == null || !HalfPreparesGlyph(half))
            return 0;
        return GrandDesignPersistentEffect.For(s, u.TeamId)?.GlyphCostReduction ?? 0;
    }

    /// <summary>True when the half's effect tree prepares a glyph on the board.</summary>
    public static bool HalfPreparesGlyph(CardHalf half) => half != null && PreparesGlyph(half.Effects, 0);

    private static bool PreparesGlyph(IEnumerable<IEffect> effects, int depth)
    {
        if (effects == null || depth > 8)
            return false;
        foreach (var e in effects)
        {
            if (e is PrepareGlyphEffect or ReflectWardEffect or SpellAnchorEffect or EnchantPillarEffect)
                return true;
            if (PreparesGlyph(e?.Children, depth + 1))
                return true;
        }
        return false;
    }

    // ── Wards: auras by position (slice 12a) ─────────────────────────"""),
])

# Cost: The Architecture's glyph discount, priced with the half being cast.
edit('Scripts/Systems/Combat/Core/RuntimeInterfaces.cs', [
("""            int glyphDiscount = GlyphManager.StandingCostReduction(u);""",
"""            int glyphDiscount = GlyphManager.StandingCostReduction(u)
                + GlyphManager.ArchitectureDiscount(s, u, s.CostContextHalf ?? InferHalf(s.CostContextCard, baseAmount));"""),
("""    public bool CanPay(GameState s, Entity caster)
    {""",
"""    /// <summary>The UI prices a card without saying which half; the half whose printed cost
    /// matches is the one being priced (ties go to the glyph half, if either is one).</summary>
    private static CardHalf InferHalf(Card card, int printed)
    {
        if (card == null)
            return null;
        CardHalf pick = null;
        foreach (var h in new[] { card.TopHalf, card.BottomHalf })
        {
            if (h?.Costs == null)
                continue;
            foreach (var c in h.Costs)
                if (c is ManaCost mc && mc.Amount == printed)
                {
                    if (pick == null || GlyphManager.HalfPreparesGlyph(h))
                        pick = h;
                }
        }
        return pick;
    }

    public bool CanPay(GameState s, Entity caster)
    {"""),
])
edit('Scripts/Systems/GameStateManager.cs', [
("""    public Card CostContextCard;""",
"""    public Card CostContextCard;

    /// <summary>The half being cast, pinned beside <see cref="CostContextCard"/> by the cast
    /// path, for per-half discounts (The Architecture's glyph discount).</summary>
    public CardHalf CostContextHalf;"""),
])
edit('Scripts/Systems/Combat/Core/RulesManager.cs', [
("""        s.CostContextCard = sourceCard;
        try
        {""",
"""        s.CostContextCard = sourceCard;
        s.CostContextHalf = a as CardHalf;
        try
        {"""),
("""        finally
        {
            s.CostContextCard = null;
        }""",
"""        finally
        {
            s.CostContextCard = null;
            s.CostContextHalf = null;
        }"""),
])

# CombatManager: illusions fade, Dispel Walk steps, Territory walk damage and halving,
# Binding Chains halving, mirror-or-you targeting, rift blocked by Territory.
edit('Scripts/Systems/Combat/Core/CombatManager.Enchanter.cs', [
("""        // A unit that left its ward loses the aura, however it moved.
        State?.Glyphs?.OnUnitEntered(unit, tile);""",
"""        // A unit that left its ward loses the aura, however it moved.
        State?.Glyphs?.OnUnitEntered(unit, tile);

        // Dispel Walk: the caster strips enemies it passes this round.
        if (unit != null && unit.DispelWalkRound == Names.Round && unit.DispelWalkRound >= 0)
            DispelEffect.DispelAdjacent(State, unit);

        // Absolute Territory: every tile an enemy walks inside costs it.
        if (kind == MovementKind.Walked && unit != null && tile != null && unit.Stats.IsAlive)
        {
            var zone = AbsoluteTerritoryZone.Holding(State, unit, tile.Axial);
            if (zone != null && zone.DamagePerTile > 0)
            {
                unit.ApplyDamage(zone.DamagePerTile);
                LogName($"{unit.Name} walks in Absolute Territory: {zone.DamagePerTile} damage.");
            }
        }"""),
("""        int cut = State.Glyphs.PillarDamageReduction(attacker);
        if (cut <= 0)
            return damage;
        combatUI?.AppendActionLog($"A Sovereign Pillar blunts {attacker.Name}'s blow (-{cut}).");
        return Math.Max(0, damage - cut);""",
"""        int cut = State.Glyphs.PillarDamageReduction(attacker);
        if (cut > 0)
        {
            combatUI?.AppendActionLog($"A Sovereign Pillar blunts {attacker.Name}'s blow (-{cut}).");
            damage = Math.Max(0, damage - cut);
        }
        // Binding Chains: a Name that halves its bearer's attacks.
        if (attacker.Names.Any(n => n.HalveAttack && n.TurnsRemaining > 0))
        {
            damage /= 2;
            combatUI?.AppendActionLog($"{attacker.Name}'s chains halve the blow.");
        }
        // Absolute Territory: enemies inside deal half.
        if (attacker.CurrentTile != null && AbsoluteTerritoryZone.Holding(State, attacker, attacker.CurrentTile.Axial) != null)
        {
            damage /= 2;
            combatUI?.AppendActionLog($"Absolute Territory halves {attacker.Name}'s blow.");
        }
        return damage;"""),
("""    /// <summary>Start of a player turn: the break round advances and every Name ticks.</summary>
    private void TickNames()
    {
        Names.Round = roundNumber;
        if (State?.UnitsInPlay != null)
            Names.Tick(State.UnitsInPlay);
    }""",
"""    /// <summary>Start of a player turn: the break round advances and every Name ticks.</summary>
    private void TickNames()
    {
        Names.Round = roundNumber;
        if (State?.UnitsInPlay != null)
            Names.Tick(State.UnitsInPlay);
        TickIllusions();
    }

    /// <summary>Maze of Mirrors: timed copies fade at the start of a player turn.</summary>
    private void TickIllusions()
    {
        if (State?.UnitsInPlay == null)
            return;
        foreach (var u in State.UnitsInPlay.ToList())
        {
            if (u == null || !IsInstanceValid(u) || u.IllusionOwner == null || !u.Stats.IsAlive || u.IllusionTurnsLeft < 0)
                continue;
            u.IllusionTurnsLeft--;
            if (u.IllusionTurnsLeft <= 0)
            {
                LogName($"{u.Name} fades.");
                u.ApplyDamage(u.Stats.Health + u.Stats.Shield + u.Stats.Armor + 999);
            }
        }
    }

    /// <summary>Maze of Mirrors: while copies of <paramref name="picked"/> stand, an enemy
    /// that chose it gets it or one of its copies, at random.</summary>
    private Unit MirrorPick(Unit picked)
    {
        if (picked == null || State?.UnitsInPlay == null)
            return picked;
        var pool = State.UnitsInPlay
            .Where(u => u != null && IsInstanceValid(u) && u.Stats.IsAlive && u.IllusionOwner == picked && u.CurrentTile != null)
            .ToList();
        if (pool.Count == 0)
            return picked;
        pool.Add(picked);
        return pool[(int)(GD.Randi() % (uint)pool.Count)];
    }"""),
])
edit('Scripts/Systems/Combat/Core/CombatManager.cs', [
("""        if (bestTaunter != null && bestTauntDist <= bestDist + 1)
            return bestTaunter;
        return best;""",
"""        if (bestTaunter != null && bestTauntDist <= bestDist + 1)
            return MirrorPick(bestTaunter);
        return MirrorPick(best);"""),
])
edit('Scripts/Systems/Combat/Core/CombatManager.WarpChanneler.cs', [
("""        if (dest == null)
        {
            string blocked = $"{enemy.Name}: the rift finds no ground and collapses.";""",
"""        if (dest != null && AbsoluteTerritoryZone.BlocksTeleport(State, enemy, dest.Axial))
        {
            string held = $"{enemy.Name}: Absolute Territory holds the veil shut. The rift collapses.";
            GD.Print("[Warp] " + held);
            combatUI?.AppendActionLog(held);
            return;
        }

        if (dest == null)
        {
            string blocked = $"{enemy.Name}: the rift finds no ground and collapses.";"""),
])
