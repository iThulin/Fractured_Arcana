#!/usr/bin/env python3
# Slice 12b part 1: two new two-step targeters (unit then unit, tile then tile), the
# friendly_glyph_tile requirement, and the swap-locked-tiles hook. Repo root.
import sys, re
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

edit('Scripts/Cards/Targeting/TargetSelectors.cs', [
("""/// <summary>Pick a unit, then an ADJACENT tile of that unit naming the direction to""",
"""/// <summary>Pick a unit, then a SECOND unit within <see cref="destRange"/> of the caster.
/// Phase Shift (swap any two units), First Layer (swap two enemies' locked tiles). The
/// TargetSet is [first unit, second unit's tile]; effects resolve the tile's occupant.</summary>
public sealed class SelectUnitThenUnitTarget : SelectTwoStepTarget
{
    public int destRange;

    public SelectUnitThenUnitTarget(bool enemyOnly = false, int range = 4, int destRange = 4)
        : base(enemyOnly, range)
    {
        this.destRange = destRange;
    }

    public override string StepTwoPrompt => enemyOnly ? "Click a second enemy." : "Click a second unit.";
}

/// <summary>Pick a tile, then a SECOND tile. With <see cref="friendlyGlyphs"/>, both must
/// hold one of the caster's glyphs (Glyph Warp). The TargetSet is [first tile, second tile].
/// The first pick is the drop, so it starts from a tile rather than a unit.</summary>
public sealed class SelectTileThenTileTarget : SelectTwoStepTarget
{
    public int destRange;
    public bool friendlyGlyphs;

    public SelectTileThenTileTarget(int range = 4, int destRange = 99, bool friendlyGlyphs = true)
        : base(false, range)
    {
        this.destRange = destRange;
        this.friendlyGlyphs = friendlyGlyphs;
    }

    public override string StepTwoPrompt => friendlyGlyphs
        ? "Click a second tile with one of your glyphs."
        : "Click a second tile.";
}

/// <summary>Pick a unit, then an ADJACENT tile of that unit naming the direction to"""),
])

edit('Scripts/Cards/Loader/JsonCardLoader.cs', [
("""            return new SelectUnitThenDirectionTarget(enemyOnly, range, friendlyOnly, constructsOnly);
        });""",
"""            return new SelectUnitThenDirectionTarget(enemyOnly, range, friendlyOnly, constructsOnly);
        });

        // { "type": "unit_then_unit", "range": n, "dest_range": n, "enemies_only": bool }
        RegisterTargeter("unit_then_unit", n =>
        {
            bool enemyOnly = n.TryGetProperty("enemies_only", out var eo) && eo.GetBoolean();
            int range = n.TryGetProperty("range", out var r) ? r.GetInt32() : 4;
            int destRange = n.TryGetProperty("dest_range", out var d) ? d.GetInt32() : range;
            return new SelectUnitThenUnitTarget(enemyOnly, range, destRange);
        });

        // { "type": "tile_then_tile", "range": n, "dest_range": n, "friendly_glyphs": bool }
        RegisterTargeter("tile_then_tile", n =>
        {
            int range = n.TryGetProperty("range", out var r) ? r.GetInt32() : 4;
            int destRange = n.TryGetProperty("dest_range", out var d) ? d.GetInt32() : 99;
            bool glyphs = !n.TryGetProperty("friendly_glyphs", out var fg) || fg.GetBoolean();
            return new SelectTileThenTileTarget(range, destRange, glyphs);
        });"""),
])

edit('Scripts/Cards/Targeting/TargetingSummary.cs', [
("""            case SelectUnitThenTileTarget ut:""",
"""            case SelectUnitThenUnitTarget uu:
                return new Entry($"Unit {uu.range}, unit {uu.destRange}", $"A unit within {uu.range}, then a second unit within {uu.destRange}.", Delivery.Arc);

            case SelectTileThenTileTarget tt2:
                return new Entry(tt2.friendlyGlyphs ? $"Glyph {tt2.range}, glyph" : $"Tile {tt2.range}, tile",
                                 tt2.friendlyGlyphs ? $"One of your glyphs within {tt2.range}, then another of your glyphs." : $"A tile within {tt2.range}, then a second tile.",
                                 Delivery.Ground);

            case SelectUnitThenTileTarget ut:"""),
])

CM = 'Scripts/Systems/Combat/Core/CombatManager.cs'
edit(CM, [
# Legal second picks for unit -> unit.
("""        if (ts is SelectUnitThenTileTarget tt)
        {""",
"""        if (ts is SelectUnitThenUnitTarget uu)
        {
            var from = selectedUnit?.CurrentTile?.Axial ?? victim.CurrentTile.Axial;
            foreach (var u in State.UnitsInPlay)
            {
                if (u == null || !IsInstanceValid(u) || u == victim || !u.Stats.IsAlive || u.CurrentTile == null)
                    continue;
                if (uu.enemyOnly && u.TeamId == selectedUnit?.TeamId)
                    continue;
                if (grid.Distance(from, u.CurrentTile.Axial) > uu.destRange)
                    continue;
                yield return u.CurrentTile.Axial;
            }
            yield break;
        }

        if (ts is SelectUnitThenTileTarget tt)
        {"""),
# Tile -> tile: begin from a tile, not a unit.
("""    /// <summary>Consumes the second click. Returns true when it handled the input, so""",
"""    /// <summary>Arms the second pick for a tile-then-tile targeter (Glyph Warp). Same state
    /// and highlight discipline as <see cref="BeginTwoStep"/>, but the first pick is a tile.</summary>
    private void BeginTwoStepTiles(CardUi cardUi, bool isTop, HexTile tile, SelectTileThenTileTarget ts, CardHalf half)
    {
        _twoStepCard = cardUi;
        _twoStepIsTop = isTop;
        _twoStepTile = tile;
        _twoStepVictim = null;
        _twoStepTargeter = ts;
        _twoStepChoice = null;

        ClearTargetHighlight();
        _twoStepLegalTiles.Clear();
        int team = selectedUnit?.TeamId ?? 0;
        foreach (var td in grid.Tiles.Values)
        {
            if (td == null || td.Axial == tile.Axial)
                continue;
            if (grid.Distance(tile.Axial, td.Axial) > ts.destRange)
                continue;
            if (ts.friendlyGlyphs && (td.Glyph == null || td.Glyph.OwnerTeam != team))
                continue;
            _twoStepLegalTiles.Add(td.Axial);
            grid.GetTileView(td.Axial)?.SetTargetHighlight(true);
        }

        string prompt = _twoStepLegalTiles.Count == 0
            ? $"{half.Name}: there is no second tile to choose. (Esc or right-click to cancel.)"
            : $"{half.Name}. {ts.StepTwoPrompt} (Esc or right-click to cancel.)";
        GD.Print($"[TwoStep] {prompt}");
        combatUI?.AppendActionLog(prompt);
    }

    /// <summary>Consumes the second click. Returns true when it handled the input, so"""),
("""            case SelectTwoStepTarget ts:
            {
                var victim = State.UnitsInPlay""",
"""            // Tile then tile (Glyph Warp): the drop is the first tile.
            case SelectTileThenTileTarget tt2:
            {
                var first = grid.GetTile(tile.Axial);
                if (first == null)
                { CancelTwoStep(); CastFail($"{resolvedHalf.Name}: no tile there."); return; }
                if (selectedUnit?.CurrentTile != null && grid.Distance(selectedUnit.CurrentTile.Axial, first.Axial) > tt2.range)
                { CancelTwoStep(); CastFail($"{resolvedHalf.Name}: that tile is out of range."); return; }
                if (tt2.friendlyGlyphs && (first.Glyph == null || first.Glyph.OwnerTeam != (selectedUnit?.TeamId ?? 0)))
                { CancelTwoStep(); CastFail($"{resolvedHalf.Name}: start on one of your glyphs."); return; }

                if (_twoStepChoice == null)
                {
                    BeginTwoStepTiles(cardUi, isTop, tile, tt2, resolvedHalf);
                    return;                      // paused for the second pick
                }

                targets.Items.Add(first);
                targets.Items.Add(_twoStepChoice);
                ClearTwoStep();
                break;
            }

            case SelectTwoStepTarget ts:
            {
                var victim = State.UnitsInPlay"""),
("""                case "empty_tile":
                    if (!TargetHasEmptyTile(targets))""",
"""                case "friendly_glyph_tile":
                {
                    var gt = FirstTargetTile(targets);
                    if (gt?.Glyph == null || gt.Glyph.OwnerTeam != (selectedUnit?.TeamId ?? 0))
                    {
                        failReason = "Requires a tile with one of your glyphs!";
                        return false;
                    }
                    break;
                }

                case "empty_tile":
                    if (!TargetHasEmptyTile(targets))"""),
])

edit('Scripts/Systems/Combat/Core/CombatManager.CastPreview.cs', [
("""            case SelectUnitTarget u:
                enemiesOnly = u.enemyOnly; friendliesOnly = u.friendlyOnly; range = u.range; break;
            case SelectTwoStepTarget ts:""",
"""            case SelectUnitTarget u:
                enemiesOnly = u.enemyOnly; friendliesOnly = u.friendlyOnly; range = u.range; break;
            case SelectTileThenTileTarget:
                return;   // picks tiles (glyphs), not units
            case SelectTwoStepTarget ts:"""),
])

# Swap two enemies' locked tiles (First Layer, §4).
edit('Scripts/Cards/Effects/IntentTimeEffects.cs', [
("""    public static Func<Unit, string> CancelHook;""",
"""    public static Func<Unit, string> CancelHook;

    /// <summary>Swap two enemies' locked attack tiles (First Layer). Installed by CombatManager.</summary>
    public static Func<Unit, Unit, string> SwapLocksHook;
    public static string SwapLocks(Unit a, Unit b) => SwapLocksHook != null ? SwapLocksHook(a, b) : "no combat is running";"""),
])

edit('Scripts/Systems/Combat/Core/CombatManager.IntentTime.cs', [
("""        IntentTime.CancelHook = CancelDeferred;
    }""",
"""        IntentTime.CancelHook = CancelDeferred;
        IntentTime.SwapLocksHook = SwapLockedTiles;
    }

    /// <summary>First Layer (§4): the two enemies' locked tiles trade places, with their
    /// threat footprints. Each attack lands where the other was aimed. The Enchanter
    /// decides WHO an attack hits; when it lands is untouched.</summary>
    private string SwapLockedTiles(Unit a, Unit b)
    {
        if (!IsValidActor(a) || !IsValidActor(b) || a == b)
            return "two different enemies are needed";
        var ia = a.CurrentIntent;
        var ib = b.CurrentIntent;
        if (ia?.TargetTile == null || ib?.TargetTile == null)
            return "both must have an attack locked on a tile";
        (ia.TargetTile, ib.TargetTile) = (ib.TargetTile, ia.TargetTile);
        (ia.ThreatTiles, ib.ThreatTiles) = (ib.ThreatTiles, ia.ThreatTiles);
        (ia.TargetUnit, ib.TargetUnit) = (ib.TargetUnit, ia.TargetUnit);
        RefreshThreatTiles();
        string msg = $"{a.Name} and {b.Name} trade their marks.";
        combatUI?.AppendActionLog(msg);
        return null;
    }"""),
])

# Schema: allow the new targeters and requirement.
p = 'Schemas/card.schema.json'
s = open(p, encoding='utf-8').read()
m = re.search(r'(\n(\s*)"memorial_or_spirit_nearby")(\n)', s)
if not m:
    sys.exit("schema: requires enum anchor not found")
if '"friendly_glyph_tile"' not in s:
    s = s[:m.end(1)] + ',\n' + m.group(2) + '"friendly_glyph_tile"' + s[m.end(1):]
    open(p, 'w', encoding='utf-8').write(s)
    print("patched", p, "(requires enum)")
