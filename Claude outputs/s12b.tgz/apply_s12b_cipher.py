#!/usr/bin/env python3
# Slice 12b part 4: Glyph Warp's tile-then-tile targeting still reads as a TILE spell to
# the glyph cipher (two-step selectors otherwise read as unit spells). Repo root.
import sys
rel = 'Scripts/Systems/Combat/Glyphs/GlyphCipherTags.cs'
s = open(rel, encoding='utf-8').read()
old = """            // friendlyOnly is declared on the SelectTwoStepTarget base, so both
            // unit_then_tile and unit_then_direction are covered by one case.
            case SelectTwoStepTarget two:"""
new = """            // Tile then tile (Glyph Warp) picks places, not people.
            case SelectTileThenTileTarget:
                return CipherTarget.Tile;

            // friendlyOnly is declared on the SelectTwoStepTarget base, so both
            // unit_then_tile and unit_then_direction are covered by one case.
            case SelectTwoStepTarget two:"""
if s.count(old) != 1:
    sys.exit("cipher tags anchor not found")
open(rel, 'w', encoding='utf-8').write(s.replace(old, new))
print("patched", rel)
