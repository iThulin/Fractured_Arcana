#!/usr/bin/env python3
# Slice 12b card data: Puppeteer, The Architecture, Absolute Territory, Phase Shift,
# Glyph Warp, Rune Step, Dispel Walk, and the §4 rewordings (Binding Chains, Dominion,
# First Layer, Read the Weave). Schema enums for the new types. Repo root.
import json, sys, re

NAMED = "Named (half damage, cannot move)"
cards = {}
def card(cid):
    if cid not in cards:
        cards[cid] = json.load(open(f"Data/Cards/{cid}.json", encoding='utf-8'))
    return cards[cid]

def with_after(d, after_key, key, value):
    out = {}
    for k, v in d.items():
        if k == key:
            continue
        out[k] = v
        if k == after_key:
            out[key] = value
    if key not in out:
        out[key] = value
    return out

def base(cid, half, field, value):
    d = card(cid)
    if field in d[half]:
        d[half][field] = value
    else:
        d[half] = with_after(d[half], "tags" if "tags" in d[half] else "rules_text", field, value)

def rung_entry(cid, half, tier):
    d = card(cid)
    rs = [u for u in d["upgrades"] if u.get("tier") == tier
          and (u.get("half") == half or (tier == 1 and u.get("half") == "both"))]
    if len(rs) != 1:
        sys.exit(f"{cid} {half} T{tier}: expected one rung, found {len(rs)}")
    return rs[0]

def rung(cid, half, tier, field, value, remove=False):
    ch = rung_entry(cid, half, tier)["changes"]
    idx = [i for i, c in enumerate(ch) if c.get("half") == half and c.get("field") == field]
    if remove:
        for i in reversed(idx):
            ch.pop(i)
        return
    if idx:
        ch[idx[0]]["value"] = value
    else:
        ch.append({"half": half, "field": field, "value": value})

# ── Puppeteer (ruled: auto-walk to your glyphs) ───────────────────────
c = "enchanter_sovereign_will"
card(c)["bottom"]["effect"] = {"type": "puppeteer", "turns": 2, "move_tiles": 2}
base(c, "bottom", "rules_text", "For 2 turns, at the start of each round, every enemy walks up to 2 tiles toward your nearest glyph. Glyphs it walks onto trigger.")
rung(c, "bottom", 1, "rules_text", "For 3 turns, at the start of each round, every enemy walks up to 2 tiles toward your nearest glyph. Glyphs it walks onto trigger.")
rung(c, "bottom", 2, "rules_text", "For 3 turns, at the start of each round, every enemy walks up to 3 tiles toward your nearest glyph. Glyphs it walks onto trigger.")
rung(c, "bottom", 3, "rules_text", f"For 3 turns, at the start of each round, every enemy walks up to 3 tiles toward your nearest glyph and is {NAMED} until the next. Glyphs it walks onto trigger.")
rung(c, "bottom", 4, "effect", {"type": "puppeteer", "turns": 4, "move_tiles": 3, "name_controlled": True})
rung(c, "bottom", 4, "rules_text", f"For 4 turns, at the start of each round, every enemy walks up to 3 tiles toward your nearest glyph and is {NAMED} until the next. Glyphs it walks onto trigger.")

# ── The Architecture: "trigger twice" is double damage ───────────────
c = "enchanter_the_grand_design"
base(c, "top", "rules_text", "For the rest of the fight: whenever you prepare a glyph it is also prepared on all tiles within 1, and your glyphs deal double damage.")
rung(c, "top", 1, "rules_text", "Rest of fight: glyphs you prepare also prepare on all tiles within 1, glyph spells cost 1 less, and glyphs deal double damage.")
rung(c, "top", 2, "rules_text", "Rest of fight: glyphs spread to radius 1, glyph spells cost 1 less, glyphs deal double damage, and you bank 1 Weave per glyph prepared.")
rung(c, "top", 3, "rules_text", "Rest of fight: glyphs spread to radius 2, glyph spells cost 1 less, glyphs deal double damage, and you bank 1 Weave per glyph prepared.")
rung(c, "top", 4, "rules_text", "Rest of fight: glyphs spread to radius 2, glyph spells cost 1 less, glyphs deal triple damage, and you bank 1 Weave per glyph prepared.")

# ── Absolute Territory (ruled: zone only) ─────────────────────────────
base(c, "bottom", "rules_text", "For 2 turns, enemies within 3 of where you stand deal half damage, take 2 damage for each tile they walk there, and cannot teleport in or out.")
rung(c, "bottom", 1, "rules_text", "For 2 turns, enemies within 3 of where you stand deal half damage, take 3 per tile they walk there, and cannot teleport in or out.")
rung(c, "bottom", 2, "rules_text", "For 3 turns, enemies within 3 of where you stand deal half damage, take 3 per tile they walk there, and cannot teleport in or out.")
rung(c, "bottom", 3, "rules_text", f"For 3 turns, enemies within 3 of where you stand are {NAMED}, take 3 per tile they walk there, and cannot teleport in or out.")
rung(c, "bottom", 4, "rules_text", f"For the rest of the fight, enemies within 4 of where you stand are {NAMED}, take 4 per tile they walk there, and cannot teleport in or out.")

# ── Phase Shift: pick two units ───────────────────────────────────────
c = "enchanter_mirror_ward"
card(c)["bottom"]["targeting"] = {"type": "unit_then_unit", "range": 3, "dest_range": 3}
card(c)["bottom"]["effect"] = {"type": "swap_units"}
base(c, "bottom", "rules_text", "Swap the positions of any 2 units within 3. If either lands on a glyph, it triggers.")
rung(c, "bottom", 1, "effect.range", None, remove=True)
rung(c, "bottom", 1, "targeting", {"type": "unit_then_unit", "range": 5, "dest_range": 5})
rung(c, "bottom", 1, "rules_text", "Swap any 2 units within 5. Glyph landings trigger.")
rung(c, "bottom", 2, "effect.chain", None, remove=True)
rung(c, "bottom", 2, "effect.damage_enemies", 4)
rung(c, "bottom", 2, "rules_text", "Swap any 2 units within 5. Each enemy moved takes 4 damage. Glyph landings trigger.")
rung(c, "bottom", 3, "rules_text", "Swap any 2 units within 5. Each enemy moved takes 4 damage and is Named for 1 turn. Glyph landings trigger.")
rung(c, "bottom", 4, "effect", {"type": "sequence", "steps": [
    {"type": "swap_units", "damage_enemies": 6, "name_enemy": True}, {"type": "draw", "count": 1}]})
rung(c, "bottom", 4, "rules_text", "Swap any 2 units within 5. Each enemy moved takes 6 damage and is Named for 1 turn. Glyph landings trigger. Draw 1 card.")

# ── Glyph Warp: pick two of your glyphs ───────────────────────────────
c = "enchanter_runic_cascade"
card(c)["bottom"]["targeting"] = {"type": "tile_then_tile", "range": 4, "dest_range": 99}
rung(c, "bottom", 1, "rules_text", "Swap 2 of your prepared glyphs, then trigger both.")
rung(c, "bottom", 2, "effect.count", None, remove=True)
rung(c, "bottom", 2, "effect.bonus", 2)
rung(c, "bottom", 2, "rules_text", "Swap 2 of your glyphs, then trigger both, each with +2 damage.")
rung(c, "bottom", 3, "rules_text", "Swap 2 of your glyphs, then trigger both, each with +2 damage. Gain 1 Weave per glyph triggered.")
rung(c, "bottom", 4, "effect", {"type": "sequence", "steps": [
    {"type": "swap_glyphs", "trigger_all_after": True, "bonus": 2, "on_trigger_weave": 1}, {"type": "gain_weave", "amount": 1}]})
rung(c, "bottom", 4, "rules_text", "Swap 2 of your glyphs, then trigger every glyph you control (+2 damage each). Gain 1 Weave per glyph, plus 1.")

# ── Rune Step: choose which glyph ─────────────────────────────────────
c = "enchanter_snare_glyph"
card(c)["bottom"]["targeting"] = {"type": "tile", "range": 12}
base(c, "bottom", "requires", ["friendly_glyph_tile"])

# ── Dispel Walk: the enemies you pass ─────────────────────────────────
c = "enchanter_dispel_walk"
card(c)["top"]["effect"]["steps"][1] = {"type": "dispel_walk", "count": 1}
rung(c, "top", 3, "effect", {"type": "sequence", "steps": [
    {"type": "move", "tiles": 3}, {"type": "dispel_walk", "count": 2, "steal": True}, {"type": "gain_weave", "amount": 1}]})
rung(c, "top", 4, "effect", {"type": "sequence", "steps": [
    {"type": "move", "tiles": 3}, {"type": "dispel_walk", "count": 99, "steal": True}, {"type": "gain_weave", "amount": 1}]})
base(c, "top", "rules_text", "Move 2 tiles. Remove 1 buff from each enemy you pass adjacent to this turn.")

# ── First Layer (§4): swap two enemies' locked tiles ──────────────────
c = "enchanter_seventh_layer"
card(c)["bottom"]["targeting"] = {"type": "unit_then_unit", "range": 6, "dest_range": 6, "enemies_only": True}
card(c)["bottom"]["effect"] = {"type": "swap_locks"}
base(c, "bottom", "rules_text", "Swap the locked tiles of two enemy attacks.")

# ── Binding Chains (§4): a Name that halves the attack ────────────────
c = "enchanter_binding_chains"
def chains(dmg, dur):
    return {"type": "name_condition", "trigger": "attack", "damage": dmg, "duration": dur, "halve_attack": True}
card(c)["top"]["effect"] = {"type": "sequence", "steps": [chains(3, 2), {"type": "gain_weave", "amount": 1}]}
base(c, "top", "rules_text", "Name an enemy for 2 turns: if it attacks, the attack deals half damage and it takes 3. Gain 1 Weave.")
rung(c, "top", 1, "effect.steps[0]", chains(5, 2))
rung(c, "top", 1, "rules_text", "Name an enemy for 2 turns: if it attacks, the attack deals half damage and it takes 5. Gain 1 Weave.")
rung(c, "top", 2, "effect.steps[0].steps[1].duration", None, remove=True)
rung(c, "top", 2, "effect.steps[0].duration", 3)
rung(c, "top", 2, "rules_text", "Name an enemy for 3 turns: if it attacks, the attack deals half damage and it takes 5. Gain 1 Weave.")
rung(c, "top", 3, "effect", {"type": "sequence", "steps": [
    chains(5, 3),
    {"type": "retarget", "targeting": {"type": "unit", "range": 3, "los": False, "enemies_only": True}, "do": chains(5, 2)},
    {"type": "gain_weave", "amount": 1}]})
rung(c, "top", 3, "rules_text", "Name an enemy for 3 turns, and the nearest other enemy within 3 for 2: if it attacks, the attack deals half damage and it takes 5. Gain 1 Weave.")
rung(c, "top", 4, "effect", {"type": "sequence", "steps": [chains(7, 99), {"type": "gain_weave", "amount": 2}]})
rung(c, "top", 4, "rules_text", "Name an enemy for the rest of the fight: if it attacks, the attack deals half damage and it takes 7. Gain 2 Weave.")

# ── Dominion (§4): a Name on everyone nearby ──────────────────────────
c = "enchanter_dominion"
def dom(dmg, dur):
    return {"type": "name_condition", "trigger": ["move", "attack"], "damage": dmg, "duration": dur}
card(c)["top"]["effect"] = {"type": "sequence", "steps": [
    {"type": "retarget", "targeting": {"type": "aoe", "radius": 2, "enemies_only": True}, "do": dom(4, 1)},
    {"type": "gain_weave", "amount": 2}]}
base(c, "top", "rules_text", "Name every enemy within 2 of the target for 1 turn: each that moves or attacks takes 4 damage. Gain 2 Weave.")
rung(c, "top", 1, "rules_text", "Name every enemy within 2 of the target for 2 turns: each that moves or attacks takes 4 damage. Gain 2 Weave.")
rung(c, "top", 2, "effect.steps[0].do", dom(6, 2))
rung(c, "top", 2, "rules_text", "Name every enemy within 2 of the target for 2 turns: each that moves or attacks takes 6 damage. Gain 2 Weave.")
rung(c, "top", 3, "rules_text", "Name every enemy within 3 of the target for 2 turns: each that moves or attacks takes 6 damage. Gain 2 Weave.")
rung(c, "top", 4, "effect", {"type": "sequence", "steps": [
    {"type": "retarget", "targeting": {"type": "global", "enemies_only": True}, "do": dom(6, 3)},
    {"type": "gain_weave", "amount": 2}]})
rung(c, "top", 4, "rules_text", "Name every enemy for 3 turns: each that moves or attacks takes 6 damage. Gain 2 Weave.")

# ── Read the Weave (§4): no scrying ───────────────────────────────────
c = "enchanter_contingency_glyph"
card(c)["bottom"]["effect"] = {"type": "sequence", "steps": [{"type": "draw", "count": 1}, {"type": "gain_weave", "amount": 1}]}
base(c, "bottom", "rules_text", "Gain 1 Weave. Draw 1 card.")
rung(c, "bottom", 1, "rules_text", "Gain 2 Weave. Draw 1 card.")

for cid, d in cards.items():
    open(f"Data/Cards/{cid}.json", 'w', encoding='utf-8').write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
    print("patched", cid)

# ── Schema enums ──────────────────────────────────────────────────────
p = 'Schemas/card.schema.json'
s = open(p, encoding='utf-8').read()
def add_after(s, anchor, values):
    m = re.search(r'(\n(\s*)"' + re.escape(anchor) + r'"),', s)
    if not m:
        sys.exit(f"schema anchor {anchor} not found")
    add = "".join(f',\n{m.group(2)}"{v}"' for v in values if f'"{v}"' not in s)
    return s[:m.end(1)] + add + s[m.end(1):]
s = add_after(s, "unit_then_direction", ["unit_then_unit", "tile_then_tile"])
s = add_after(s, "compel_walk", ["puppeteer", "swap_locks", "dispel_walk"])
json.loads(s)
open(p, 'w', encoding='utf-8').write(s)
print("patched", p)
