import sys, os, json, re
root = sys.argv[1]

def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        assert n == 1, f"{rel}: expected 1 match, got {n} for:\n{old}"
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print("ok", rel)

# ════════════════════════════════════════════════════════════════════
# Overdrawn Time Bank (§2b)
# ════════════════════════════════════════════════════════════════════
edit('Scripts/Systems/Combat/Attunement/FateAttunement.cs', [
(
'''    public const int MaxCharges = 4;
''',
'''    public const int MaxCharges = 4;
    /// <summary>Overdrawn floor (class_identity_chronomancer_v1 §2b): "lose" effects may
    /// take the bank this far below zero. Spending never goes below zero.</summary>
    public const int MinCharges = -3;

    /// <summary>Below zero: the owner loses HP each turn start and gets no free Reflex.</summary>
    public bool IsOverdrawn => Charges < 0;
'''),
(
'''    public void SpendCharges(int amount)
    {
        SetCharges(Math.Max(0, Charges - amount));
    }
''',
'''    public void SpendCharges(int amount)
    {
        // Spending needs the Foresight to be there: it stops at zero (or stays where
        // an Overdraft already put it). Only LoseCharges can borrow below zero.
        SetCharges(Math.Max(Math.Min(Charges, 0), Charges - amount));
    }

    /// <summary>"Lose N Foresight (you may go Overdrawn)": may take the bank below zero,
    /// down to <see cref="MinCharges"/>. Returns how much was actually lost.</summary>
    public int LoseCharges(int amount)
    {
        int before = Charges;
        SetCharges(Math.Max(MinCharges, Charges - Math.Max(0, amount)));
        return before - Charges;
    }
'''),
(
'''        Charges = Math.Clamp(value, 0, MaxCharges);
''',
'''        Charges = Math.Clamp(value, MinCharges, MaxCharges);
'''),
(
'''    private static ForesightTier ChargeToTier(int charges) => charges switch
    {
        0 => ForesightTier.Blind,
''',
'''    private static ForesightTier ChargeToTier(int charges) => charges switch
    {
        <= 0 => ForesightTier.Blind,   // Overdrawn reads as no tier, never as Foreseen
'''),
])

edit('Scripts/Systems/Combat/Core/RuntimeInterfaces.cs', [(
'''                available += fateAvail.Charges;
''',
'''                available += Math.Max(0, fateAvail.Charges);   // an Overdraft backs nothing
''')])

edit('Scripts/Systems/Combat/Core/CombatManager.cs', [
(
'''        // Reset extra-turn flag and per-round tracking
        if (!_isExtraTurn)
        {
''',
'''        // Chronomancer §2e: where everyone stood, and their HP, as this round begins.
        if (!_isExtraTurn)
            SnapshotRoundStart();

        // Reset extra-turn flag and per-round tracking
        if (!_isExtraTurn)
        {
'''),
(
'''            unit.StartTurn();

            // Apply martial stance passives
''',
'''            unit.StartTurn();

            // Overdrawn Time Bank (chronomancer §2b): HP lost per point below zero.
            if (unit.Attunement is FateAttunement overdraft && overdraft.IsOverdrawn)
                ApplyOverdraftLoss(unit, overdraft);
            if (!unit.Stats.IsAlive)
                continue;

            // Apply martial stance passives
'''),
# The Almanac fires through AlmanacEntry.Fire (maturity + caster pin).
(
'''                    entry.Child?.Resolve(State, entry.Caster, entry.Targets, entry.Snapshot);
''',
'''                    entry.Fire(State);   // pins the scheduling unit and applies maturity (§2c)
'''),
])

edit('Scripts/UI/SchoolAttunementUI.cs', [
(
'''	private void OnForesightChanged(int newValue)
	{
		if (_foresightBar == null)
			return;
		_foresightBar.Value = newValue;
		_foresightTierLabel.Text = ForesightTierLabels[Math.Clamp(newValue, 0, 4)];
	}
''',
'''	private void OnForesightChanged(int newValue)
	{
		if (_foresightBar == null)
			return;
		ShowForesight(newValue);
	}

	/// <summary>Chronomancer §2b: a positive bank fills toward FULL in the school colour;
	/// an Overdrawn bank shows the debt instead, in the danger colour, with its cost.</summary>
	private void ShowForesight(int value)
	{
		if (value < 0)
		{
			_foresightBar.MaxValue = -FateAttunement.MinCharges;
			_foresightBar.Value = -value;
			_foresightBar.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = UITheme.Danger });
			_foresightTierLabel.Text = $"OWE {-value}";
			_foresightTierLabel.TooltipText = $"Overdrawn: you lose {-value * CombatManager.OverdraftHpPerPoint} HP at the start of each turn, and get no free Reflex, until the bank is back to 0.";
			_foresightTierLabel.MouseFilter = Control.MouseFilterEnum.Stop;
			return;
		}
		_foresightBar.MaxValue = FateAttunement.MaxCharges;
		_foresightBar.Value = value;
		_foresightBar.AddThemeStyleboxOverride("fill", new StyleBoxFlat { BgColor = SchoolColors.GetBorderColor(CardSchool.Chronomancer) });
		_foresightTierLabel.Text = ForesightTierLabels[Math.Clamp(value, 0, 4)];
		_foresightTierLabel.TooltipText = "";
	}
'''),
(
'''		_foresightBar.Value = _boundFate.Charges;
		_foresightTierLabel.Text = ForesightTierLabels[Math.Clamp(_boundFate.Charges, 0, 4)];
	}
''',
'''		ShowForesight(_boundFate.Charges);
	}
'''),
])

# ════════════════════════════════════════════════════════════════════
# Matured schedules (§2c)
# ════════════════════════════════════════════════════════════════════
edit('Scripts/Cards/Effects/Effect.cs', [(
'''	public bool IsReady => TurnsRemaining <= 0;

	/// <summary>Decrement the counter. Call once per player turn.</summary>
	public void Tick() => TurnsRemaining = Math.Max(0, TurnsRemaining - 1);
''',
'''	public bool IsReady => TurnsRemaining <= 0;

	/// <summary>The unit that scheduled it, pinned as the caster when it fires.</summary>
	public Unit CasterUnit;

	/// <summary>Turns this entry has waited (one per tick).</summary>
	public int TurnsWaited;

	/// <summary>Matured schedules (class_identity_chronomancer_v1 §2c): +2 damage for
	/// each turn waited beyond the first. Damage only, through BonusSpellDamage.</summary>
	public const int MaturityPerTurn = 2;
	public int MaturityBonus => Math.Max(0, TurnsWaited - 1) * MaturityPerTurn;

	/// <summary>Decrement the counter. Call once per player turn.</summary>
	public void Tick()
	{
		TurnsRemaining = Math.Max(0, TurnsRemaining - 1);
		TurnsWaited++;
	}

	/// <summary>Resolves the scheduled effect now, as its scheduling unit, with whatever
	/// it has matured to so far. Every firing path (the turn tick, Advance, Hasten,
	/// event control) goes through here so maturity cannot be skipped.</summary>
	public void Fire(GameState s)
	{
		var unit = CasterUnit != null && GodotObject.IsInstanceValid(CasterUnit) && CasterUnit.Stats.IsAlive
			? CasterUnit : null;
		int bonus = unit != null ? MaturityBonus : 0;
		var prevCaster = s.ActiveCasterUnit;
		if (unit != null)
			s.ActiveCasterUnit = unit;
		if (bonus > 0)
		{
			unit.BonusSpellDamage += bonus;
			s.Log($"[Almanac] {Label} has matured: +{bonus} damage.");
			RegisterManager.Fire("chrono.matured");
		}
		try
		{
			Child?.Resolve(s, Caster, Targets, Snapshot);
		}
		finally
		{
			if (bonus > 0)
				unit.BonusSpellDamage -= bonus;
			s.ActiveCasterUnit = prevCaster;
		}
	}
''')])

edit('Scripts/Cards/Effects/ChronomancerEffects.cs', [
(
'''			Snapshot = snap,
			// The card's own name, not the effect class: this is what the Almanac
''',
'''			Snapshot = snap,
			CasterUnit = s.ActiveCasterUnit,   // fires as this unit, with maturity (§2c)
			// The card's own name, not the effect class: this is what the Almanac
'''),
(
'''			s.Log($"[Advance] Entry reached 0. Firing immediately.");
			entry.Child?.Resolve(s, entry.Caster, entry.Targets, entry.Snapshot);
			s.Almanac.Remove(entry);
''',
'''			s.Log($"[Advance] Entry reached 0. Firing immediately.");
			s.Almanac.Remove(entry);
			entry.Fire(s);
'''),
(
'''			s.Almanac.Remove(entry);   // removed first, so an entry that schedules again cannot loop
			entry.Child?.Resolve(s, entry.Caster, entry.Targets, entry.Snapshot);
''',
'''			s.Almanac.Remove(entry);   // removed first, so an entry that schedules again cannot loop
			entry.Fire(s);
'''),
(
'''				s.Log($"[EventControl] Fast-forwarding '{entry.Label}'.");
				entry.Child?.Resolve(s, entry.Caster, entry.Targets, entry.Snapshot);
				s.Almanac.Remove(entry);
''',
'''				s.Log($"[EventControl] Fast-forwarding '{entry.Label}'.");
				s.Almanac.Remove(entry);
				entry.Fire(s);
'''),
# ── peek_intent: lookahead (Chronomancer) and permanent (Adept) ──
(
'''	public int Range;
	public PeekIntentEffect(int range = 0) { Range = Math.Max(0, range); }
''',
'''	public int Range;
	/// <summary>Also reveal each enemy's NEXT intent (Chronomancer lookahead, §2d).</summary>
	public bool Lookahead;
	/// <summary>Keep what was revealed visible for the rest of the fight (Adept reveals).</summary>
	public bool Permanent;
	public PeekIntentEffect(int range = 0, bool lookahead = false, bool permanent = false)
	{
		Range = Math.Max(0, range);
		Lookahead = lookahead;
		Permanent = permanent;
	}
'''),
(
'''			if (IntentTime.Reveal(unit))
''',
'''			if (IntentTime.Reveal(unit, Lookahead, Permanent))
'''),
# ── ManaDebt retired (§2b): Borrowed Mana loses Foresight instead ──
(
'''/// <summary>
/// Borrowed Mana (audit §6.2 addition, 2026-07-29): gain mana now, repay it at the
/// start of your next turn. The school's answer to tithe_aura pressure without
/// giving the zero-economy school real ramp. The debt makes it tempo, not value.
/// JSON: { "type": "mana_debt", "amount": n }  (the GAIN is a separate mana_gain
/// step; this leaf only books the repayment)
/// </summary>
public sealed class ManaDebtLeafEffect : EffectBase
{
	public int Amount;
	public ManaDebtLeafEffect(int amount) { Amount = Math.Max(0, amount); }

	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		if (Amount <= 0)
			return;
		var unit = s.ActiveCasterUnit;
		s.ActiveEffects ??= new List<PersistentEffect>();
		s.ActiveEffects.Add(new ManaDebtPersistentEffect(Amount, caster, unit));
		s.Log($"[ManaDebt] {unit?.Name ?? "caster"} owes {Amount} mana next turn.");
	}
}

/// <summary>Collects the Borrowed Mana debt on the owner's next turn start, then
/// expires. Drains to a floor of 0: a debt cannot make mana negative; if the
/// player spent everything, the shortfall is simply forgiven (and logged), which is
/// deliberately lenient: a debt that could brick the turn after a defensive
/// emergency would make the card unplayable at its rarity.</summary>
public class ManaDebtPersistentEffect : PersistentEffect
{
	private readonly int _amount;
	private readonly Unit _unit;

	public ManaDebtPersistentEffect(int amount, Entity owner, Unit unit)
	{
		_amount = amount;
		Owner = owner;
		_unit = unit;
		TurnsRemaining = 1;
	}

	public override void Tick(GameState s)
	{
		TurnsRemaining = 0;
		if (_unit == null || !GodotObject.IsInstanceValid(_unit) || !_unit.Stats.IsAlive)
			return;
		int due = Math.Min(_amount, _unit.Stats.Mana);
		if (due > 0)
			_unit.TrySpendMana(due);
		if (s.Mana.ContainsKey(Owner))
			s.Mana[Owner] = _unit.Stats.Mana;
		s.Log(due < _amount
			? $"[ManaDebt] {_unit.Name} repays {due}/{_amount}. The rest is forgiven."
			: $"[ManaDebt] {_unit.Name} repays {due} mana.");
	}
}
''',
'''// (2026-10-03) ManaDebtLeafEffect / ManaDebtPersistentEffect retired: the Overdrawn
// Time Bank replaces mana debt (class_identity_chronomancer_v1 §2b). Borrowed Mana now
// uses lose_foresight (TimeBankEffects.cs).
'''),
])

edit('Scripts/Cards/Loader/CardScriptRegistry.Chronomancer.cs', [
(
'''        // { "type": "peek_intent", "range": n }  range 0 (default) = every enemy
        RegisterEffect("peek_intent", n =>
        {
            int range = n.TryGetProperty("range", out var r) ? r.GetInt32() : 0;
            return new PeekIntentEffect(range).WithTag("Foresight");
        });
''',
'''        // { "type": "peek_intent", "range": n, "lookahead": bool, "permanent": bool }
        // range 0 (default) = every enemy; lookahead also shows the NEXT intent;
        // permanent keeps it revealed for the rest of the fight.
        RegisterEffect("peek_intent", n =>
        {
            int range = n.TryGetProperty("range", out var r) ? r.GetInt32() : 0;
            bool look = n.TryGetProperty("lookahead", out var lk) && lk.GetBoolean();
            bool perm = n.TryGetProperty("permanent", out var pm) && pm.GetBoolean();
            return new PeekIntentEffect(range, look, perm).WithTag("Foresight");
        });
'''),
(
'''        // Borrowed Mana's repayment (2026-07-29): books a next-turn mana drain.
        // { "type": "mana_debt", "amount": n }
        RegisterEffect("mana_debt", n =>
        {
            int amount = n.TryGetProperty("amount", out var a) ? a.GetInt32() : 2;
            return new ManaDebtLeafEffect(amount).WithTag("Mana");
        });
''',
'''        // Overdrawn Time Bank (2026-10-03, replaces mana_debt): lose Foresight, may go below 0.
        // { "type": "lose_foresight", "amount": n }
        RegisterEffect("lose_foresight", n =>
        {
            int amount = n.TryGetProperty("amount", out var a) ? a.GetInt32() : 1;
            return new LoseForesightEffect(amount).WithTag("Foresight");
        });

        // Round-start snapshot (2026-10-03): back to the tile (and HP) held when the round began.
        // { "type": "return_to_round_start", "restore_hp": bool, "allies_only": bool,
        //   "all_allies": bool, "radius": n, "collision_damage": n, "foresight_cost": n }
        RegisterEffect("return_to_round_start", n => new ReturnToRoundStartEffect
        {
            RestoreHp = n.TryGetProperty("restore_hp", out var rh) && rh.GetBoolean(),
            AlliesOnly = n.TryGetProperty("allies_only", out var ao) && ao.GetBoolean(),
            AllAllies = n.TryGetProperty("all_allies", out var aa) && aa.GetBoolean(),
            Radius = n.TryGetProperty("radius", out var ra) ? ra.GetInt32() : 0,
            CollisionDamage = n.TryGetProperty("collision_damage", out var cd) ? cd.GetInt32() : 0,
            ForesightCost = n.TryGetProperty("foresight_cost", out var fc) ? fc.GetInt32() : 0,
        });
'''),
])

edit('Schemas/card.schema.json', [(
'''						"mana_debt"
''',
'''						"lose_foresight",
						"return_to_round_start"
''')])

# ════════════════════════════════════════════════════════════════════
# Lookahead + snapshot data (§2d, §2e)
# ════════════════════════════════════════════════════════════════════
edit('Scripts/Systems/Combat/Core/Unit.cs', [(
'''    public IntentTiming AttackTiming = IntentTiming.Normal;
''',
'''    public IntentTiming AttackTiming = IntentTiming.Normal;

    /// <summary>Lookahead stays revealed every round (The Fixed Hour, Glimpse's top rung).</summary>
    public bool IntentLookaheadPermanent;

    /// <summary>Round-start snapshot (class_identity_chronomancer_v1 §2e): the tile and
    /// HP this unit had when the current round began. Null tile: it arrived mid-round.</summary>
    public Vector2I? RoundStartTile;
    public int RoundStartHp;
''')])

edit('Scripts/Systems/Combat/Core/CombatManager.EnemyIntents.cs', [
(
'''    public ElementReaction PredictedReaction = ElementReaction.None;
''',
'''    public ElementReaction PredictedReaction = ElementReaction.None;

    /// <summary>Lookahead (class_identity_chronomancer_v1 §2d): the kind and a short
    /// description of the enemy's NEXT beat, forecast at planning. Shown only once
    /// <see cref="NextRevealed"/> is set (Glimpse) or the unit is under permanent lookahead.</summary>
    public IntentKind NextKind = IntentKind.Unknown;
    public string NextNote = "";
    public bool NextRevealed;
'''),
(
'''            if (enemy.CurrentIntent != null)
                enemy.CurrentIntent.Revealed = enemy.IntentPermanentlyRevealed;

            UpdateIntentDisplay(enemy);
''',
'''            if (enemy.CurrentIntent != null)
                enemy.CurrentIntent.Revealed = enemy.IntentPermanentlyRevealed;
            ForecastNextBeat(enemy);   // lookahead (chronomancer §2d), hidden until revealed

            UpdateIntentDisplay(enemy);
'''),
])

# Nameplate: "THEN <KIND>" tag + tooltip line.
edit('Scripts/UI/UnitNameplate.cs', [
(
'''    public ElementReaction IntentReaction = ElementReaction.None;
''',
'''    public ElementReaction IntentReaction = ElementReaction.None;
    /// <summary>Revealed lookahead: the next beat's kind word ("" when hidden) and note.</summary>
    public string IntentNext = "";
    public string IntentNextNote = "";
'''),
(
'''          .Append(',').Append(IntentTiming).Append(',').Append(IntentReaction)
''',
'''          .Append(',').Append(IntentTiming).Append(',').Append(IntentReaction)
          .Append(',').Append(IntentNext).Append(IntentNextNote)
'''),
])

edit('Scripts/UI/HealthBarRoot.cs', [(
'''            d.IntentReaction = intent.PredictedReaction;
''',
'''            d.IntentReaction = intent.PredictedReaction;
            d.IntentNext = intent.NextRevealed ? NextKindWord(intent.NextKind) : "";
            d.IntentNextNote = intent.NextRevealed ? (intent.NextNote ?? "") : "";
'''),
(
'''    /// <summary>Takes a Label3D off every camera without touching its Visible
''',
'''    /// <summary>Short word for a forecast next beat (nameplate "THEN ..." tag).</summary>
    private static string NextKindWord(IntentKind kind) => kind switch
    {
        IntentKind.Attack       => "ATTACK",
        IntentKind.RangedAttack => "SHOT",
        IntentKind.Channel      => "CHANNEL",
        IntentKind.Release      => "BLAST",
        IntentKind.Guard        => "GUARD",
        IntentKind.Imbue        => "IMBUE",
        IntentKind.Shove        => "SHOVE",
        _                       => "?",
    };

    /// <summary>Takes a Label3D off every camera without touching its Visible
'''),
])

edit('Scripts/UI/UnitNameplate.Intent.cs', [
(
'''        if (d.IntentReaction != ElementReaction.None)
            tags.Add(new IntentTag(ElementReactions.DisplayName(d.IntentReaction).ToUpperInvariant(),
                                   ElementColors.Reaction(d.IntentReaction), clock: false));
        return tags;
''',
'''        if (d.IntentReaction != ElementReaction.None)
            tags.Add(new IntentTag(ElementReactions.DisplayName(d.IntentReaction).ToUpperInvariant(),
                                   ElementColors.Reaction(d.IntentReaction), clock: false));
        if (!string.IsNullOrEmpty(d.IntentNext))
            tags.Add(new IntentTag($"THEN {d.IntentNext}", TemporalColor.Lightened(0.35f) with { A = 0.85f }, clock: false));
        return tags;
'''),
(
'''        if (d.IntentReaction != ElementReaction.None)
            sb.Append($"\\nWill form {ElementReactions.DisplayName(d.IntentReaction)} on the marked ground: {ElementReactions.Describe(d.IntentReaction)}");
''',
'''        if (d.IntentReaction != ElementReaction.None)
            sb.Append($"\\nWill form {ElementReactions.DisplayName(d.IntentReaction)} on the marked ground: {ElementReactions.Describe(d.IntentReaction)}");
        if (!string.IsNullOrEmpty(d.IntentNext))
            sb.Append($"\\nNext turn it {d.IntentNextNote}. Where it strikes is decided when it plans.");
'''),
])

# Almanac view: show maturity.
edit('Scripts/Systems/Combat/Core/CombatManager.AlmanacView.cs', [
(
'''                sig.Append(e.Label).Append('|').Append(e.TurnsRemaining).Append('|')
''',
'''                sig.Append(e.Label).Append('|').Append(e.TurnsRemaining).Append('|').Append(e.MaturityBonus).Append('|')
'''),
(
'''            text.Append($"{name}: {when}{where}");
''',
'''            text.Append($"{name}: {when}{where}");
            if (e.MaturityBonus > 0)
                text.Append($", matured +{e.MaturityBonus} damage");
'''),
])

# ════════════════════════════════════════════════════════════════════
# Register notes
# ════════════════════════════════════════════════════════════════════
p = os.path.join(root, 'Data/Register/barks.json')
data = json.load(open(p, encoding='utf-8'))
keys = [b['key'] for b in data['barks']]
assert 'chrono.overdrawn' not in keys
at = keys.index('strategic.first_council')
data['barks'][at:at] = [
    {"key": "chrono.overdrawn", "category": "explain", "once": True, "title": "Overdrawn",
     "lines": ["You have borrowed against the hour. The hour keeps accounts."],
     "note": "Your Time Bank is below zero. At the start of each of your turns you lose 2 HP for every point you owe (shield and armor do not help), and a full-bank free Reflex is off. Banking at the end of your turn (+1, plus unspent mana) pays the debt down. The bank cannot go below -3."},
    {"key": "chrono.matured", "category": "explain", "once": True, "title": "A matured spell",
     "lines": ["It waited. It is... stronger for the wait. Most things are not."],
     "note": "A scheduled spell gains 2 damage for every turn it waits beyond the first. Calling it forward early (Hasten, Sands of Time) lands it with what it has matured to so far."},
    {"key": "chrono.lookahead", "category": "explain", "once": True, "title": "Reading ahead",
     "lines": ["The next page, then. Read it quickly; it is still being... written."],
     "note": "Revealed enemies now show THEN and their next move on the nameplate: what they plan to do the turn after this one. It tells you what, not where: the target is chosen when they plan."},
]
with open(p, 'w', encoding='utf-8') as f:
    f.write(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
print("ok Data/Register/barks.json")
