#!/usr/bin/env python3
# Slice 7 card data: Glimpse lookahead, Borrowed Mana overdraft, Rewind/Recoil
# round-start returns, Adept permanent reveals. Run from the repo root.
import json, sys
C = 'Data/Cards/'
def load(n):
    with open(C + n + '.json', encoding='utf-8') as f: return json.load(f)
def save(n, d):
    with open(C + n + '.json', 'w', encoding='utf-8') as f:
        f.write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
def rung(d, tier, half):
    for u in d['upgrades']:
        if u['tier'] == tier and u['half'] == half: return u
    sys.exit(f"missing rung {d['id']} T{tier} {half}")
def drop_top(u):
    u['changes'] = [c for c in u['changes'] if c['half'] != 'top']
def top(field, value): return {'half': 'top', 'field': field, 'value': value}
def bot(field, value): return {'half': 'bottom', 'field': field, 'value': value}

# ── Glimpse ──
d = load('chronomancer_glimpse')
peek6 = {'type': 'peek_intent', 'range': 6, 'lookahead': True}
peekall = {'type': 'peek_intent', 'lookahead': True}
d['top']['effect'] = dict(peek6)
d['top']['rules_text'] = 'Reveal the next two intents of every enemy within 6.'
u = rung(d, 1, 'both'); drop_top(u)
u['description'] = 'More Foresight; sturdier ward.'
u['changes'][0:0] = [
    top('effect', {'type': 'sequence', 'steps': [dict(peek6), {'type': 'gain_foresight', 'amount': 2}]}),
    top('rules_text', 'Reveal the next two intents of every enemy within 6. Gain 2 Foresight.')]
u = rung(d, 2, 'top')
u['description'] = 'See the whole board two steps ahead. Draw 1.'
u['changes'] = [
    top('effect', {'type': 'sequence', 'steps': [dict(peekall), {'type': 'gain_foresight', 'amount': 2}, {'type': 'draw', 'count': 1}]}),
    top('rules_text', 'Reveal the next two intents of every enemy. Gain 2 Foresight. Draw 1 card.')]
oracle_tgt = {'type': 'unit', 'range': 6, 'enemies_only': True}
u = rung(d, 3, 'top')
u['description'] = 'See ahead, then move one attack to the end of the round.'
u['changes'] = [
    top('targeting', dict(oracle_tgt)),
    top('effect', {'type': 'sequence', 'steps': [dict(peekall), {'type': 'defer_intent'}, {'type': 'gain_foresight', 'amount': 2}, {'type': 'draw', 'count': 1}]}),
    top('rules_text', "Reveal the next two intents of every enemy. Defer target enemy's attack. Gain 2 Foresight. Draw 1 card.")]
u = rung(d, 4, 'top')
u['description'] = 'Sight that lasts the whole fight.'
u['changes'] = [
    top('targeting', dict(oracle_tgt)),
    top('effect', {'type': 'sequence', 'steps': [{'type': 'peek_intent', 'lookahead': True, 'permanent': True}, {'type': 'defer_intent'}, {'type': 'gain_foresight', 'amount': 2}]}),
    top('rules_text', "For the rest of the fight, see the next two intents of every enemy. Defer target enemy's attack. Gain 2 Foresight.")]
save('chronomancer_glimpse', d)

# ── Borrowed Mana ──
d = load('chronomancer_borrowed_mana')
steps = d['top']['effect']['steps']
assert steps[1]['type'] == 'mana_debt'
steps[1] = {'type': 'lose_foresight', 'amount': 2}
d['top']['rules_text'] = 'Gain 2 mana. Lose 2 Foresight (you may go Overdrawn).'
u = rung(d, 1, 'both')
u['description'] = 'Borrow more against the same debt. The repayment shields harder.'
u['changes'] += [
    top('rules_text', 'Gain 3 mana. Lose 2 Foresight (you may go Overdrawn).'),
    bot('rules_text', 'Gain 3 shield. Gain 1 Foresight.')]
save('chronomancer_borrowed_mana', d)

# ── Rewind ──
d = load('chronomancer_rewind')
def rw(**kw):
    e = {'type': 'return_to_round_start', 'restore_hp': True}
    e.update(kw); return e
ally_tgt = {'type': 'unit', 'range': 6}
d['top']['targeting'] = dict(ally_tgt)
d['top']['effect'] = rw(allies_only=True, foresight_cost=1)
d['top']['rules_text'] = 'Return target ally or yourself to the tile and HP it had at the start of this round. Spend 1 Foresight.'
u = rung(d, 1, 'both'); drop_top(u)
u['description'] = 'Free rewind; sturdier shield.'
u['changes'][0:0] = [
    top('effect', rw(allies_only=True)),
    top('rules_text', 'Return target ally or yourself to the tile and HP it had at the start of this round.')]
u = rung(d, 2, 'top'); u['top_name'] = 'Second Chance'
u['description'] = 'Rewind, and draw 1.'
u['changes'] = [
    top('effect', {'type': 'sequence', 'steps': [rw(allies_only=True), {'type': 'draw', 'count': 1}]}),
    top('rules_text', 'Return target ally or yourself to the tile and HP it had at the start of this round. Draw 1 card.')]
u = rung(d, 3, 'top'); u['top_name'] = 'Rally Point'
u['description'] = 'Rewind the whole party.'
u['changes'] = [
    top('targeting', {'type': 'self'}),
    top('effect', rw(all_allies=True, foresight_cost=1)),
    top('rules_text', 'Return every ally to the tile and HP it had at the start of this round. Spend 1 Foresight.')]
u = rung(d, 4, 'top')
u['description'] = 'The whole party, cheaper, and a card back.'
u['changes'] = [
    top('targeting', {'type': 'self'}),
    top('mana', 1),
    top('effect', {'type': 'sequence', 'steps': [rw(all_allies=True), {'type': 'draw', 'count': 1}]}),
    top('rules_text', 'Return every ally to the tile and HP it had at the start of this round. Draw 1 card.')]
save('chronomancer_rewind', d)

# ── Recoil ──
d = load('chronomancer_recoil')
def rc(coll, radius=0):
    e = {'type': 'return_to_round_start', 'collision_damage': coll}
    if radius: e['radius'] = radius
    return e
d['top']['targeting'] = {'type': 'unit', 'range': 5, 'enemies_only': True}
d['top']['effect'] = rc(4)
d['top']['rules_text'] = 'Return target enemy to the tile it started this round on. If that tile is taken, both units take 4 damage.'
u = rung(d, 1, 'both'); drop_top(u)
u['description'] = 'A harder snap back and a longer step.'
u['changes'][0:0] = [
    top('effect', rc(5)),
    top('rules_text', 'Return target enemy to the tile it started this round on. If that tile is taken, both units take 5 damage.')]
u = rung(d, 2, 'top')
u['description'] = 'Its neighbours go back too.'
u['changes'] = [
    top('effect', rc(5, 1)),
    top('rules_text', 'Return target enemy, and every enemy within 1 of it, to the tile each started this round on. If a tile is taken, both units take 5 damage.')]
u = rung(d, 3, 'top')
u['description'] = 'Snapped back and struck.'
u['changes'] = [
    top('effect', {'type': 'sequence', 'steps': [rc(5, 1), {'type': 'damage', 'amount': 3}]}),
    top('rules_text', 'Return target enemy, and every enemy within 1 of it, to the tile each started this round on. If a tile is taken, both units take 5 damage. Deal 3 damage to the target.')]
u = rung(d, 4, 'top')
u['description'] = 'The whole front line, returned with interest.'
u['changes'] = [
    top('effect', {'type': 'sequence', 'steps': [rc(7, 2), {'type': 'damage', 'amount': 4}]}),
    top('rules_text', 'Return target enemy, and every enemy within 2 of it, to the tile each started this round on. If a tile is taken, both units take 7 damage. Deal 4 damage to the target.')]
save('chronomancer_recoil', d)

# ── Adept permanent reveals ──
def perm(node):
    n = 0
    if isinstance(node, dict):
        if node.get('type') == 'peek_intent':
            node['permanent'] = True; n += 1
        for v in node.values(): n += perm(v)
    elif isinstance(node, list):
        for v in node: n += perm(v)
    return n
REVEAL = "reveal every enemy's intent for the rest of the fight"
TEXT = {
  'adept_survey': [
    ('Draw 1 card. Reveal the next action of all enemies.', "Draw 1 card. Reveal every enemy's intent for the rest of the fight."),
    ('Draw 2 cards. Reveal every enemy.', "Draw 2 cards. Reveal every enemy's intent for the rest of the fight."),
    ('Draw 2 cards, reveal every enemy, gain 1 shield.', "Draw 2 cards and gain 1 shield. Reveal every enemy's intent for the rest of the fight."),
    ('Draw 3 cards. Reveal every enemy.', "Draw 3 cards. Reveal every enemy's intent for the rest of the fight."),
    ('Draw 3 cards, reveal every enemy, gain 1 mana.', "Draw 3 cards and gain 1 mana. Reveal every enemy's intent for the rest of the fight."),
  ],
  'adept_flare': [
    ('Reveal the condition, archetype, and status of every enemy.', "Reveal every enemy's intent for the rest of the fight."),
    ('Reveal every enemy. Draw 1 card.', "Reveal every enemy's intent for the rest of the fight. Draw 1 card."),
    ('Reveal every enemy. Draw 1 card and gain 1 mana.', "Reveal every enemy's intent for the rest of the fight. Draw 1 card and gain 1 mana."),
  ],
  'adept_arcane_sight': [
    ('Draw 2 cards. Reveal every enemy.', "Draw 2 cards. Reveal every enemy's intent for the rest of the fight."),
  ],
}
def retext(node, old, new):
    n = 0
    if isinstance(node, dict):
        for k, v in node.items():
            if isinstance(v, str) and v == old and k in ('rules_text', 'value'):
                node[k] = new; n += 1
            else: n += retext(v, old, new)
    elif isinstance(node, list):
        for v in node: n += retext(v, old, new)
    return n
EXPECT_PEEK = {'adept_survey': 5, 'adept_flare': 3, 'adept_arcane_sight': 1}
for name, pairs in TEXT.items():
    d = load(name)
    got = perm(d)
    assert got == EXPECT_PEEK[name], (name, got)
    for old, new in pairs:
        assert retext(d, old, new) >= 1, (name, old)
    save(name, d)
print('slice 7 cards applied')
