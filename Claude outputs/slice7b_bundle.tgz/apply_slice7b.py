#!/usr/bin/env python3
# Slice 7b: anchor + phase controls and markers, aim arcs, Hasten/Advance fire repeating strikes.
import sys, os
root = sys.argv[1]
def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        assert n == 1, f"{rel}: expected 1 match, got {n} for:\n{old}"
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print("ok", rel)

# ── Unit ───────────────────────────────────────────────────────────────
edit('Scripts/Systems/Combat/Core/Unit.cs', [
('''    public int AnchorTurnsRemaining = 0;
''',
'''    public int AnchorTurnsRemaining = 0;

    /// <summary>Snap Back bonuses set by SetAnchorEffect (Temporal Anchor's ladder),
    /// paid each time the unit snaps to its anchor (CombatManager.Anchors.cs).</summary>
    public int AnchorSnapHeal;
    public int AnchorSnapShield;
    public int AnchorSnapForesight;

    /// <summary>A Fixed anchor (Temporal Anchor tier 4): the first hit that would kill
    /// the unit leaves it at 1 HP and snaps it home. Spent on use.</summary>
    public bool AnchorLethalSave;

    /// <summary>Round in which Snap Back / Phase Step was last used (once per turn each).</summary>
    public int AnchorSnapUsedRound = -1;
    public int PhaseStepUsedRound = -1;

    /// <summary>Raised when a Fixed anchor caught a lethal hit (HP already set to 1).
    /// CombatManager teleports the unit home.</summary>
    public static event Action<Unit> AnchorLethalSaved;
'''),
('''        Stats.Health = Math.Max(0, Stats.Health - hpLoss);
''',
'''        Stats.Health = Math.Max(0, Stats.Health - hpLoss);
        if (Stats.Health <= 0 && AnchorLethalSave && AnchorCoord != null && !IsDeathQueued)
        {
            Stats.Health = 1;
            AnchorLethalSave = false;
            AnchorLethalSaved?.Invoke(this);
        }
'''),
])

# ── GameState ──────────────────────────────────────────────────────────
edit('Scripts/Systems/GameStateManager.cs', [
('''    public int PhaseTileTurnsRemaining = 0;
''',
'''    public int PhaseTileTurnsRemaining = 0;

    /// <summary>The unit that made the Phase tiles: it alone may Phase Step.</summary>
    public Unit PhaseTileOwner;

    /// <summary>Foresight granted per Phase Step (Phase Anchor tier 4).</summary>
    public int PhaseStepForesight;
'''),
])

# ── Effects ────────────────────────────────────────────────────────────
edit('Scripts/Cards/Effects/ChronomancerEffects.cs', [
# SetAnchor
('''/// The anchor expires in <c>StartPlayerTurn</c> (see wiring doc §8).
/// JSON: { "type": "set_anchor", "turns": n }
/// </summary>
public sealed class SetAnchorEffect : EffectBase
{
	public int Turns;
	public SetAnchorEffect(int turns) { Turns = turns; }
''',
'''/// The anchor expires in <c>StartPlayerTurn</c> (see wiring doc §8). The unit snaps
/// back with the action bar's Snap Back button (CombatManager.Anchors.cs), which pays
/// the heal / shield / Foresight bonuses; lethal_save catches the first killing hit.
/// JSON: { "type": "set_anchor", "turns": n, "heal": n, "shield": n, "foresight": n,
///         "lethal_save": bool }
/// </summary>
public sealed class SetAnchorEffect : EffectBase
{
	public int Turns;
	public int Heal;
	public int Shield;
	public int Foresight;
	public bool LethalSave;
	public SetAnchorEffect(int turns, int heal = 0, int shield = 0, int foresight = 0, bool lethalSave = false)
	{
		Turns = turns;
		Heal = Math.Max(0, heal);
		Shield = Math.Max(0, shield);
		Foresight = Math.Max(0, foresight);
		LethalSave = lethalSave;
	}
'''),
('''		casterUnit.AnchorCoord = casterUnit.CurrentTile.Axial;
		casterUnit.AnchorTurnsRemaining = Turns;
''',
'''		casterUnit.AnchorCoord = casterUnit.CurrentTile.Axial;
		casterUnit.AnchorTurnsRemaining = Turns;
		casterUnit.AnchorSnapHeal = Heal;
		casterUnit.AnchorSnapShield = Shield;
		casterUnit.AnchorSnapForesight = Foresight;
		casterUnit.AnchorLethalSave = LethalSave;
'''),
# CreatePhaseTiles
('''/// JSON: { "type": "create_phase_tiles", "count": n, "turns": n }
/// </summary>
public sealed class CreatePhaseTilesEffect : EffectBase
{
	public int Count;
	public int Turns;

	public CreatePhaseTilesEffect(int count, int turns)
	{
		Count = count;
		Turns = turns;
	}
''',
'''/// A new network replaces the old one. Tiles: the targeted tile, then the caster's own
/// tile, then empty tiles near the target (farthest first) until Count is reached. Only
/// the caster may Phase Step (action bar, CombatManager.Anchors.cs).
/// JSON: { "type": "create_phase_tiles", "count": n, "turns": n, "step_foresight": n }
/// </summary>
public sealed class CreatePhaseTilesEffect : EffectBase
{
	public int Count;
	public int Turns;
	public int StepForesight;

	public CreatePhaseTilesEffect(int count, int turns, int stepForesight = 0)
	{
		Count = count;
		Turns = turns;
		StepForesight = Math.Max(0, stepForesight);
	}
'''),
('''		s.PhaseTiles ??= new List<Vector2I>();
		s.PhaseTileTurnsRemaining = Turns;
''',
'''		s.PhaseTiles ??= new List<Vector2I>();
		s.PhaseTiles.Clear();
		s.PhaseTileTurnsRemaining = Turns;
		s.PhaseTileOwner = s.ActiveCasterUnit;
		s.PhaseStepForesight = StepForesight;
'''),
('''		s.Log($"[PhaseTiles] Network of {s.PhaseTiles.Count} tile(s) active for {Turns} turn(s).");
''',
'''		// Fill the rest: the caster's own tile, then empty tiles near the first one.
		var casterTile = s.ActiveCasterUnit?.CurrentTile;
		if (added < Count && casterTile != null && !s.PhaseTiles.Contains(casterTile.Axial))
		{
			s.PhaseTiles.Add(casterTile.Axial);
			added++;
		}
		if (added < Count)
		{
			Vector2I centre = s.PhaseTiles.Count > 0 ? s.PhaseTiles[0] : casterTile?.Axial ?? default;
			var ring = new List<(int dist, Vector2I at)>();
			var seen = new HashSet<Vector2I> { centre };
			var frontier = new List<Vector2I> { centre };
			for (int d = 1; d <= 2; d++)
			{
				var next = new List<Vector2I>();
				foreach (var f in frontier)
					foreach (var nb in s.Grid.GetNeighbors(f))
						if (seen.Add(nb))
						{
							next.Add(nb);
							var t = s.Grid.GetTile(nb);
							if (t != null && t.IsWalkable && !t.IsBlocked && !t.IsOccupied && !s.PhaseTiles.Contains(nb))
								ring.Add((d, nb));
						}
				frontier = next;
			}
			ring.Sort((a, b) => b.dist.CompareTo(a.dist));   // farthest first: a network should spread
			int need = Count - added;
			int step = Math.Max(1, ring.Count / Math.Max(1, need));
			for (int i = 0; i < ring.Count && added < Count; i += step)
			{
				s.PhaseTiles.Add(ring[i].at);
				added++;
			}
		}

		s.Log($"[PhaseTiles] Network of {s.PhaseTiles.Count} tile(s) active for {Turns} turn(s).");
'''),
# Advance: also repeating strikes
('''		if (s.Almanac == null || s.Almanac.Count == 0)
		{
			s.Log("[Advance] No scheduled entries to advance.");
			return;
		}
''',
'''		if (s.Almanac == null || s.Almanac.Count == 0)
		{
			// A foreseen strike on a tile (Foregone Conclusion, Time Walk) lives in
			// ActiveEffects, not the Almanac: advancing it lands its next strike now.
			var strike = ScheduledStrikes.Soonest(s, caster);
			if (strike != null)
			{
				ScheduledStrikes.FireOne(s, strike, "[Advance]");
				return;
			}
			s.Log("[Advance] Nothing scheduled to advance.");
			return;
		}
'''),
# FastForward: almanac + strikes
('''		if (s.Almanac == null || s.Almanac.Count == 0)
		{
			s.Log("[FastForward] No scheduled entries.");
			return;
		}

		int fired = 0;
		while (fired < Count && s.Almanac.Count > 0)
		{
			// The caster's own entries first, soonest first; anyone's as a fallback.
			var entry = s.Almanac
				.Where(e => e.Caster == caster)
				.OrderBy(e => e.TurnsRemaining)
				.FirstOrDefault()
				?? s.Almanac.OrderBy(e => e.TurnsRemaining).First();

			s.Log($"[FastForward] Firing scheduled entry immediately.");
			s.Almanac.Remove(entry);   // removed first, so an entry that schedules again cannot loop
			entry.Fire(s);
			fired++;
		}
''',
'''		// 2026-10-03: also fires foreseen strikes on a tile (Foregone Conclusion, Time
		// Walk). Those live in ActiveEffects, so Hasten used to find "nothing scheduled"
		// while the Almanac view plainly listed them.
		int fired = 0;
		while (fired < Count)
		{
			// The caster's own first, soonest first; anyone's as a fallback. A strike's
			// next tick is always the coming turn, so it ranks as 1 turn away.
			var entry = s.Almanac == null || s.Almanac.Count == 0 ? null
				: s.Almanac.Where(e => !e.Hidden)
					.OrderBy(e => e.Caster == caster ? 0 : 1)
					.ThenBy(e => e.TurnsRemaining)
					.FirstOrDefault();
			var strike = ScheduledStrikes.Soonest(s, caster);
			if (entry == null && strike == null)
				break;

			bool takeEntry = entry != null && (strike == null
				|| (entry.Caster == caster ? 0 : 1, entry.TurnsRemaining).CompareTo((strike.Owner == caster ? 0 : 1, 1)) <= 0);
			if (takeEntry)
			{
				s.Log($"[FastForward] {entry.Label ?? "Scheduled spell"} resolves now.");
				s.Almanac.Remove(entry);   // removed first, so an entry that schedules again cannot loop
				entry.Fire(s);
			}
			else
			{
				ScheduledStrikes.FireOne(s, strike, "[FastForward]");
			}
			fired++;
		}

		if (fired == 0)
		{
			s.Log("[FastForward] Nothing scheduled to resolve.");
			return;
		}
'''),
])

# Helper class appended after FastForwardEffect (anchor on SetAnchor summary start)
edit('Scripts/Cards/Effects/ChronomancerEffects.cs', [
('''/// <summary>
/// Marks the caster's current tile as an anchor for <see cref="Turns"/> turns.
''',
'''/// <summary>Foreseen strikes on a tile (<see cref="DelayedDamageEffect"/>): the other
/// kind of scheduled spell, kept in GameState.ActiveEffects. Hasten and Advance reach
/// them through here.</summary>
internal static class ScheduledStrikes
{
	public static DelayedDamageEffect Soonest(GameState s, Entity caster) =>
		s?.ActiveEffects?.OfType<DelayedDamageEffect>()
			.Where(d => !d.IsExpired)
			.OrderBy(d => d.Owner == caster ? 0 : 1)
			.FirstOrDefault();

	/// <summary>Lands the strike's next hit now (one tick); removes it once spent.</summary>
	public static void FireOne(GameState s, DelayedDamageEffect dd, string tag)
	{
		s.Log($"{tag} {dd.Label ?? "Foreseen strike"} strikes ({dd.TargetCoord.X}, {dd.TargetCoord.Y}) now.");
		dd.Tick(s);
		if (dd.IsExpired)
			s.ActiveEffects.Remove(dd);
	}
}

/// <summary>
/// Marks the caster's current tile as an anchor for <see cref="Turns"/> turns.
'''),
])

# ── Registry ───────────────────────────────────────────────────────────
edit('Scripts/Cards/Loader/CardScriptRegistry.Chronomancer.cs', [
('''        // { "type": "set_anchor", "turns": n }
        RegisterEffect("set_anchor", n =>
        {
            int turns = n.TryGetProperty("turns", out var t) ? t.GetInt32() : 2;
            return new SetAnchorEffect(turns);
        });
''',
'''        // { "type": "set_anchor", "turns": n, "heal": n, "shield": n, "foresight": n, "lethal_save": bool }
        RegisterEffect("set_anchor", n =>
        {
            int turns = n.TryGetProperty("turns", out var t) ? t.GetInt32() : 2;
            int heal = n.TryGetProperty("heal", out var h) ? h.GetInt32() : 0;
            int shield = n.TryGetProperty("shield", out var sh) ? sh.GetInt32() : 0;
            int foresight = n.TryGetProperty("foresight", out var f) ? f.GetInt32() : 0;
            bool lethal = n.TryGetProperty("lethal_save", out var l) && l.GetBoolean();
            return new SetAnchorEffect(turns, heal, shield, foresight, lethal);
        });
'''),
('''        // { "type": "create_phase_tiles", "count": n, "turns": n }
        RegisterEffect("create_phase_tiles", n =>
        {
            int count = n.TryGetProperty("count", out var c) ? c.GetInt32() : 2;
            int turns = n.TryGetProperty("turns", out var t) ? t.GetInt32() : 3;
            return new CreatePhaseTilesEffect(count, turns);
        });
''',
'''        // { "type": "create_phase_tiles", "count": n, "turns": n, "step_foresight": n }
        RegisterEffect("create_phase_tiles", n =>
        {
            int count = n.TryGetProperty("count", out var c) ? c.GetInt32() : 2;
            int turns = n.TryGetProperty("turns", out var t) ? t.GetInt32() : 3;
            int stepForesight = n.TryGetProperty("step_foresight", out var sf) ? sf.GetInt32() : 0;
            return new CreatePhaseTilesEffect(count, turns, stepForesight);
        });
'''),
])

# ── Action bar ─────────────────────────────────────────────────────────
edit('Scripts/Systems/Combat/Core/CombatManager.Actions.cs', [
('''public enum UnitAction { None, Strike, Shove, Station, Interact, Brace, Swap }''',
 '''public enum UnitAction { None, Strike, Shove, Station, Interact, Brace, Swap, SnapBack, PhaseStep }'''),
('''        return list;
    }

    /// <summary>A bar button was pressed''',
'''
        // Chronomancer marked positions (CombatManager.Anchors.cs).
        if (unit.AnchorCoord != null)
        {
            list.Add(new UnitActionDef
            {
                Kind = UnitAction.SnapBack,
                Label = "Snap Back (free)",
                Tooltip = SnapTooltip(unit),
                Enabled = myTurn && WhyNoSnap(unit) == null,
                Armed = false,
            });
        }
        if (HasPhaseStep(unit))
        {
            list.Add(new UnitActionDef
            {
                Kind = UnitAction.PhaseStep,
                Label = "Phase Step (free)",
                Tooltip = PhaseTooltip(unit),
                Enabled = myTurn && WhyNoPhaseStep(unit) == null,
                Armed = _armedAction == UnitAction.PhaseStep,
            });
        }
        return list;
    }

    /// <summary>A bar button was pressed'''),
('''        if (kind == UnitAction.Brace)
        {
            DisarmAction(refresh: false);
            TryBrace(selectedUnit);
            return;
        }
''',
'''        if (kind == UnitAction.Brace)
        {
            DisarmAction(refresh: false);
            TryBrace(selectedUnit);
            return;
        }
        if (kind == UnitAction.SnapBack)
        {
            DisarmAction(refresh: false);
            TrySnapToAnchor(selectedUnit);
            RefreshSelectedUnitUI();
            return;
        }
'''),
('''                UnitAction.Swap => "Swap",
                _ => "",
            };
            combatUI?.SetHintText($"{what}: click a target. Right-click or Esc to cancel.");''',
'''                UnitAction.Swap => "Swap",
                UnitAction.PhaseStep => "Phase Step",
                _ => "",
            };
            combatUI?.SetHintText(_armedAction == UnitAction.PhaseStep
                ? "Phase Step: click a marked Phase tile. Right-click or Esc to cancel."
                : $"{what}: click a target. Right-click or Esc to cancel.");'''),
])

# ── CombatManager core ─────────────────────────────────────────────────
edit('Scripts/Systems/Combat/Core/CombatManager.cs', [
('''        InstallIntentTime();  // Chronomancer Defer / Advance hooks
''',
'''        InstallIntentTime();  // Chronomancer Defer / Advance hooks
        InstallAnchorHooks(); // Temporal Anchor lethal save
'''),
('''        UninstallIntentTime();
    }
''',
'''        UninstallIntentTime();
        UninstallAnchorHooks();
    }
'''),
('''        RefreshAlmanacView(); // Almanac list + tile markers; repaints only when it changed
''',
'''        RefreshAlmanacView(); // Almanac list + tile markers; repaints only when it changed
        RefreshAimLines();    // ranged intents: arc from the enemy to its locked tile
'''),
('''                // Interact armed: a click on a breakable wall is a blow, not a move.
''',
'''                // Phase Step armed: a click on a Phase tile teleports there.
                if (_armedAction == UnitAction.PhaseStep && selectedUnit != null)
                {
                    if (TryPhaseStep(selectedUnit, tile.Axial))
                        DisarmAction();
                    return;
                }

                // Interact armed: a click on a breakable wall is a blow, not a move.
'''),
('''                    unit.AnchorCoord = null;
                    GD.Print($"[Anchor] {unit.Name}'s anchor expired.");''',
'''                    unit.AnchorCoord = null;
                    unit.AnchorLethalSave = false;
                    GD.Print($"[Anchor] {unit.Name}'s anchor expired.");'''),
('''                State.PhaseTiles?.Clear();
                GD.Print("[PhaseTiles] Phase network expired.");''',
'''                State.PhaseTiles?.Clear();
                State.PhaseTileOwner = null;
                GD.Print("[PhaseTiles] Phase network expired.");'''),
])

# ── Almanac view: anchor + phase tile markers ─────────────────────────
edit('Scripts/Systems/Combat/Core/CombatManager.AlmanacView.cs', [
('''        string s = sig.ToString();
        if (s == _almanacSignature)
            return;''',
'''        foreach (var u in playerUnits)
        {
            if (u != null && IsInstanceValid(u) && u.Stats.IsAlive && u.AnchorCoord != null)
                sig.Append("A|").Append(u.GetInstanceId()).Append('|').Append(u.AnchorCoord.Value).Append('|')
                   .Append(u.AnchorTurnsRemaining).Append(';');
        }
        if (State?.PhaseTiles != null && State.PhaseTiles.Count > 0)
        {
            sig.Append("P|").Append(State.PhaseTileTurnsRemaining);
            foreach (var c in State.PhaseTiles)
                sig.Append('|').Append(c);
            sig.Append(';');
        }

        string s = sig.ToString();
        if (s == _almanacSignature)
            return;'''),
('''        combatUI?.SetAlmanac(text.Length > 0 ? text.ToString() : null);''',
'''        // Marked positions (Temporal Anchor, Phase Anchor): the tile shows what it is,
        // whose it is, and how long it holds. Snap Back / Phase Step are on the action bar.
        void Mark(Vector2I at, string line)
        {
            var tile = grid?.GetTile(at);
            if (tile == null)
                return;
            if (!perTile.TryGetValue(tile, out var list))
                perTile[tile] = list = new List<string>();
            list.Add(line);
        }
        static string Holds(int turns) => turns >= 99 ? "" : turns <= 1 ? " (THIS TURN)" : $" ({turns} TURNS)";
        foreach (var u in playerUnits)
        {
            if (u != null && IsInstanceValid(u) && u.Stats.IsAlive && u.AnchorCoord != null)
                Mark(u.AnchorCoord.Value, $"ANCHOR: {u.DisplayName.ToUpperInvariant()}{Holds(u.AnchorTurnsRemaining)}");
        }
        if (State?.PhaseTiles != null)
        {
            foreach (var c in State.PhaseTiles)
                Mark(c, $"PHASE TILE{Holds(State.PhaseTileTurnsRemaining)}");
        }

        combatUI?.SetAlmanac(text.Length > 0 ? text.ToString() : null);'''),
])
print("slice 7b code applied")
