#!/usr/bin/env python3
# Slice 7b cards: Temporal Anchor (Snap Back ladder), Phase Anchor (Phase Step ladder).
import json, sys
C = 'Data/Cards/'
def load(n):
    with open(C + n + '.json', encoding='utf-8') as f: return json.load(f)
def save(n, d):
    with open(C + n + '.json', 'w', encoding='utf-8') as f:
        f.write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
def rung(d, tier, half):
    for u in d['upgrades']:
        if u['tier'] == tier and u['half'] == half: return u
    sys.exit(f"missing rung {d['id']} T{tier} {half}")
def keep_only(u, half):
    u['changes'] = [c for c in u['changes'] if c['half'] != half]
def ch(half, field, value): return {'half': half, 'field': field, 'value': value}

# ── Temporal Anchor (top) ──
d = load('chronomancer_temporal_anchor')
def anc(turns, heal=0, shield=0, fs=0, lethal=False):
    e = {'type': 'set_anchor', 'turns': turns}
    if heal: e['heal'] = heal
    if shield: e['shield'] = shield
    if fs: e['foresight'] = fs
    if lethal: e['lethal_save'] = True
    return e
d['top']['effect'] = anc(2)
d['top']['rules_text'] = 'Mark your tile for 2 turns. Snap Back to it from the action bar: free, once per turn.'
u = rung(d, 1, 'both'); keep_only(u, 'top')
u['changes'][0:0] = [ch('top', 'effect', anc(3)),
    ch('top', 'rules_text', 'Mark your tile for 3 turns. Snap Back to it from the action bar: free, once per turn.')]
u = rung(d, 2, 'top')
u['description'] = 'Snapping back mends you.'
u['changes'] = [ch('top', 'effect', anc(3, heal=3, fs=1)),
    ch('top', 'rules_text', 'Mark your tile for 3 turns. Snap Back (free, once per turn): heal 3 HP and gain 1 Foresight.')]
u = rung(d, 3, 'top')
u['description'] = 'Snapping back also guards you.'
u['changes'] = [ch('top', 'effect', anc(3, heal=3, shield=3, fs=1)),
    ch('top', 'rules_text', 'Mark your tile for 3 turns. Snap Back (free, once per turn): heal 3 HP, gain 3 shield and 1 Foresight.')]
u = rung(d, 4, 'top')
u['description'] = 'Anchored for the whole fight, and death snaps you home.'
u['changes'] = [ch('top', 'effect', anc(99, heal=3, shield=3, fs=1, lethal=True)),
    ch('top', 'rules_text', 'Mark your tile for the fight. Snap Back (free, once per turn): heal 3 HP, gain 3 shield and 1 Foresight. The first hit that would kill you snaps you back at 1 HP instead.')]
save('chronomancer_temporal_anchor', d)

# ── Phase Anchor (Temporal Inversion bottom) ──
d = load('chronomancer_temporal_inversion')
def ph(count, turns, sf=0):
    e = {'type': 'create_phase_tiles', 'count': count, 'turns': turns}
    if sf: e['step_foresight'] = sf
    return e
d['bottom']['effect'] = ph(2, 3)
d['bottom']['rules_text'] = 'Make the target tile and your own tile Phase tiles for 3 turns. Phase Step between them from the action bar: free, once per turn.'
u = rung(d, 1, 'both'); keep_only(u, 'bottom')
u['changes'] += [ch('bottom', 'effect', ph(3, 3)),
    ch('bottom', 'rules_text', 'Make 3 Phase tiles for 3 turns: the target tile, your own, and one near the target. Phase Step between them from the action bar: free, once per turn.')]
u = rung(d, 2, 'bottom')
u['description'] = 'The network holds longer.'
u['changes'] = [ch('bottom', 'effect', ph(3, 4)),
    ch('bottom', 'rules_text', 'Make 3 Phase tiles for 4 turns: the target tile, your own, and one near the target. Phase Step between them from the action bar: free, once per turn.')]
u = rung(d, 3, 'bottom')
u['description'] = 'A wider network.'
u['changes'] = [ch('bottom', 'effect', ph(4, 4)),
    ch('bottom', 'rules_text', 'Make 4 Phase tiles for 4 turns: the target tile, your own, and two near the target. Phase Step between them from the action bar: free, once per turn.')]
u = rung(d, 4, 'bottom')
u['changes'] = [ch('bottom', 'effect', ph(4, 99, sf=1)),
    ch('bottom', 'rules_text', 'Make 4 Phase tiles for the fight: the target tile, your own, and two near the target. Phase Step between them (free, once per turn) and gain 1 Foresight each time.')]
save('chronomancer_temporal_inversion', d)
print('slice 7b cards applied')
