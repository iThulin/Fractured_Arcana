#!/usr/bin/env python3
# Slice 9 cards: the 13 new Chronomancer cards (class_identity_chronomancer_v1 §3) and
# the starter-deck swap (one Stolen Moment out, Slow Fuse in).
import json, os, sys
root = sys.argv[1] if len(sys.argv) > 1 else '.'
C = os.path.join(root, 'Data/Cards')

def seq(*s): return {'type': 'sequence', 'steps': list(s)}
def gf(n): return {'type': 'gain_foresight', 'amount': n}
def draw(n): return {'type': 'draw', 'count': n}
def dmg(n): return {'type': 'damage', 'amount': n}
def sh(n): return {'type': 'shield', 'amount': n}
def mana(n): return {'type': 'mana_gain', 'amount': n}
def lose(n): return {'type': 'lose_foresight', 'amount': n}
def defer(**k): e = {'type': 'defer_intent'}; e.update(k); return e
SELF = {'type': 'self'}
def unit(r=6, enemies=True, los=False):
    t = {'type': 'unit', 'range': r, 'los': los}
    if enemies: t['enemies_only'] = True
    return t
def tile(r): return {'type': 'tile', 'range': r}
def aoe(r): return {'type': 'aoe', 'radius': r, 'enemies_only': True}

def half(name, mana_, speed, text, targeting, effect):
    return {'name': name, 'mana': mana_, 'speed': speed, 'rules_text': text,
            'tags': ['temporal'], 'targeting': targeting, 'effect': effect}

def rung(tier, h, name, desc, changes_by_half):
    """changes_by_half: {'top': {field: value}, 'bottom': {...}}"""
    u = {'tier': tier, 'half': h}
    if h == 'both':
        u['top_name'], u['bottom_name'] = name
    else:
        u['top_name' if h == 'top' else 'bottom_name'] = name
    u['description'] = desc
    u['changes'] = [{'half': hh, 'field': f, 'value': v}
                    for hh, fields in changes_by_half.items() for f, v in fields.items()]
    return u

def card(cid, name, rarity, top, bottom, upgrades):
    d = {'id': cid, 'status': 'ready', 'name': name, 'school': 'Chronomancer', 'rarity': rarity,
         'top': top, 'bottom': bottom, 'upgrades': upgrades}
    p = os.path.join(C, cid + '.json')
    if os.path.exists(p) and os.environ.get('SLICE9_OVERWRITE') != '1':
        sys.exit(f'{p} already exists; refusing to overwrite')
    with open(p, 'w', encoding='utf-8') as f:
        f.write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
    print('wrote', p)

def T(effect, text, **extra):
    d = {'effect': effect, 'rules_text': text}
    d.update(extra)
    return d

# ── A. The Fatekeeper ─────────────────────────────────────────────────
def ra(look_perm=False): 
    e = {'type': 'peek_intent', 'lookahead': True, 'target_only': True}
    if look_perm: e['permanent'] = True
    return e
RA = "Reveal target enemy's next two intents."
card('chronomancer_read_ahead', 'Read Ahead', 'Common',
     half('Read Ahead', 1, 'Studied', RA + ' Gain 1 Foresight.', unit(8), seq(ra(), gf(1))),
     half('Hold That Thought', 1, 'Reflex', "Defer target enemy's attack.", unit(8), defer()),
     [rung(1, 'both', ('Read Ahead+', 'Hold That Thought+'), 'A card for the reading; a coin for the wait.',
           {'top': T(seq(ra(), gf(1), draw(1)), RA + ' Gain 1 Foresight. Draw 1 card.'),
            'bottom': T(seq(defer(), gf(1)), "Defer target enemy's attack. Gain 1 Foresight.")}),
      rung(2, 'top', 'Read Further', 'More banked.', {'top': T(seq(ra(), gf(2), draw(1)), RA + ' Gain 2 Foresight. Draw 1 card.')}),
      rung(2, 'bottom', 'Hold Them All', 'Its neighbours wait too.',
           {'bottom': T(seq(defer(radius=1), gf(1)), "Defer the attack of target enemy and every enemy within 1 of it. Gain 1 Foresight.")}),
      rung(3, 'top', 'Know Them', 'You keep reading it.',
           {'top': T(seq(ra(True), gf(2), draw(1)), "For the rest of the fight, see target enemy's next two intents. Gain 2 Foresight. Draw 1 card.")}),
      rung(3, 'bottom', 'Hold Fast', 'More banked.',
           {'bottom': T(seq(defer(radius=1), gf(2)), "Defer the attack of target enemy and every enemy within 1 of it. Gain 2 Foresight.")}),
      rung(4, 'top', 'Open Book', 'Free.',
           {'top': T(seq(ra(True), gf(2), draw(1)), "For the rest of the fight, see target enemy's next two intents. Gain 2 Foresight. Draw 1 card.", mana=0)}),
      rung(4, 'bottom', 'Stopped Clock', 'Free.',
           {'bottom': T(seq(defer(radius=1), gf(2)), "Defer the attack of target enemy and every enemy within 1 of it. Gain 2 Foresight.", mana=0)})])

GH = 'Defer the attacks of every enemy within {r} of the target point.'
def pd(m): return {'type': 'gain_foresight_per_deferred', 'max': m}
PD = 'Gain 1 Foresight for each Deferred attack on the board (max {m}).'
card('chronomancer_the_gathering_hour', 'The Gathering Hour', 'Uncommon',
     half('The Gathering Hour', 2, 'Studied', GH.format(r=2), aoe(2), defer()),
     half('Count the Hours', 1, 'Reflex', PD.format(m=3), SELF, pd(3)),
     [rung(1, 'both', ('The Gathering Hour+', 'Count the Hours+'), 'A little banked on both faces.',
           {'top': T(seq(defer(), gf(1)), GH.format(r=2) + ' Gain 1 Foresight.'),
            'bottom': T(seq(pd(3), sh(3)), PD.format(m=3) + ' Gain 3 shield.')}),
      rung(2, 'top', 'The Long Hour', 'A wider gathering.',
           {'top': T(seq(defer(), gf(1)), GH.format(r=3) + ' Gain 1 Foresight.', targeting=aoe(3))}),
      rung(2, 'bottom', 'Count Further', 'Counts higher.', {'bottom': T(seq(pd(4), sh(3)), PD.format(m=4) + ' Gain 3 shield.')}),
      rung(3, 'top', 'The Heavy Hour', 'More banked.',
           {'top': T(seq(defer(), gf(2)), GH.format(r=3) + ' Gain 2 Foresight.', targeting=aoe(3))}),
      rung(3, 'bottom', 'Tally', 'And a card.', {'bottom': T(seq(pd(4), draw(1)), PD.format(m=4) + ' Draw 1 card.')}),
      rung(4, 'top', 'The Appointed Hour', 'Cheaper.',
           {'top': T(seq(defer(), gf(2)), GH.format(r=3) + ' Gain 2 Foresight.', targeting=aoe(3), mana=1)}),
      rung(4, 'bottom', 'Reckoning', 'Free.', {'bottom': T(seq(pd(4), draw(1)), PD.format(m=4) + ' Draw 1 card.', mana=0)})])

DUE = {'type': 'advance_intent', 'deferred_only': True}
DT = 'Every Deferred attack lands now, on its locked tile, fastest attacker first.'
def cancel(c): return {'type': 'cancel_deferred', 'foresight_cost': c}
CT = "Cancel target enemy's Deferred attack: it never happens."
card('chronomancer_the_hour_comes_due', 'The Hour Comes Due', 'Rare',
     half('The Hour Comes Due', 3, 'Studied', DT, SELF, DUE),
     half('Stay of Execution', 2, 'Reflex', CT + ' Spend 2 Foresight.', unit(8), cancel(2)),
     [rung(1, 'both', ('The Hour Comes Due+', 'Stay of Execution+'), 'Cheaper to stay; a little banked when it falls.',
           {'top': T(seq(DUE, gf(1)), DT + ' Gain 1 Foresight.'),
            'bottom': T(cancel(1), CT + ' Spend 1 Foresight.')}),
      rung(2, 'top', 'Due Now', 'Cheaper.', {'top': T(seq(DUE, gf(1)), DT + ' Gain 1 Foresight.', mana=2)}),
      rung(2, 'bottom', 'Reprieve', 'Cheaper.', {'bottom': T(cancel(1), CT + ' Spend 1 Foresight.', mana=1)}),
      rung(3, 'top', 'Overdue', 'More banked.', {'top': T(seq(DUE, gf(2)), DT + ' Gain 2 Foresight.', mana=2)}),
      rung(3, 'bottom', 'Pardon', 'No Foresight needed.', {'bottom': T(cancel(0), CT, mana=1)}),
      rung(4, 'top', 'The Bill Arrives', 'And a card.', {'top': T(seq(DUE, gf(2), draw(1)), DT + ' Gain 2 Foresight. Draw 1 card.', mana=2)}),
      rung(4, 'bottom', 'Clemency', 'Free.', {'bottom': T(seq(cancel(0), gf(1)), CT + ' Gain 1 Foresight.', mana=0)})])

# ── B. The Long Game ──────────────────────────────────────────────────
def fuse(n): return {'type': 'schedule', 'turns': 1, 'do': dmg(n)}
FT = 'Schedule: at the start of your next turn, deal {n} damage to whatever stands on the target tile.'
card('chronomancer_slow_fuse', 'Slow Fuse', 'Common',
     half('Slow Fuse', 1, 'Studied', FT.format(n=6), tile(5), fuse(6)),
     half('Patience', 1, 'Reflex', 'Gain 4 shield. Gain 1 Foresight.', SELF, seq(sh(4), gf(1))),
     [rung(1, 'both', ('Slow Fuse+', 'Patience+'), 'A bigger charge; a thicker guard.',
           {'top': T(fuse(7), FT.format(n=7)), 'bottom': T(seq(sh(5), gf(1)), 'Gain 5 shield. Gain 1 Foresight.')}),
      rung(2, 'top', 'Long Fuse', 'Bigger.', {'top': T(fuse(8), FT.format(n=8))}),
      rung(2, 'bottom', 'Forbearance', 'Thicker.', {'bottom': T(seq(sh(6), gf(1)), 'Gain 6 shield. Gain 1 Foresight.')}),
      rung(3, 'top', 'Lit and Waiting', 'And a little banked.',
           {'top': T(seq(fuse(8), gf(1)), FT.format(n=8) + ' Gain 1 Foresight.')}),
      rung(3, 'bottom', 'Endurance', 'More banked.', {'bottom': T(seq(sh(6), gf(2)), 'Gain 6 shield. Gain 2 Foresight.')}),
      rung(4, 'top', 'Powder Keg', 'A real charge.', {'top': T(seq(fuse(10), gf(1)), FT.format(n=10) + ' Gain 1 Foresight.')}),
      rung(4, 'bottom', 'Stillness', 'Free.', {'bottom': T(seq(sh(6), gf(2)), 'Gain 6 shield. Gain 2 Foresight.', mana=0)})])

def delay(n): return {'type': 'delay_scheduled', 'turns': n}
PH = 'Delay your soonest scheduled spell by {n} turn{s}. It matures while it waits (+2 damage per turn).'
def mv(r): return {'type': 'move_scheduled', 'reach': r}
MV = 'Move one of your scheduled spells aimed within {r} of the target tile onto it.'
card('chronomancer_patient_hand', 'Patient Hand', 'Uncommon',
     half('Patient Hand', 1, 'Studied', PH.format(n=1, s='') + ' Draw 1 card.', SELF, seq(delay(1), draw(1))),
     half('Shift the Mark', 1, 'Reflex', MV.format(r=1), tile(8), mv(1)),
     [rung(1, 'both', ('Patient Hand+', 'Shift the Mark+'), 'Banked patience; a longer reach.',
           {'top': T(seq(delay(1), draw(1), gf(1)), PH.format(n=1, s='') + ' Draw 1 card. Gain 1 Foresight.'),
            'bottom': T(mv(2), MV.format(r=2))}),
      rung(2, 'top', 'Patient Study', 'More cards.', {'top': T(seq(delay(1), draw(2)), PH.format(n=1, s='') + ' Draw 2 cards.')}),
      rung(2, 'bottom', 'Shift and Bank', 'And a coin.', {'bottom': T(seq(mv(2), gf(1)), MV.format(r=2) + ' Gain 1 Foresight.')}),
      rung(3, 'top', 'Long Patience', 'Two turns of ripening.', {'top': T(seq(delay(2), draw(2)), PH.format(n=2, s='s') + ' Draw 2 cards.')}),
      rung(3, 'bottom', 'Wide Shift', 'Further.', {'bottom': T(seq(mv(3), gf(1)), MV.format(r=3) + ' Gain 1 Foresight.')}),
      rung(4, 'top', 'Patience Rewarded', 'Free.', {'top': T(seq(delay(2), draw(2)), PH.format(n=2, s='s') + ' Draw 2 cards.', mana=0)}),
      rung(4, 'bottom', 'Sleight of Hours', 'Free.', {'bottom': T(seq(mv(3), gf(1)), MV.format(r=3) + ' Gain 1 Foresight.', mana=0)})])

EPH = {'type': 'ephemeris'}
ET = 'For the rest of the fight, the first spell you cast each turn is copied: the copy resolves again, on the same targets, at the start of your next turn.'
FF = {'type': 'fast_forward', 'count': 99, 'foresight_cost': 0}
FT2 = 'All your scheduled spells resolve now.'
card('chronomancer_ephemeris', 'Ephemeris', 'Rare',
     half('Ephemeris', 3, 'Studied', ET, SELF, EPH),
     half('Conjunction', 1, 'Reflex', FT2, SELF, FF),
     [rung(1, 'both', ('Ephemeris+', 'Conjunction+'), 'A little banked; a guard as they land.',
           {'top': T(seq(EPH, gf(1)), ET + ' Gain 1 Foresight.'), 'bottom': T(seq(FF, sh(3)), FT2 + ' Gain 3 shield.')}),
      rung(2, 'top', 'Almanac of Days', 'Cheaper.', {'top': T(seq(EPH, gf(1)), ET + ' Gain 1 Foresight.', mana=2)}),
      rung(2, 'bottom', 'Free Conjunction', 'Free.', {'bottom': T(seq(FF, sh(3)), FT2 + ' Gain 3 shield.', mana=0)}),
      rung(3, 'top', 'Almanac of Years', 'And a card.', {'top': T(seq(EPH, gf(1), draw(1)), ET + ' Gain 1 Foresight. Draw 1 card.', mana=2)}),
      rung(3, 'bottom', 'Alignment', 'And a coin.', {'bottom': T(seq(FF, gf(1)), FT2 + ' Gain 1 Foresight.', mana=0)}),
      rung(4, 'top', 'The Turning Sky', 'Cheaper still.', {'top': T(seq(EPH, gf(1), draw(1)), ET + ' Gain 1 Foresight. Draw 1 card.', mana=1)}),
      rung(4, 'bottom', 'Syzygy', 'And a card.', {'bottom': T(seq(FF, gf(1), draw(1)), FT2 + ' Gain 1 Foresight. Draw 1 card.', mana=0)})])

# ── C. The Debtor ─────────────────────────────────────────────────────
BS = 'Deal {n} damage. Lose 2 Foresight (you may go Overdrawn).'
BB = 'Gain {n} shield. Lose 1 Foresight (you may go Overdrawn).'
card('chronomancer_borrowed_strength', 'Borrowed Strength', 'Common',
     half('Borrowed Strength', 1, 'Studied', BS.format(n=9), unit(6, los=True), seq(dmg(9), lose(2))),
     half('Borrowed Guard', 0, 'Reflex', BB.format(n=4), SELF, seq(sh(4), lose(1))),
     [rung(1, 'both', ('Borrowed Strength+', 'Borrowed Guard+'), 'More for the same debt.',
           {'top': T(seq(dmg(10), lose(2)), BS.format(n=10)), 'bottom': T(seq(sh(5), lose(1)), BB.format(n=5))}),
      rung(2, 'top', 'Borrowed Might', 'Harder.', {'top': T(seq(dmg(11), lose(2)), BS.format(n=11))}),
      rung(2, 'bottom', 'Borrowed Wall', 'Thicker.', {'bottom': T(seq(sh(6), lose(1)), BB.format(n=6))}),
      rung(3, 'top', 'Borrowed Fury', 'Harder still.', {'top': T(seq(dmg(12), lose(2)), BS.format(n=12))}),
      rung(3, 'bottom', 'Borrowed Bulwark', 'Thicker still.', {'bottom': T(seq(sh(7), lose(1)), BB.format(n=7))}),
      rung(4, 'top', 'Debt of Iron', 'Ruinous.', {'top': T(seq(dmg(14), lose(2)), BS.format(n=14))}),
      rung(4, 'bottom', 'Debt of Stone', 'Unbreakable, nearly.', {'bottom': T(seq(sh(8), lose(1)), BB.format(n=8))})])

def ci(per, mn): return {'type': 'damage_per_overdraft', 'per': per, 'min': mn}
CIT = 'Deal {p} damage for each point you are Overdrawn (minimum {m}).'
def repay(n): return {'type': 'repay_overdraft', 'amount': n}
RPT = 'Repay {n} point{s} of Overdraft. Gain {sh} shield.'
card('chronomancer_compound_interest', 'Compound Interest', 'Uncommon',
     half('Compound Interest', 1, 'Studied', CIT.format(p=3, m=3), unit(6, los=True), ci(3, 3)),
     half('Installment', 1, 'Reflex', RPT.format(n=1, s='', sh=4), SELF, seq(repay(1), sh(4))),
     [rung(1, 'both', ('Compound Interest+', 'Installment+'), 'A higher floor; a thicker guard.',
           {'top': T(ci(3, 4), CIT.format(p=3, m=4)), 'bottom': T(seq(repay(1), sh(5)), RPT.format(n=1, s='', sh=5))}),
      rung(2, 'top', 'Usury', 'Steeper interest.', {'top': T(ci(4, 4), CIT.format(p=4, m=4))}),
      rung(2, 'bottom', 'Settlement', 'Pays more down.', {'bottom': T(seq(repay(2), sh(5)), RPT.format(n=2, s='s', sh=5))}),
      rung(3, 'top', 'Arrears', 'A higher floor.', {'top': T(ci(4, 5), CIT.format(p=4, m=5))}),
      rung(3, 'bottom', 'Clean Ledger', 'Thicker.', {'bottom': T(seq(repay(2), sh(6)), RPT.format(n=2, s='s', sh=6))}),
      rung(4, 'top', 'Foreclosure', 'Ruinous interest.', {'top': T(ci(5, 5), CIT.format(p=5, m=5))}),
      rung(4, 'bottom', 'Paid in Full', 'Free.', {'bottom': T(seq(repay(2), sh(6)), RPT.format(n=2, s='s', sh=6), mana=0)})])

def mort(d, m, o): return seq(draw(d), mana(m), {'type': 'lose_foresight', 'to_overdraft': o})
MT = 'Draw {d} cards and gain {m} mana. Your Time Bank drops to Overdrawn {o}.'
def lien(lo, hi, extra=()): return seq({'type': 'conditional', 'if': {'type': 'overdrawn'}, 'then': mana(hi), 'else': mana(lo)}, *extra)
LT = 'Gain {lo} mana, or {hi} if you are Overdrawn.'
card('chronomancer_mortgage_the_hour', 'Mortgage the Hour', 'Rare',
     half('Mortgage the Hour', 2, 'Studied', MT.format(d=3, m=3, o=3), SELF, mort(3, 3, 3)),
     half('Lien', 1, 'Reflex', LT.format(lo=1, hi=2), SELF, lien(1, 2)),
     [rung(1, 'both', ('Mortgage the Hour+', 'Lien+'), 'A bigger loan; a guard on the lien.',
           {'top': T(mort(4, 3, 3), MT.format(d=4, m=3, o=3)), 'bottom': T(lien(1, 2, (sh(2),)), LT.format(lo=1, hi=2) + ' Gain 2 shield.')}),
      rung(2, 'top', 'Second Mortgage', 'More mana.', {'top': T(mort(4, 4, 3), MT.format(d=4, m=4, o=3))}),
      rung(2, 'bottom', 'Free Lien', 'Free.', {'bottom': T(lien(1, 2, (sh(2),)), LT.format(lo=1, hi=2) + ' Gain 2 shield.', mana=0)}),
      rung(3, 'top', 'Easy Terms', 'Cheaper.', {'top': T(mort(4, 4, 3), MT.format(d=4, m=4, o=3), mana=1)}),
      rung(3, 'bottom', 'Deep Lien', 'More when deep.', {'bottom': T(lien(1, 3), LT.format(lo=1, hi=3), mana=0)}),
      rung(4, 'top', 'Generous Terms', 'A shallower debt.', {'top': T(mort(4, 4, 2), MT.format(d=4, m=4, o=2), mana=1)}),
      rung(4, 'bottom', 'Lien on Tomorrow', 'And a card.', {'bottom': T(lien(1, 3, (draw(1),)), LT.format(lo=1, hi=3) + ' Draw 1 card.', mana=0)})])

# ── D. The Clockwright ────────────────────────────────────────────────
def hd(b): return {'type': 'hasten_decay', 'bonus': b}
HD = 'Every Burn and Bleed on target enemy deals all its remaining damage now, then ends.'
def ext(n): return {'type': 'extend_buffs', 'turns': n}
EX = 'Each buff on target ally lasts {n} more turn{s}.'
card('chronomancer_hasten_decay', 'Hasten Decay', 'Common',
     half('Hasten Decay', 1, 'Studied', HD, unit(6), hd(0)),
     half('Linger', 1, 'Reflex', EX.format(n=1, s=''), unit(6, enemies=False), ext(1)),
     [rung(1, 'both', ('Hasten Decay+', 'Linger+'), 'A little banked on both faces.',
           {'top': T(seq(hd(0), gf(1)), HD + ' Gain 1 Foresight.'), 'bottom': T(seq(ext(1), gf(1)), EX.format(n=1, s='') + ' Gain 1 Foresight.')}),
      rung(2, 'top', 'Rot', 'It comes due with interest.', {'top': T(seq(hd(2), gf(1)), HD + ' It deals 2 extra. Gain 1 Foresight.')}),
      rung(2, 'bottom', 'Long Linger', 'Two turns.', {'bottom': T(ext(2), EX.format(n=2, s='s'))}),
      rung(3, 'top', 'Ruin', 'More interest.', {'top': T(seq(hd(3), gf(1)), HD + ' It deals 3 extra. Gain 1 Foresight.')}),
      rung(3, 'bottom', 'Lasting Grace', 'And a coin.', {'bottom': T(seq(ext(2), gf(1)), EX.format(n=2, s='s') + ' Gain 1 Foresight.')}),
      rung(4, 'top', 'Entropy', 'Free.', {'top': T(seq(hd(3), gf(1)), HD + ' It deals 3 extra. Gain 1 Foresight.', mana=0)}),
      rung(4, 'bottom', 'Evergreen', 'Free.', {'bottom': T(seq(ext(2), gf(1)), EX.format(n=2, s='s') + ' Gain 1 Foresight.', mana=0)})])

W = {'type': 'wither'}
WT = 'Target enemy loses all its shield and every buff.'
def ps(m): return {'type': 'gain_foresight_per_status', 'max': m}
PS = 'Gain 1 Foresight for each status on target unit (max {m}).'
card('chronomancer_wither_the_hour', 'Wither the Hour', 'Uncommon',
     half('Wither the Hour', 2, 'Studied', WT, unit(6), W),
     half('Read the Signs', 1, 'Reflex', PS.format(m=3), unit(8, enemies=False), ps(3)),
     [rung(1, 'both', ('Wither the Hour+', 'Read the Signs+'), 'A little banked; a guard while reading.',
           {'top': T(seq(W, gf(1)), WT + ' Gain 1 Foresight.'), 'bottom': T(seq(ps(3), sh(2)), PS.format(m=3) + ' Gain 2 shield.')}),
      rung(2, 'top', 'Withering Glance', 'Cheaper.', {'top': T(seq(W, gf(1)), WT + ' Gain 1 Foresight.', mana=1)}),
      rung(2, 'bottom', 'Read Deeper', 'Counts higher.', {'bottom': T(seq(ps(4), sh(2)), PS.format(m=4) + ' Gain 2 shield.')}),
      rung(3, 'top', 'Blight of Hours', 'And it hurts.', {'top': T(seq(W, dmg(4), gf(1)), WT + ' Deal 4 damage. Gain 1 Foresight.', mana=1)}),
      rung(3, 'bottom', 'Omens', 'And a card.', {'bottom': T(seq(ps(4), draw(1)), PS.format(m=4) + ' Draw 1 card.')}),
      rung(4, 'top', 'Dust and Hours', 'It hurts more.', {'top': T(seq(W, dmg(6), gf(1)), WT + ' Deal 6 damage. Gain 1 Foresight.', mana=1)}),
      rung(4, 'bottom', 'Augury', 'Free.', {'bottom': T(seq(ps(4), draw(1)), PS.format(m=4) + ' Draw 1 card.', mana=0)})])

RM = {'type': 'return_to_round_start', 'all_units': True}
RMT = 'Every unit returns to the tile it held at the start of this round. A unit whose tile is taken stays put.'
def pm(m): return {'type': 'gain_foresight_per_moved', 'max': m}
PM = 'Gain 1 Foresight for each unit that moved this round (max {m}).'
card('chronomancer_return_to_the_moment', 'Return to the Moment', 'Rare',
     half('Return to the Moment', 3, 'Studied', RMT, SELF, RM),
     half('Measure the Moment', 1, 'Reflex', PM.format(m=3), SELF, pm(3)),
     [rung(1, 'both', ('Return to the Moment+', 'Measure the Moment+'), 'A little banked; a guard while measuring.',
           {'top': T(seq(RM, gf(1)), RMT + ' Gain 1 Foresight.'), 'bottom': T(seq(pm(3), sh(3)), PM.format(m=3) + ' Gain 3 shield.')}),
      rung(2, 'top', 'Return Again', 'Cheaper.', {'top': T(seq(RM, gf(1)), RMT + ' Gain 1 Foresight.', mana=2)}),
      rung(2, 'bottom', 'Measure Further', 'Counts higher.', {'bottom': T(seq(pm(4), sh(3)), PM.format(m=4) + ' Gain 3 shield.')}),
      rung(3, 'top', 'The Moment Kept', 'More banked.', {'top': T(seq(RM, gf(2)), RMT + ' Gain 2 Foresight.', mana=2)}),
      rung(3, 'bottom', 'Measured Step', 'And a card.', {'bottom': T(seq(pm(4), draw(1)), PM.format(m=4) + ' Draw 1 card.')}),
      rung(4, 'top', 'As It Was', 'And a card.', {'top': T(seq(RM, gf(2), draw(1)), RMT + ' Gain 2 Foresight. Draw 1 card.', mana=2)}),
      rung(4, 'bottom', 'The Measure of All', 'Free.', {'bottom': T(seq(pm(4), draw(1)), PM.format(m=4) + ' Draw 1 card.', mana=0)})])

# ── Legendary ─────────────────────────────────────────────────────────
FH = {'type': 'fixed_hour'}
FHT = ("For the rest of the fight, you see every enemy's next two intents, and once per round you may "
       "Defer one attack for free (Defer on the action bar).")
ALL = {'type': 'advance_intent', 'radius': 99, 'reverse_speed': True}
ALT = "Every enemy's attack lands now, on its locked tile, slowest attacker first."
card('chronomancer_the_fixed_hour', 'The Fixed Hour', 'Legendary',
     half('The Fixed Hour', 4, 'Studied', FHT, SELF, FH),
     half('Midnight', 3, 'Reflex', ALT, SELF, ALL),
     [rung(1, 'both', ('The Fixed Hour+', 'Midnight+'), 'Banked insight on both faces.',
           {'top': T(seq(FH, gf(2)), FHT + ' Gain 2 Foresight.'), 'bottom': T(seq(ALL, gf(1)), ALT + ' Gain 1 Foresight.')}),
      rung(2, 'top', 'The Settled Hour', 'Cheaper.', {'top': T(seq(FH, gf(2)), FHT + ' Gain 2 Foresight.', mana=3)}),
      rung(2, 'bottom', 'Witching Hour', 'Cheaper.', {'bottom': T(seq(ALL, gf(1)), ALT + ' Gain 1 Foresight.', mana=2)}),
      rung(3, 'top', 'The Certain Hour', 'And a card.', {'top': T(seq(FH, gf(2), draw(1)), FHT + ' Gain 2 Foresight. Draw 1 card.', mana=3)}),
      rung(3, 'bottom', 'Small Hours', 'More banked.', {'bottom': T(seq(ALL, gf(2)), ALT + ' Gain 2 Foresight.', mana=2)}),
      rung(4, 'top', 'The Hour Unending', 'Cheaper still.', {'top': T(seq(FH, gf(2), draw(1)), FHT + ' Gain 2 Foresight. Draw 1 card.', mana=2)}),
      rung(4, 'bottom', 'The Last Stroke', 'Cheaper still.', {'bottom': T(seq(ALL, gf(2)), ALT + ' Gain 2 Foresight.', mana=1)})])

# ── Starter deck: one Stolen Moment out, Slow Fuse in ─────────────────
p = os.path.join(root, 'Data/StarterDecks/chronomancer_starter.json')
d = json.load(open(p, encoding='utf-8'))
ids = [c['id'] for c in d['cards']]
assert 'chronomancer_slow_fuse' not in ids, 'starter already has Slow Fuse'
for c in d['cards']:
    if c['id'] == 'chronomancer_stolen_moment':
        assert c['count'] == 2
        c['count'] = 1
d['cards'].append({'id': 'chronomancer_slow_fuse', 'count': 1})
open(p, 'w', encoding='utf-8').write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
print('wrote', p)
print('slice 9 cards applied')
