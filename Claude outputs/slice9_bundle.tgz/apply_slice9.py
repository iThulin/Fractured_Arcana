#!/usr/bin/env python3
# Slice 9 (code): engine support for the 13 new Chronomancer cards.
import sys, os
root = sys.argv[1]
def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        assert n == 1, f"{rel}: expected 1 match, got {n} for:\n{old}"
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print("ok", rel)

edit('Scripts/Systems/Combat/Core/Unit.cs', [
('''    /// <summary>Lookahead stays revealed every round (The Fixed Hour, Glimpse's top rung).</summary>
    public bool IntentLookaheadPermanent;
''',
'''    /// <summary>Lookahead stays revealed every round (The Fixed Hour, Glimpse's top rung).</summary>
    public bool IntentLookaheadPermanent;

    /// <summary>Ephemeris (chronomancer §3): the first spell this unit casts each turn is
    /// copied into the Almanac (ChronoHooks.OnSpellResolved). Reset per turn in StartPlayerTurn.</summary>
    public bool EphemerisActive;
    public bool EphemerisFiredThisTurn;

    /// <summary>The Fixed Hour: this unit has a free Defer each round (action bar).</summary>
    public bool HasFixedHour;
    public int FixedHourDeferRound = -1;
'''),
])

edit('Scripts/Systems/GameStateManager.cs', [
('''    /// <summary>Foresight granted per Phase Step (Phase Anchor tier 4).</summary>
    public int PhaseStepForesight;
''',
'''    /// <summary>Foresight granted per Phase Step (Phase Anchor tier 4).</summary>
    public int PhaseStepForesight;

    /// <summary>The Fixed Hour was cast: every enemy plan (and its next beat) is revealed
    /// for the rest of the fight, new arrivals included.</summary>
    public bool FixedHourActive;
'''),
])

edit('Scripts/Systems/Combat/Core/RulesManager.cs', [
('''        s.LastResolvedItem = item;
''',
'''        s.LastResolvedItem = item;
        ChronoHooks.OnSpellResolved(s, item);   // Ephemeris (chronomancer §3)
'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.cs', [
('''            unit.HasSwitchedStanceThisTurn = false;
''',
'''            unit.HasSwitchedStanceThisTurn = false;
            unit.EphemerisFiredThisTurn = false;   // Ephemeris: a new turn's first spell
'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.EnemyIntents.cs', [
('''            if (thirdEye)
                enemy.IntentPermanentlyRevealed = true;''',
'''            if (thirdEye || State.FixedHourActive)
                enemy.IntentPermanentlyRevealed = true;'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.TimeSight.cs', [
('''        intent.NextRevealed = enemy.IntentLookaheadPermanent;''',
'''        intent.NextRevealed = enemy.IntentLookaheadPermanent || State.FixedHourActive;'''),
])

edit('Scripts/Cards/Effects/IntentTimeEffects.cs', [
('''    public static string Defer(Unit enemy) => DeferHook != null ? DeferHook(enemy) : "no combat is running";''',
'''    public static string Defer(Unit enemy) => DeferHook != null ? DeferHook(enemy) : "no combat is running";

    /// <summary>Cancel a Deferred attack: it never lands (The Hour Comes Due).</summary>
    public static Func<Unit, string> CancelHook;
    public static string Cancel(Unit enemy) => CancelHook != null ? CancelHook(enemy) : "no combat is running";'''),
('''public sealed class AdvanceIntentEffect : EffectBase
{
    public int Radius;
    public AdvanceIntentEffect(int radius = 0) { Radius = Math.Max(0, radius); }

    public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
    {
        var primaries = new List<Unit>();
        if (targets?.Items != null)
            foreach (var obj in targets.Items)
                primaries.Add(ResolveTargetUnit(s, obj));

        var victims = IntentTime.Victims(s, primaries, Radius);''',
'''public sealed class AdvanceIntentEffect : EffectBase
{
    public int Radius;
    /// <summary>Only attacks already Deferred (The Hour Comes Due), whoever was targeted.</summary>
    public bool DeferredOnly;
    /// <summary>Slowest attacker first (The Fixed Hour's bottom half); otherwise fastest first.</summary>
    public bool ReverseSpeed;
    public AdvanceIntentEffect(int radius = 0) { Radius = Math.Max(0, radius); }

    public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
    {
        var primaries = new List<Unit>();
        if (targets?.Items != null)
            foreach (var obj in targets.Items)
                primaries.Add(ResolveTargetUnit(s, obj));

        List<Unit> victims;
        if (DeferredOnly)
            victims = s?.UnitsInPlay?.Where(u => u != null && !u.IsPlayerControlled && u.Stats.IsAlive
                                                 && u.AttackTiming == IntentTiming.Deferred).ToList()
                      ?? new List<Unit>();
        else
            victims = IntentTime.Victims(s, primaries, Radius);
        victims = ReverseSpeed
            ? victims.OrderBy(u => u.Stats.BaseSpeed).ToList()
            : victims.OrderByDescending(u => u.Stats.BaseSpeed).ToList();'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.IntentTime.cs', [
('''        IntentTime.RevealHook = RevealForEffect;
    }
''',
'''        IntentTime.RevealHook = RevealForEffect;
        IntentTime.CancelHook = CancelDeferred;
    }

    /// <summary>The Hour Comes Due (bottom): a Deferred attack never lands. The enemy
    /// still takes its turn, without the blow.</summary>
    private string CancelDeferred(Unit enemy)
    {
        if (!IsValidActor(enemy))
            return "it cannot act";
        if (enemy.AttackTiming != IntentTiming.Deferred)
            return "its attack is not Deferred";
        _deferredAttacks.RemoveAll(e => e.enemy == enemy);
        enemy.AttackTiming = IntentTiming.Spent;
        string msg = $"{enemy.Name}'s Deferred attack is cancelled. It never happens.";
        GD.Print($"[Defer] {msg}");
        combatUI?.AppendActionLog(msg);
        UpdateIntentDisplay(enemy);
        RefreshThreatTiles();
        return null;
    }
'''),
('''            string spent = $"{enemy.Name} acts without its attack; it has already landed.";''',
'''            string spent = $"{enemy.Name} acts without its attack.";'''),
('''        if (IntentTime.AdvanceHook == AdvanceAttack)''',
'''        if (IntentTime.CancelHook == CancelDeferred)
            IntentTime.CancelHook = null;
        if (IntentTime.AdvanceHook == AdvanceAttack)'''),
])

edit('Scripts/Cards/Effects/ChronomancerEffects.cs', [
('''	/// <summary>Keep what was revealed visible for the rest of the fight (Adept reveals).</summary>
	public bool Permanent;''',
'''	/// <summary>Keep what was revealed visible for the rest of the fight (Adept reveals).</summary>
	public bool Permanent;
	/// <summary>Only the targeted enemies (Read Ahead), not everyone in range.</summary>
	public bool TargetOnly;'''),
('''		s.Log("[PeekIntent] Enemy intel:");
		int revealed = 0;
		foreach (var unit in s.UnitsInPlay)
		{''',
'''		s.Log("[PeekIntent] Enemy intel:");
		int revealed = 0;
		var only = new HashSet<Unit>();
		if (TargetOnly && targets?.Items != null)
			foreach (var obj in targets.Items)
			{
				var t = ResolveTargetUnit(s, obj);
				if (t != null)
					only.Add(t);
			}
		foreach (var unit in s.UnitsInPlay)
		{
			if (TargetOnly && !only.Contains(unit))
				continue;'''),
])

edit('Scripts/Cards/Effects/TimeBankEffects.cs', [
('''using Godot;
using System;
using System.Collections.Generic;
''',
'''using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
'''),
('''    public int Amount;
    public LoseForesightEffect(int amount) { Amount = Math.Max(0, amount); }
''',
'''    public int Amount;
    /// <summary>When set (n &gt; 0), lose exactly enough to sit at Overdrawn n instead
    /// (Mortgage the Hour: "your bank drops to Overdrawn 3").</summary>
    public int ToOverdraft;
    public LoseForesightEffect(int amount) { Amount = Math.Max(0, amount); }
'''),
('''        int before = fate.Charges;
        int lost = fate.LoseCharges(Amount);''',
'''        int before = fate.Charges;
        int want = ToOverdraft > 0 ? Math.Max(0, fate.Charges + ToOverdraft) : Amount;
        int lost = fate.LoseCharges(want);'''),
('''              + (lost < Amount ? $" (the bank cannot go below {FateAttunement.MinCharges})." : "."));''',
'''              + (lost < want ? $" (the bank cannot go below {FateAttunement.MinCharges})." : "."));'''),
('''    public int ForesightCost;

    public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
    {
        if (s?.Grid == null)
            return;''',
'''    public int ForesightCost;
    /// <summary>Every living unit on the board, both sides (Return to the Moment). Units
    /// whose start tile is held by another returning unit get further passes, so a chain
    /// of swaps resolves; whoever is still blocked after that stays put.</summary>
    public bool AllUnits;

    public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
    {
        if (s?.Grid == null)
            return;
        if (AllUnits)
        {
            ReturnEveryone(s);
            return;
        }'''),
('''    /// <summary>True when the unit changed tile or HP.</summary>''',
'''    private void ReturnEveryone(GameState s)
    {
        var pending = (s.UnitsInPlay ?? new List<Unit>())
            .Where(u => u != null && GodotObject.IsInstanceValid(u) && u.Stats.IsAlive && u.CurrentTile != null
                        && u.RoundStartTile.HasValue && u.CurrentTile.Axial != u.RoundStartTile.Value)
            .ToList();
        int moved = 0;
        for (int pass = 0; pass < 4 && pending.Count > 0; pass++)
        {
            var still = new List<Unit>();
            foreach (var u in pending)
            {
                var dest = s.Grid.GetTile(u.RoundStartTile.Value);
                if (dest != null && dest.Occupant == null && dest.CanEnter(u))
                {
                    u.PlaceOnTile(dest);
                    moved++;
                }
                else
                    still.Add(u);
            }
            if (still.Count == pending.Count)
                break;   // nobody could move this pass: the rest are truly blocked
            pending = still;
        }
        foreach (var u in pending)
            s.Log($"[ReturnToRoundStart] {u.Name}'s start tile is taken. It stays put.");
        s.Log($"[ReturnToRoundStart] {moved} unit(s) returned to where the round began.");
    }

    /// <summary>True when the unit changed tile or HP.</summary>'''),
])

edit('Scripts/Cards/Loader/CardScriptRegistry.Chronomancer.cs', [
('''            bool perm = n.TryGetProperty("permanent", out var pm) && pm.GetBoolean();
            return new PeekIntentEffect(range, look, perm).WithTag("Foresight");''',
'''            bool perm = n.TryGetProperty("permanent", out var pm) && pm.GetBoolean();
            var peek = new PeekIntentEffect(range, look, perm);
            peek.TargetOnly = n.TryGetProperty("target_only", out var to) && to.GetBoolean();
            return peek.WithTag("Foresight");'''),
('''            int radius = n.TryGetProperty("radius", out var r) ? r.GetInt32() : 0;
            return new AdvanceIntentEffect(radius).WithTag("Control");''',
'''            int radius = n.TryGetProperty("radius", out var r) ? r.GetInt32() : 0;
            var adv = new AdvanceIntentEffect(radius)
            {
                DeferredOnly = n.TryGetProperty("deferred_only", out var d) && d.GetBoolean(),
                ReverseSpeed = n.TryGetProperty("reverse_speed", out var rs) && rs.GetBoolean(),
            };
            return adv.WithTag("Control");'''),
('''            int amount = n.TryGetProperty("amount", out var a) ? a.GetInt32() : 1;
            return new LoseForesightEffect(amount).WithTag("Foresight");''',
'''            int amount = n.TryGetProperty("amount", out var a) ? a.GetInt32() : 1;
            var lose = new LoseForesightEffect(amount);
            if (n.TryGetProperty("to_overdraft", out var to))
                lose.ToOverdraft = to.GetInt32();
            return lose.WithTag("Foresight");'''),
('''            ForesightCost = n.TryGetProperty("foresight_cost", out var fc) ? fc.GetInt32() : 0,
        });
    }
}''',
'''            ForesightCost = n.TryGetProperty("foresight_cost", out var fc) ? fc.GetInt32() : 0,
            AllUnits = n.TryGetProperty("all_units", out var au) && au.GetBoolean(),
        });

        // ── The 13 new cards (chronomancer §3, slice 9) ─────────────────────
        static int I(System.Text.Json.JsonElement n, string k, int d) => n.TryGetProperty(k, out var v) ? v.GetInt32() : d;
        RegisterEffect("gain_foresight_per_deferred", n => new GainForesightPerDeferredEffect(I(n, "max", 3)).WithTag("Foresight"));
        RegisterEffect("cancel_deferred", n => new CancelDeferredEffect(I(n, "foresight_cost", 2)).WithTag("Control"));
        RegisterEffect("delay_scheduled", n => new DelayScheduledEffect(I(n, "turns", 1)).WithTag("Foresight"));
        RegisterEffect("move_scheduled", n => new MoveScheduledEffect(I(n, "reach", 1)).WithTag("Foresight"));
        RegisterEffect("ephemeris", _ => new EphemerisEffect().WithTag("Foresight"));
        RegisterEffect("damage_per_overdraft", n => new DamagePerOverdraftEffect(I(n, "per", 3), I(n, "min", 3)).WithTag("Damage"));
        RegisterEffect("repay_overdraft", n => new RepayOverdraftEffect(I(n, "amount", 1)).WithTag("Foresight"));
        RegisterEffect("hasten_decay", n => new HastenDecayEffect(I(n, "bonus", 0)).WithTag("Damage"));
        RegisterEffect("extend_buffs", n => new ExtendBuffsEffect(I(n, "turns", 1)).WithTag("Status"));
        RegisterEffect("wither", _ => new WitherEffect().WithTag("Status"));
        RegisterEffect("gain_foresight_per_status", n => new GainForesightPerStatusEffect(I(n, "max", 3)).WithTag("Foresight"));
        RegisterEffect("gain_foresight_per_moved", n => new GainForesightPerMovedEffect(I(n, "max", 3)).WithTag("Foresight"));
        RegisterEffect("fixed_hour", _ => new FixedHourEffect().WithTag("Foresight"));
    }
}'''),
])

edit('Scripts/Cards/Loader/JsonCardLoader.cs', [
('''        // Spells cast this turn at least: { "type": "spells_cast_this_turn", "threshold": n }''',
'''        // Chronomancer: the Time Bank is below zero: { "type": "overdrawn" }
        RegisterPredicate("overdrawn", _ => new OverdrawnPredicate());

        // Spells cast this turn at least: { "type": "spells_cast_this_turn", "threshold": n }'''),
])

A = 'Scripts/Systems/Combat/Core/CombatManager.Actions.cs'
edit(A, [
('''public enum UnitAction { None, Strike, Shove, Station, Interact, Brace, Swap, SnapBack, PhaseStep }''',
 '''public enum UnitAction { None, Strike, Shove, Station, Interact, Brace, Swap, SnapBack, PhaseStep, FreeDefer }'''),
('''        if (HasPhaseStep(unit))
        {''',
'''        if (unit.HasFixedHour)
        {
            bool used = unit.FixedHourDeferRound == roundNumber;
            list.Add(new UnitActionDef
            {
                Kind = UnitAction.FreeDefer,
                Label = "Defer (free)",
                Tooltip = "The Fixed Hour: once per round, click an enemy to Defer its attack to the end of the round."
                          + (used ? " Already used this round." : ""),
                Enabled = myTurn && !used,
                Armed = _armedAction == UnitAction.FreeDefer,
            });
        }
        if (HasPhaseStep(unit))
        {'''),
('''                UnitAction.PhaseStep => "Phase Step",''',
'''                UnitAction.PhaseStep => "Phase Step",
                UnitAction.FreeDefer => "Defer (The Fixed Hour)",'''),
('''            case UnitAction.Swap:
                if (!TryDanceSwap(selectedUnit, target)) return false;
                break;''',
'''            case UnitAction.Swap:
                if (!TryDanceSwap(selectedUnit, target)) return false;
                break;
            case UnitAction.FreeDefer:
            {
                if (!selectedUnit.HasFixedHour || selectedUnit.FixedHourDeferRound == roundNumber)
                    return false;
                string why = IntentTime.Defer(target);
                if (why != null)
                {
                    combatUI?.AppendActionLog($"Can't Defer {target.Name}: {why}.");
                    return true;   // armed click consumed; the button stays available
                }
                selectedUnit.FixedHourDeferRound = roundNumber;
                break;
            }'''),
])

# schema enum
p = os.path.join(root, 'Schemas/card.schema.json')
s = open(p, encoding='utf-8').read()
old = '''						"lose_foresight",
						"return_to_round_start"'''
assert s.count(old) == 1
new_types = ["schedule_last", "gain_foresight_per_scheduled", "gain_foresight_per_deferred", "cancel_deferred",
             "delay_scheduled", "move_scheduled", "ephemeris", "damage_per_overdraft", "repay_overdraft",
             "hasten_decay", "extend_buffs", "wither", "gain_foresight_per_status", "gain_foresight_per_moved",
             "fixed_hour"]
s = s.replace(old, old + ''.join(f',\n\t\t\t\t\t\t"{t}"' for t in new_types))
open(p, 'w', encoding='utf-8').write(s)
print("ok Schemas/card.schema.json")
print("slice 9 code applied")
