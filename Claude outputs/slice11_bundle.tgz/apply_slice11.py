#!/usr/bin/env python3
# Slice 11: Enchanter engine. Compel is walked movement (compel_walk + path preview);
# Names are conditions that punish (name_condition, NameBroken, nameplate chips);
# the Weave holds while glyphs OR Names stand and gains 1 per break. Compel, Charm
# Drift and Geas converted.
import sys, os, json
root = sys.argv[1]
def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        assert n == 1, f"{rel}: expected 1 match, got {n} for:\n{old}"
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print("ok", rel)

edit('Scripts/Systems/Combat/Core/Unit.cs', [
('''    /// <summary>Lookahead stays revealed every round (The Fixed Hour, Glimpse's top rung).</summary>
    public bool IntentLookaheadPermanent;
''',
'''    /// <summary>Lookahead stays revealed every round (The Fixed Hour, Glimpse's top rung).</summary>
    public bool IntentLookaheadPermanent;

    /// <summary>Enchanter Names on this unit (EnchanterEngine.cs): conditions that punish.</summary>
    public List<NameCondition> Names = new();
'''),
])

edit('Scripts/Cards/Loader/CardScriptRegistry.Enchanter.cs', [
('''        // Geas: status whose on-move punish lives in the status system
        // { "type": "geas", "duration": n }
        RegisterEffect("geas", n =>
        {
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 2;
            return new StatusApplyEffect("geas", dur, "(on-move punish needs status hook)").WithTag("Control");
        });''',
'''        // Geas (2026-10-04, slice 11): a real Name now, not a status with no hook.
        // { "type": "geas", "damage": n, "duration": n, "punish_cast": bool }
        RegisterEffect("geas", n =>
        {
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 2;
            int dmg = n.TryGetProperty("damage", out var dm) ? dm.GetInt32() : 6;
            var trig = NameTrigger.Move;
            if (n.TryGetProperty("punish_cast", out var pc) && pc.ValueKind == System.Text.Json.JsonValueKind.True)
                trig |= NameTrigger.Cast;
            return new NameConditionEffect(trig, dmg, dur).WithTag("Control");
        });

        // Names (class_identity_enchanter_v1 §2b): a condition that punishes.
        // { "type": "name_condition", "trigger": "move"|"attack"|"cast"|"act" or [..], "damage": n, "duration": n }
        RegisterEffect("name_condition", n =>
        {
            var trig = NameTrigger.None;
            void Add(string w)
            {
                trig |= (w ?? "").ToLowerInvariant() switch
                {
                    "move" or "moves" => NameTrigger.Move,
                    "attack" or "attacks" => NameTrigger.Attack,
                    "cast" or "casts" => NameTrigger.Cast,
                    _ => NameTrigger.Any,
                };
            }
            if (n.TryGetProperty("trigger", out var t))
            {
                if (t.ValueKind == System.Text.Json.JsonValueKind.Array)
                    foreach (var e in t.EnumerateArray()) Add(e.GetString());
                else
                    Add(t.GetString());
            }
            int dmg = n.TryGetProperty("damage", out var dm) ? dm.GetInt32() : 4;
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 2;
            return new NameConditionEffect(trig, dmg, dur).WithTag("Control");
        });

        // Compel (§2a): the target WALKS (walked entry rules), toward you or a chosen way.
        // { "type": "compel_walk", "tiles": n, "mode": "toward_caster" | "direction" }
        RegisterEffect("compel_walk", n =>
        {
            int tiles = n.TryGetProperty("tiles", out var t) ? t.GetInt32() : 2;
            bool dir = n.TryGetProperty("mode", out var m) && m.GetString() == "direction";
            return new CompelWalkEffect(tiles, dir).WithTag("Movement");
        });'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.cs', [
('''        InstallAnchorHooks(); // Temporal Anchor lethal save
''',
'''        InstallAnchorHooks(); // Temporal Anchor lethal save
        InstallEnchanterHooks(); // Names break on walk; breaks feed the Weave
'''),
('''        UninstallAnchorHooks();
        CardUi.HalfSpentProvider = null;''',
'''        UninstallAnchorHooks();
        UninstallEnchanterHooks();
        CardUi.HalfSpentProvider = null;'''),
('''        RegisterManager.Fire("combat.basics.move");
''',
'''        RegisterManager.Fire("combat.basics.move");
        TickNames();   // Enchanter Names lose a turn; the break round advances
'''),
('''            if (unit.Attunement is WeaveAttunement w)
                w.OnTurnEnd(State.Glyphs.CountFriendly(unit.TeamId) > 0);''',
'''            // Enchanter §2c: the Weave holds while you have prepared glyphs OR Named units.
            if (unit.Attunement is WeaveAttunement w)
                w.OnTurnEnd(State.Glyphs.CountFriendly(unit.TeamId) > 0
                            || Names.AnyWrittenBy(State.UnitsInPlay, unit.TeamId));'''),
('''        string prompt = $"{half.Name} → {victim.Name}. {ts.StepTwoPrompt} (Esc or right-click to cancel.)";''',
'''        string stepTwo = ShowCompelDirectionPaths(half, victim)
            ? "Click a tile beside it: it walks that way (outlined: where each direction leads)."
            : ts.StepTwoPrompt;
        string prompt = $"{half.Name} → {victim.Name}. {stepTwo} (Esc or right-click to cancel.)";'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.EnemyIntents.cs', [
('''        LastStrikeVictim = null;
        bool wasRedirected = redirected != null && IsInstanceValid(redirected) && redirected.Stats.IsAlive;''',
'''        LastStrikeVictim = null;
        // Enchanter Names: an attack breaks "if it attacks" (the blow still lands; Names punish, never forbid).
        if (attacker != null && IsInstanceValid(attacker))
            Names.Break(attacker, NameTrigger.Attack, LogName);
        bool wasRedirected = redirected != null && IsInstanceValid(redirected) && redirected.Stats.IsAlive;'''),
('''            case IntentKind.Channel:
                if (IsRitualist(enemy))
                    await ExecuteRitualStart(enemy, intent);''',
'''            case IntentKind.Channel:
                Names.Break(enemy, NameTrigger.Cast, LogName);   // starting a spell is casting
                if (!IsValidActor(enemy))
                    break;
                if (IsRitualist(enemy))
                    await ExecuteRitualStart(enemy, intent);'''),
('''            case IntentKind.Release:
                if (IsRitualist(enemy))
                    await ExecuteRitualRelease(enemy, intent);''',
'''            case IntentKind.Release:
                Names.Break(enemy, NameTrigger.Cast, LogName);
                if (!IsValidActor(enemy))
                    break;
                if (IsRitualist(enemy))
                    await ExecuteRitualRelease(enemy, intent);'''),
('''            case IntentKind.Imbue:
                await ExecuteImbueIntent(enemy, intent);
                break;
            case IntentKind.Shove:
                await ExecuteShoveIntent(enemy, intent);
                break;''',
'''            case IntentKind.Imbue:
                Names.Break(enemy, NameTrigger.Cast, LogName);
                if (!IsValidActor(enemy))
                    break;
                await ExecuteImbueIntent(enemy, intent);
                break;
            case IntentKind.Shove:
                Names.Break(enemy, NameTrigger.Attack, LogName);
                if (!IsValidActor(enemy))
                    break;
                await ExecuteShoveIntent(enemy, intent);
                break;'''),
])

edit('Scripts/Systems/Combat/Core/CombatManager.CastPreview.cs', [
('''                _trace.Show(grid, center, aim, bolt ? TrajectoryTrace.Style.Straight : TrajectoryTrace.Style.Lob,
                            blocker?.Axial, coverStop || !inRange || (blocker != null && (u.los || bolt)));
                break;''',
'''                _trace.Show(grid, center, aim, bolt ? TrajectoryTrace.Style.Straight : TrajectoryTrace.Style.Lob,
                            blocker?.Axial, coverStop || !inRange || (blocker != null && (u.los || bolt)));
                ShowCompelPathPreview(_draggedHalf, aim);   // Enchanter: where a Compel walks it
                break;'''),
])

edit('Scripts/UI/StatusCatalog.cs', [
('''        if (u.ArmedReaction != null)''',
'''        // Enchanter Names (§2b): every Name shows its condition on the plate. Required:
        // glyphs, Names and compelled walks are only readable if every one is visible.
        foreach (var name in u.Names)
        {
            if (name.TurnsRemaining <= 0)
                continue;
            string words = name.TriggerWords();
            var info = new StatusInfo($"If it {words}: {name.Damage}",
                                      $"IF {words.ToUpperInvariant().Replace(" OR ", "/").Replace(", ", "/")}: {name.Damage}",
                                      StatusTone.Mark,
                                      $"Named by {name.Source}: if it {words}, it takes {name.Damage} damage (once a round). {{n}} turn(s) left.");
            list.Add(new UnitCondition($"name:{(int)name.Triggers}:{name.Damage}", info, name.TurnsRemaining));
        }

        if (u.ArmedReaction != null)'''),
])

# ── barks ──
p = os.path.join(root, 'Data/Register/barks.json')
d = json.load(open(p, encoding='utf-8'))
keys = {b.get('key') for b in d['barks']}
new = [
    {'key': 'ench.first_name', 'category': 'explain', 'once': True, 'title': 'A Name',
     'lines': ['It has been Named. It may still do as it likes. It will simply... pay.'],
     'note': 'A Named unit shows its condition on its nameplate, such as "If it moves: 6". It can still do that thing; '
             'if it does, it takes the damage (once a round) and the Name is broken, which gives you 1 Weave.'},
    {'key': 'ench.name_broken', 'category': 'comment', 'once': False, 'cooldown': 30,
     'lines': ['Broken. As written.', 'It chose. The Name was clear about what that would cost.']},
    {'key': 'ench.compel', 'category': 'explain', 'once': True, 'title': 'Compelled',
     'lines': ['It walks because it was told to. It walks over whatever is in the way.'],
     'note': 'A compelled unit walks, it is not shoved: your glyphs trigger, Fire sears and Frost slides as it steps, '
             'but there is no collision damage and it cannot be walked off a ledge. A blocked step ends the walk.'},
]
for b in new:
    assert b['key'] not in keys, b['key']
    d['barks'].append(b)
open(p, 'w', encoding='utf-8').write(json.dumps(d, indent=2, ensure_ascii=False) + '\n')
print('ok', p)

# ── schema ──
p = os.path.join(root, 'Schemas/card.schema.json')
s = open(p, encoding='utf-8').read()
old = '''						"fixed_hour"'''
assert s.count(old) == 1
s = s.replace(old, old + ',\n\t\t\t\t\t\t"compel_walk",\n\t\t\t\t\t\t"name_condition"')
open(p, 'w', encoding='utf-8').write(s)
print('ok', p)

# ── cards ──
def card(name, fn):
    p = os.path.join(root, 'Data/Cards', name + '.json')
    d = json.load(open(p, encoding='utf-8'))
    fn(d)
    open(p, 'w', encoding='utf-8').write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
    print('ok', p)
def ch(half, field, value): return {'half': half, 'field': field, 'value': value}
def seq(*s): return {'type': 'sequence', 'steps': list(s)}
def gw(n): return {'type': 'gain_weave', 'amount': n}
def cw(t, direction=False):
    e = {'type': 'compel_walk', 'tiles': t}
    if direction: e['mode'] = 'direction'
    return e
def nm(trig, dmg, dur): return {'type': 'name_condition', 'trigger': trig, 'damage': dmg, 'duration': dur}
def mass(do): return {'type': 'retarget', 'targeting': {'type': 'aoe', 'radius': 2, 'enemies_only': True}, 'do': do}
UNIT = {'type': 'unit', 'range': 6, 'los': False, 'enemies_only': True}
DIRT = {'type': 'unit_then_direction', 'range': 6, 'enemies_only': True}
TILE6 = {'type': 'tile', 'range': 6}

def ladder(d, half, rungs):
    for u in d['upgrades']:
        if u['tier'] in rungs and u['half'] in ((half, 'both') if u['tier'] == 1 else (half,)):
            desc, changes = rungs[u['tier']]
            u['changes'] = [c for c in u['changes'] if c['half'] != half] + changes
            if desc:
                u['description'] = desc

CT = 'Compel target enemy to walk up to {n} tiles toward you. Your glyphs on its path trigger.'
def compel(d):
    d['top']['effect'] = cw(2)
    d['top']['rules_text'] = CT.format(n=2)
    ladder(d, 'top', {
        1: ('It walks further. The focus sigil lasts longer.', [ch('top', 'effect', cw(3)), ch('top', 'rules_text', CT.format(n=3))]),
        2: ('Every step feeds the working.', [ch('top', 'effect', seq(cw(3), gw(1))), ch('top', 'rules_text', CT.format(n=3) + ' Gain 1 Weave.')]),
        3: ('Several at once.', [ch('top', 'targeting', TILE6), ch('top', 'effect', seq(mass(cw(3)), gw(1))),
            ch('top', 'rules_text', 'Compel every enemy within 2 of the target point to walk up to 3 tiles toward you. Your glyphs on their paths trigger. Gain 1 Weave.')]),
        4: ('And Name them as they come.', [ch('top', 'targeting', TILE6), ch('top', 'effect', seq(mass(seq(cw(3), nm('attack', 4, 1))), gw(1))),
            ch('top', 'rules_text', 'Compel every enemy within 2 of the target point to walk up to 3 tiles toward you, then Name each for 1 turn: if it attacks, it takes 4. Gain 1 Weave.')]),
    })
card('enchanter_compel', compel)

DT = 'Compel target enemy to walk {n} tiles in a direction you choose. Your glyphs on its path trigger.'
def drift(d):
    d['top']['effect'] = cw(2, True)
    d['top']['rules_text'] = DT.format(n=2)
    ladder(d, 'top', {
        1: ('It drifts further. The ward holds more.', [ch('top', 'effect', cw(3, True)), ch('top', 'rules_text', DT.format(n=3))]),
        2: ('Every step feeds the working.', [ch('top', 'effect', seq(cw(3, True), gw(1))), ch('top', 'rules_text', DT.format(n=3) + ' Gain 1 Weave.')]),
        3: ('A long walk.', [ch('top', 'targeting', DIRT), ch('top', 'effect', seq(cw(4, True), gw(1))), ch('top', 'rules_text', DT.format(n=4) + ' Gain 1 Weave.')]),
        4: ('And Name it where it stops.', [ch('top', 'targeting', DIRT), ch('top', 'effect', seq(cw(4, True), nm('move', 5, 2), gw(1))),
            ch('top', 'rules_text', DT.format(n=4) + ' Then Name it for 2 turns: if it moves, it takes 5. Gain 1 Weave.')]),
    })
card('enchanter_charm_drift', drift)

GT = 'Name an enemy for {t} turns: if it {w}, it takes {n} damage. Gain {g} Weave.'
def geas(d):
    def g(dmg, dur, cast=False):
        e = {'type': 'geas', 'damage': dmg, 'duration': dur}
        if cast: e['punish_cast'] = True
        return e
    ladder(d, 'top', {
        1: (None, [ch('top', 'effect', seq(g(8, 2), gw(1))), ch('top', 'rules_text', GT.format(t=2, w='moves', n=8, g=1))]),
        2: ('Casting breaks it too.', [ch('top', 'effect', seq(g(8, 2, True), gw(1))), ch('top', 'rules_text', GT.format(t=2, w='moves or casts', n=8, g=1))]),
        3: ('Heavier, and longer.', [ch('top', 'effect', seq(g(10, 3, True), gw(1))), ch('top', 'rules_text', GT.format(t=3, w='moves or casts', n=10, g=1))]),
        4: ('Every enemy in the circle.', [ch('top', 'targeting', TILE6), ch('top', 'effect', seq(mass(g(8, 3, True)), gw(2))),
            ch('top', 'rules_text', 'Name every enemy within 2 of the target point for 3 turns: if it moves or casts, it takes 8 damage. Gain 2 Weave.')]),
    })
card('enchanter_geas', geas)
print('slice 11 applied')
