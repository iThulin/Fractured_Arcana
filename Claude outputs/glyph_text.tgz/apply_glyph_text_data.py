#!/usr/bin/env python3
# Authored glyph tooltip text: card data + schema (2026-10-04). Run from the repo root.
#
# glyph_text says what the glyph does when it goes off (the trigger line is built by the
# game, or overridden by glyph_trigger). Tokens are filled from the live glyph:
#   {damage} {status_turns} {armor} {shield} {ally_damage} {draw_cards} {owner_mana}
#   {weave} {heal} {casts} {next_spells} {owner}
# Upgrade rungs apply cumulatively, so a rung only carries glyph_text when the WORDING
# changes (a new status, a new effect). Number-only rungs inherit through the tokens.
import json, sys

NAMED = "Named (half damage, cannot move)"

# card id -> half -> {tier: text}; tier 0 is the base half.
TEXT = {
 "enchanter_binding_chains": {"bottom": {
    0: "It takes {damage} damage and {owner} heals {heal} HP.",
    3: "It takes {damage} damage and is Weakened for {status_turns}. {owner} heals {heal} HP.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}. {{owner}} heals {{heal}} HP."}},
 "enchanter_binding_rune": {"top": {
    0: "It takes {damage} damage and is Rooted for {status_turns}.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}."}},
 "enchanter_charm_drift": {"bottom": {
    0: "It gains +{armor} armor.",
    2: "It gains +{armor} armor and {shield} shield.",
    3: "It gains +{armor} armor, {shield} shield and +{ally_damage} spell damage."}},
 "enchanter_compel": {"bottom": {
    0: "Your spells cost 1 less.",
    2: "Your spells cost 1 less and deal +2 damage.",
    3: "Your spells cost 1 less and deal +2 damage. Gain 1 Weave each turn.",
    4: "Your spells cost 2 less and deal +3 damage. Gain 1 Weave each turn."}},
 "enchanter_contingency_glyph": {"top": {
    0: "It takes {damage} damage and is Rooted for {status_turns}."}},
 "enchanter_dominion": {"bottom": {
    0: "It gains +{armor} armor and {shield} shield.",
    2: "It gains +{armor} armor, {shield} shield and +{ally_damage} spell damage.",
    3: "It gains +{armor} armor, {shield} shield and +{ally_damage} spell damage, and heals 3 HP each turn.",
    4: "It gains +{armor} armor, {shield} shield and +{ally_damage} spell damage, and heals 4 HP each turn."}},
 "enchanter_ensnaring_web": {"top": {
    0: "It is Slowed for {status_turns}.",
    1: "It takes {damage} damage and is Slowed for {status_turns}.",
    2: "It takes {damage} damage and is Rooted for {status_turns}.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}."}},
 "enchanter_fate_weaver": {
   "top": {
    0: "{owner} draws {draw_cards}.",
    1: "{owner} draws {draw_cards} and gains {owner_mana} mana.",
    2: "{owner} draws {draw_cards} and gains {owner_mana} mana and {weave} Weave.",
    4: "{owner} draws {draw_cards} and gains {owner_mana} mana and {weave} Weave. A 3-damage glyph appears nearby."},
   "bottom": {
    0: "It takes {damage} damage.",
    2: "It takes {damage} damage and is Slowed for {status_turns}.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}."}},
 "enchanter_geas": {"bottom": {
    0: "It gains +{ally_damage} spell damage.",
    2: "It gains +{ally_damage} spell damage and {shield} shield.",
    4: "It gains +{ally_damage} spell damage, {shield} shield and +{armor} armor."}},
 "enchanter_glyph_network": {"bottom": {
    0: "The next spell you cast here is cast {casts} times.",
    2: "The next spell you cast here is cast {casts} times and costs 1 less.",
    4: "Every spell you cast here is cast {casts} times and costs 1 less. Gain 1 Weave each time."}},
 "enchanter_hex_mark": {"bottom": {
    0: "It gains +{ally_damage} spell damage.",
    2: "It gains +{ally_damage} spell damage and {shield} shield.",
    4: "It gains +{ally_damage} spell damage, {shield} shield and +{armor} armor."}},
 "enchanter_mirror_ward": {"top": {
    0: "Reflects {next_spells} back at the caster.",
    3: "Reflects {next_spells} back at the caster with +50% damage.",
    4: "Reflects every such spell back at its caster with +50% damage."}},
 "enchanter_runic_cascade": {"top": {
    0: "It takes {damage} damage.",
    2: "It takes {damage} damage. The copies go off at once.",
    3: "It takes {damage} damage and is Slowed for {status_turns}. The copies go off at once.",
    4: "It takes {damage} damage and is Rooted for {status_turns}. The copies go off at once."}},
 "enchanter_runic_trap": {
   "top": {
    0: "It takes {damage} damage.",
    2: "It takes {damage} damage and is Slowed for {status_turns}.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}."},
   "bottom": {
    0: "It gains {shield} shield.",
    2: "It gains {shield} shield and +{ally_damage} spell damage.",
    4: "It gains {shield} shield, +{armor} armor and +{ally_damage} spell damage."}},
 "enchanter_snare_glyph": {"top": {
    0: "It takes {damage} damage and is Rooted for {status_turns}.",
    2: "It takes {damage} damage and is Weakened for {status_turns}.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}."}},
 "enchanter_sovereign_will": {"top": {
    0: "It gains +{armor} armor, +{shield} shield and +{ally_damage} spell damage. Adjacent enemies deal 2 less and end their turn Weakened.",
    3: "It gains +{armor} armor, +{shield} shield and +{ally_damage} spell damage. Adjacent enemies deal 2 less and end their turn Weakened. Gain 1 Weave each turn.",
    4: f"It gains +{{armor}} armor, +{{shield}} shield and +{{ally_damage}} spell damage. Adjacent enemies deal 3 less, take 3 damage and are {NAMED}. Gain 1 Weave each turn."}},
 "enchanter_warding_step": {"bottom": {
    0: "It takes {damage} damage and is Slowed for {status_turns}.",
    2: "It takes {damage} damage and is Rooted for {status_turns}.",
    4: f"It takes {{damage}} damage and is {NAMED} for {{status_turns}}."}},
}

# Glyphs whose engine trigger reads wrong in a tooltip (Mirror Ward is a Manual glyph).
TRIGGER = {
 ("enchanter_mirror_ward", "top"): "When a spell targets a unit on this tile.",
}

def with_after(d, after_key, key, value):
    out = {}
    for k, v in d.items():
        if k == key:
            continue
        out[k] = v
        if k == after_key:
            out[key] = value
    if key not in out:
        out[key] = value
    return out

for cid, halves in TEXT.items():
    path = f"Data/Cards/{cid}.json"
    d = json.load(open(path, encoding='utf-8'))
    for h, tiers in halves.items():
        half = d[h]
        half = with_after(half, "rules_text", "glyph_text", tiers[0])
        if (cid, h) in TRIGGER:
            half = with_after(half, "glyph_text", "glyph_trigger", TRIGGER[(cid, h)])
        d[h] = half
        for t, txt in tiers.items():
            if t == 0:
                continue
            rungs = [u for u in d.get("upgrades", [])
                     if u.get("tier") == t and (u.get("half") == h or (t == 1 and u.get("half") == "both"))]
            if len(rungs) != 1:
                sys.exit(f"{cid} {h}: expected one tier {t} rung, found {len(rungs)}")
            ch = [c for c in rungs[0]["changes"] if not (c.get("half") == h and c.get("field") == "glyph_text")]
            ch.append({"half": h, "field": "glyph_text", "value": txt})
            rungs[0]["changes"] = ch
    open(path, 'w', encoding='utf-8').write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
    print("patched", path)

# Schema: allow the two half-level fields.
rel = 'Schemas/card.schema.json'
s = open(rel, encoding='utf-8').read()
old = """				"rules_text": {
					"type": "string",
					"description": "Human-readable description of the effect shown on the card.",
					"minLength": 1
				},
"""
new = old + """				"glyph_text": {
					"type": "string",
					"description": "Tile tooltip text for a glyph this half prepares: what it does when it goes off. Tokens like {damage} are filled from the live glyph."
				},
				"glyph_trigger": {
					"type": "string",
					"description": "Optional override for the glyph tooltip's trigger line."
				},
"""
if s.count(old) != 1:
    sys.exit(f"{rel}: rules_text block not found exactly once")
if '"glyph_text"' not in s:
    s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)
