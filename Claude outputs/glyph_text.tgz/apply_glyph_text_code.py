#!/usr/bin/env python3
# Authored glyph tooltip text: code half (2026-10-04). Run from the repo root.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:160]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

edit('Scripts/Cards/CardRuntime.cs', [
("""    public string RulesText = "";
""",
"""    public string RulesText = "";

    /// <summary>Tile-tooltip text for a glyph this half prepares: what the glyph does when it
    /// goes off, never how it is cast. Tokens such as {damage} are filled from the live glyph,
    /// so a number-only upgrade needs no new text. Authored as `glyph_text`.</summary>
    public string GlyphText = "";

    /// <summary>Optional override for the tooltip's trigger line (`glyph_trigger`), for glyphs
    /// the engine models with a Manual or otherwise unreadable trigger.</summary>
    public string GlyphTriggerText = "";
"""),
])

edit('Scripts/Cards/Loader/JsonCardLoader.cs', [
("""            RulesText = halfNode.TryGetProperty("rules_text", out var rt) ? rt.GetString() : "",
""",
"""            RulesText = halfNode.TryGetProperty("rules_text", out var rt) ? rt.GetString() : "",
            GlyphText = halfNode.TryGetProperty("glyph_text", out var gt) ? gt.GetString() ?? "" : "",
            GlyphTriggerText = halfNode.TryGetProperty("glyph_trigger", out var gtr) ? gtr.GetString() ?? "" : "",
"""),
])

edit('Scripts/Systems/Combat/Glyphs/GlyphData.cs', [
("""    public string SourceRulesText = "";""",
"""    public string SourceRulesText = "";

    /// <summary>Authored tooltip text of the half that placed this glyph (CardHalf.GlyphText),
    /// with {tokens} the tooltip fills from this glyph's live values.</summary>
    public string GlyphText = "";

    /// <summary>Authored override for the tooltip's trigger line (CardHalf.GlyphTriggerText).</summary>
    public string GlyphTriggerText = "";"""),
])

edit('Scripts/Systems/Combat/Glyphs/GlyphManager.cs', [
("""    public GlyphData Prepare(TileData tile, Unit owner, Action<GlyphData> configure)""",
"""    /// <summary>
    /// The card half whose effects are resolving right now, set by the stack resolver
    /// (RulesManager) around each item. A glyph prepared while it is set takes that half's
    /// live name, rules text and authored glyph text, which is the tier actually cast
    /// (upgrade renames happen after load, so the load-time stamp carries the base name).
    /// It also gives bespoke glyph effects (pillars, wards, anchors) a source at all.
    /// </summary>
    public static CardHalf ResolvingHalf;

    /// <summary>Copies the resolving half's identity onto <paramref name="g"/>. No-op outside
    /// a card resolution.</summary>
    public static void StampFromCast(GlyphData g)
    {
        var h = ResolvingHalf;
        if (h == null || g == null)
            return;
        if (!string.IsNullOrEmpty(h.Name))
            g.SourceName = h.Name;
        g.SourceRulesText = h.RulesText ?? "";
        g.GlyphText = h.GlyphText ?? "";
        g.GlyphTriggerText = h.GlyphTriggerText ?? "";
        if (string.IsNullOrEmpty(g.SourceCardId))
        {
            g.SourceCardId = h.SourceCardId ?? "";
            g.SourceHalf = h.SourceHalf ?? "";
        }
    }

    public GlyphData Prepare(TileData tile, Unit owner, Action<GlyphData> configure, bool stampFromCast = true)"""),
("""        configure?.Invoke(g);
        tile.Glyph = g;
""",
"""        configure?.Invoke(g);
        // Ownerless glyphs (map events) and cascade copies are not the resolving spell's.
        if (stampFromCast && owner != null)
            StampFromCast(g);
        tile.Glyph = g;
"""),
("""                string srcName = g.SourceName, srcText = g.SourceRulesText;
                Prepare(nbr, owner, ng =>
                {
                    ng.SourceName = string.IsNullOrEmpty(srcName) ? "" : srcName + " (spread)";
                    ng.SourceRulesText = srcText;
                    ng.Trigger = trig;""",
"""                string srcName = g.SourceName, srcText = g.SourceRulesText;
                string srcGlyph = g.GlyphText, srcTrig = g.GlyphTriggerText;
                string srcId = g.SourceCardId, srcHalf = g.SourceHalf;
                // stampFromCast false: a cascade can go off during some OTHER spell's
                // resolution (a Compel walking an enemy onto it), and the copy is still
                // the cascade's, not that spell's.
                Prepare(nbr, owner, ng =>
                {
                    ng.SourceName = string.IsNullOrEmpty(srcName) ? "" : srcName + " (spread)";
                    ng.SourceRulesText = srcText;
                    ng.GlyphText = srcGlyph;
                    ng.GlyphTriggerText = srcTrig;
                    ng.SourceCardId = srcId;
                    ng.SourceHalf = srcHalf;
                    ng.Trigger = trig;"""),
("""                    ng.CascadeSpread = sp; // copies spread one fewer to terminate the chain
                });""",
"""                    ng.CascadeSpread = sp; // copies spread one fewer to terminate the chain
                }, stampFromCast: false);"""),
])

edit('Scripts/Systems/Combat/Core/RulesManager.cs', [
("""        s.ResolvingAbilityName = item.Ability?.Name;   // Almanac labels (schedule)
""",
"""        s.ResolvingAbilityName = item.Ability?.Name;   // Almanac labels (schedule)
        var prevGlyphHalf = GlyphManager.ResolvingHalf;
        GlyphManager.ResolvingHalf = item.Ability as CardHalf;   // glyph tooltip source
"""),
("""            s.ResolvingAbilityName = prevAbilityName;
        }""",
"""            s.ResolvingAbilityName = prevAbilityName;
            GlyphManager.ResolvingHalf = prevGlyphHalf;
        }"""),
])

edit('Scripts/Cards/Effects/Effect.cs', [
("""				// Reusable glyphs are re-armed by re-placing; Unit.PlaceOnTile clears on trigger.
				// Full reusable/duration handling needs the GlyphManager tick (see writeup).
			}
		};
		tile.TileView?.ShowGlyph();""",
"""				// Reusable glyphs are re-armed by re-placing; Unit.PlaceOnTile clears on trigger.
				// Full reusable/duration handling needs the GlyphManager tick (see writeup).
			}
		};
		GlyphManager.StampFromCast(tile.Glyph);
		tile.TileView?.ShowGlyph(tile.Glyph);"""),
])

# TooltipManager: authored text first, hazard glyphs, permanent lifetime.
edit('Scripts/Systems/TooltipManager.cs', [
("""        bool mine = g.OwnerTeam == PlayerTeam;
        if (g.Invisible && !mine)
            return;                              // a hidden enemy glyph stays hidden

        string owner = g.Owner?.Name ?? g.OwnerId ?? "";
        string name = string.IsNullOrEmpty(g.SourceName) ? "Glyph" : g.SourceName;

        AddSeparator();
        AddPairRow(name, GlyphAccent, mine ? "yours" : "enemy", mine ? UITheme.Success : UITheme.Danger);
        if (!string.IsNullOrEmpty(owner) && !mine)
            AddRow("Set by:", owner);

        AddColoredRow("Triggers:", "", GlyphAccent);
        AddWrapped(TriggerText(g, mine, owner), UITheme.TextPrimary);

        var payload = PayloadLines(g, owner);
        foreach (var line in payload)
            AddWrapped(line, UITheme.TextPrimary);

        string life = g.DurationTurns < 0 ? "Until triggered"
                    : g.DurationTurns == 1 ? "1 turn left"
                    : $"{g.DurationTurns} turns left";
        AddRow(g.Reusable ? "Reusable" : "Single use", life);

        // The card text is a fallback only. When the glyph's own payload says what it does,
        // the card text just repeats it plus the casting instructions. When the payload is
        // empty (an effect GlyphData does not model, such as a cost aura), show what the
        // card says the glyph does, minus the placement and cast-time sentences.
        if (payload.Count == 0)
        {
            string rest = GlyphEffectText(g.SourceRulesText);
            if (!string.IsNullOrEmpty(rest))
                AddWrapped(rest, UITheme.TextPrimary);
        }
    }""",
"""        bool mine = g.OwnerTeam == PlayerTeam;
        // Team 1 is the enemy side. Anything else (map events plant team 2) belongs to
        // nobody and goes off under everyone.
        bool hazard = g.OwnerTeam != PlayerTeam && g.OwnerTeam != EnemyTeam;
        if (g.Invisible && !mine)
            return;                              // a hidden enemy glyph stays hidden

        string owner = g.Owner?.Name ?? g.OwnerId ?? "";
        string name = string.IsNullOrEmpty(g.SourceName) ? "Glyph" : g.SourceName;

        AddSeparator();
        AddPairRow(name, GlyphAccent,
                   mine ? "yours" : hazard ? "hazard" : "enemy",
                   mine ? UITheme.Success : hazard ? UITheme.Warning : UITheme.Danger);
        if (!string.IsNullOrEmpty(owner) && !mine && !hazard)
            AddRow("Set by:", owner);

        AddColoredRow("Triggers:", "", GlyphAccent);
        string trig = !string.IsNullOrEmpty(g.GlyphTriggerText) ? g.GlyphTriggerText
                    : hazard ? HazardTriggerText(g)
                    : TriggerText(g, mine, owner);
        AddWrapped(trig, UITheme.TextPrimary);

        // Authored glyph text (CardHalf.GlyphText) is the primary read. Without it, fall
        // back to lines built from the glyph's fields, then to the filtered card text.
        if (!string.IsNullOrEmpty(g.GlyphText))
        {
            AddWrapped(FillGlyphTokens(g.GlyphText, g, owner), UITheme.TextPrimary);
            foreach (var line in DynamicLines(g))
                AddWrapped(line, UITheme.TextPrimary);
        }
        else
        {
            var payload = PayloadLines(g, owner);
            foreach (var line in payload)
                AddWrapped(line, UITheme.TextPrimary);
            if (payload.Count == 0)
            {
                string rest = GlyphEffectText(g.SourceRulesText);
                if (!string.IsNullOrEmpty(rest))
                    AddWrapped(rest, UITheme.TextPrimary);
            }
        }

        string life = g.DurationTurns < 0 ? "Until triggered"
                    : g.DurationTurns >= PermanentTurns ? "Permanent"
                    : g.DurationTurns == 1 ? "1 turn left"
                    : $"{g.DurationTurns} turns left";
        AddRow(g.Reusable ? "Reusable" : "Single use", life);
    }

    private const int EnemyTeam = 1;

    /// <summary>Card data writes "duration": 99 for a glyph that lasts the fight.</summary>
    private const int PermanentTurns = 90;

    private static string HazardTriggerText(GlyphData g) => g.Trigger switch
    {
        GlyphTrigger.StartOfTurn => "When any unit starts its turn on this tile.",
        _ => "When any unit steps onto this tile.",
    };

    /// <summary>State a glyph picks up after it is cast (Glyph Network links, cascade
    /// copies), which no authored text can know about.</summary>
    private static List<string> DynamicLines(GlyphData g)
    {
        var lines = new List<string>();
        if (g.CascadeSpread > 0)
            lines.Add($"Then copies itself onto {g.CascadeSpread} adjacent tile{(g.CascadeSpread == 1 ? "" : "s")}.");
        if (g.LinkId != 0)
            lines.Add(g.CumulativeBonus > 0
                ? $"Linked: fires with its network, +{g.CumulativeBonus} damage per glyph that fires."
                : "Linked: fires with its network.");
        return lines;
    }

    /// <summary>
    /// Fills the authored glyph text from the live glyph, so the tooltip number is the one
    /// that will land (spell damage bonuses, Grand Design) and a number-only upgrade needs
    /// no new text. Unknown tokens are left as written, so a typo shows up in play.
    /// </summary>
    private static string FillGlyphTokens(string text, GlyphData g, string owner)
    {
        static string Plural(int n, string one, string many) => n == 1 ? $"{n} {one}" : $"{n} {many}";
        int sd = g.StatusDuration;
        return text
            .Replace("{damage}", g.EffectiveDamage(g.GameState).ToString())
            .Replace("{status_turns}", Plural(sd, "turn", "turns"))
            .Replace("{armor}", g.AllyArmor.ToString())
            .Replace("{shield}", g.AllyShield.ToString())
            .Replace("{ally_damage}", g.AllyDamage.ToString())
            .Replace("{ally_mana}", g.AllyMana.ToString())
            .Replace("{draw_cards}", Plural(g.OwnerDraw, "card", "cards"))
            .Replace("{owner_mana}", g.OwnerMana.ToString())
            .Replace("{weave}", g.OwnerWeave.ToString())
            .Replace("{heal}", g.OwnerHeal.ToString())
            .Replace("{radius}", g.Radius.ToString())
            .Replace("{casts}", sd.ToString())
            .Replace("{next_spells}", sd == 1 ? "the next spell" : $"the next {sd} spells")
            .Replace("{owner}", string.IsNullOrEmpty(owner) ? "its caster" : owner);
    }"""),
])

edit('Scripts/Cards/Effects/Effect.cs', [
("""			};

			tile.TileView?.ShowGlyph();
			s.Log($"[Glyph] Placed glyph at {tile.Axial}.");""",
"""			};

			GlyphManager.StampFromCast(tile.Glyph);
			tile.TileView?.ShowGlyph(tile.Glyph);
			s.Log($"[Glyph] Placed glyph at {tile.Axial}.");"""),
])
