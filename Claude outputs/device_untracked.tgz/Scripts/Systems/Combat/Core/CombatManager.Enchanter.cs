using Godot;
using System.Collections.Generic;
using System.Linq;

// ============================================================
// CombatManager.Enchanter.cs  (partial of CombatManager)
//
// Purpose:        Wiring for the Enchanter engine (EnchanterEngine.cs,
//                 class_identity_enchanter_v1 §2, slice 11):
//                 • Name breaks: a walked step (the unit's own move, or
//                   a Compel) breaks "if it moves"; ResolveStrike breaks
//                   "if it attacks"; channel, release and imbue intents
//                   break "if it casts".
//                 • A break gives the Namer +1 Weave (§2c).
//                 • Names tick down at each player turn start.
//                 • Compel previews: the walk path while dragging a
//                   toward-you Compel over an enemy, and every direction's
//                   path when a directional Compel picks its aim.
// Layer:          Combat
// Collaborators:  Names / NameCondition / CompelWalk (EnchanterEngine.cs),
//                 Unit.OnUnitEnteredTile, WeaveAttunement, CastPreview
// See:            docs/class_identity_enchanter_v1.md §2
// ============================================================

public partial class CombatManager
{
    private bool _enchanterHooksInstalled;

    private void InstallEnchanterHooks()
    {
        if (_enchanterHooksInstalled)
            return;
        Unit.OnUnitEnteredTile += OnEnchanterUnitEntered;
        Names.NameBroken += OnNameBroken;
        _enchanterHooksInstalled = true;
    }

    private void UninstallEnchanterHooks()
    {
        if (!_enchanterHooksInstalled)
            return;
        Unit.OnUnitEnteredTile -= OnEnchanterUnitEntered;
        Names.NameBroken -= OnNameBroken;
        _enchanterHooksInstalled = false;
    }

    private void LogName(string msg) => combatUI?.AppendActionLog(msg);

    private void OnEnchanterUnitEntered(Unit unit, TileData tile, MovementKind kind)
    {
        if (kind == MovementKind.Walked && unit != null && unit.Names.Count > 0)
            Names.Break(unit, NameTrigger.Move, LogName);
    }

    private void OnNameBroken(Unit unit, NameCondition name)
    {
        var owner = name.OwnerUnit;
        if (owner != null && IsInstanceValid(owner) && owner.Attunement is WeaveAttunement weave)
        {
            weave.Add(1);
            GD.Print($"[Weave] {owner.Name}: a Name was broken, +1 Weave ({weave.Weave}/{WeaveAttunement.MaxWeave}).");
        }
        RefreshSelectedUnitUI();
    }

    /// <summary>Start of a player turn: the break round advances and every Name ticks.</summary>
    private void TickNames()
    {
        Names.Round = roundNumber;
        if (State?.UnitsInPlay != null)
            Names.Tick(State.UnitsInPlay);
    }

    // ── Compel previews ─────────────────────────────────────────────────

    private static CompelWalkEffect FindCompel(IEnumerable<IEffect> effects)
    {
        if (effects == null)
            return null;
        foreach (var e in effects)
        {
            if (e is CompelWalkEffect c)
                return c;
            if (e is EffectBase eb)
            {
                var nested = FindCompel(eb.Children);
                if (nested != null)
                    return nested;
            }
        }
        return null;
    }

    /// <summary>Drag-hover over an enemy with a toward-you Compel: outline the walk.</summary>
    private void ShowCompelPathPreview(CardHalf half, Vector2I aim)
    {
        var compel = FindCompel(half?.Effects);
        if (compel == null || compel.Direction || selectedUnit?.CurrentTile == null || _aimZone == null)
            return;
        var victim = grid.GetTile(aim)?.Occupant;
        if (victim == null || !victim.Stats.IsAlive || victim.TeamId == selectedUnit.TeamId)
            return;
        var path = CompelWalk.Plan(grid, victim, compel.Tiles, selectedUnit.CurrentTile.Axial, null);
        if (path.Count > 0)
            _aimZone.ShowOutline(new HashSet<Vector2I>(path), grid, AimGroundColor, 0.22f);
        combatUI?.SetHintText(path.Count == 0
            ? $"{victim.DisplayName} has nowhere to walk toward you."
            : $"Compel: {victim.DisplayName} walks {path.Count} tile(s). Glyphs and element tiles on the way trigger.");
    }

    /// <summary>Directional Compel waiting for its aim: outline where each of the six
    /// directions would walk it, and say so in the prompt.</summary>
    private bool ShowCompelDirectionPaths(CardHalf half, Unit victim)
    {
        var compel = FindCompel(half?.Effects);
        if (compel == null || !compel.Direction || victim?.CurrentTile == null)
            return false;
        EnsureCastRenderers();
        var all = new HashSet<Vector2I>();
        foreach (var dir in HexDirection.All)
            foreach (var c in CompelWalk.Plan(grid, victim, compel.Tiles, null, dir))
                all.Add(c);
        if (all.Count > 0)
            _aimZone.ShowOutline(all, grid, AimGroundColor, 0.16f);
        return true;
    }
}
