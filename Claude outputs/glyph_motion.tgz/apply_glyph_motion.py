#!/usr/bin/env python3
# Glyph motion (2026-10-04): layers turn independently, the circle breathes, energy runs
# the rings, a pulse rolls out through the cipher, runes flicker, and a faint column of
# light with rising motes stands over each glyph. Copy glyph_aura.gdshader into
# Assets/Shaders/ first (cp -n). Repo root.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

S = 'Assets/Shaders/glyph_sigil.gdshader'
edit(S, [
("""/** Hexagram and satellites, radians per second. */
uniform float ornament_spin : hint_range(-1.0, 1.0) = 0.06;
/** Rune band, radians per second. Opposite sign to the hexagram reads as machinery. */
uniform float rune_spin : hint_range(-1.0, 1.0) = -0.035;
/** The cipher itself. Zero by default: spoke bearings are gameplay information. */
uniform float cipher_spin : hint_range(-1.0, 1.0) = 0.0;""",
"""/** Hexagram or rosette, and the satellites, radians per second. */
uniform float ornament_spin : hint_range(-1.0, 1.0) = 0.14;
/** Rune band, radians per second. Opposite sign to the hexagram reads as machinery. */
uniform float rune_spin : hint_range(-1.0, 1.0) = -0.10;
/** The cipher's slow turn, radians per second. The tooltip carries its meaning, so it may move. */
uniform float cipher_spin : hint_range(-1.0, 1.0) = 0.035;
/** The cipher's gentle rocking on top of its turn, radians. */
uniform float cipher_sway : hint_range(0.0, 0.5) = 0.07;
/** Outer ring or star, and its ticks, radians per second. */
uniform float ring_spin : hint_range(-1.0, 1.0) = 0.05;
/** Band ring or star, radians per second. */
uniform float band_spin : hint_range(-1.0, 1.0) = -0.08;
/** How far the rings swell and settle as the circle breathes (UV units). */
uniform float breath_amount : hint_range(0.0, 0.02) = 0.005;

group_uniforms energy;
/** The colour that runs through the circle: comets on the rings, the cipher pulse,
    rune flickers. Set per glyph from its palette. */
uniform vec4 pop_color : source_color = vec4(0.78, 0.60, 1.00, 1.0);
uniform float pop_strength : hint_range(0.0, 3.0) = 1.0;
/** Laps per second of the ring comets. */
uniform float current_speed : hint_range(0.0, 1.0) = 0.12;
/** Seconds between pulses rolling out through the cipher. */
uniform float wave_period : hint_range(0.5, 10.0) = 3.4;
/** How far the stave's colour drifts toward pop_color and back. */
uniform float hue_drift : hint_range(0.0, 1.0) = 0.18;"""),
("""    float ang = bearing(p);
    float pulse = 1.0 + pulse_amount * sin(TIME * pulse_speed * TAU + phase);""",
"""    float ang = bearing(p);
    float pulse = 1.0 + pulse_amount * sin(TIME * pulse_speed * TAU + phase);

    // Motion: each layer turns on its own clock, and the rings breathe out of step.
    float tt = TIME;
    vec2 po = rot(p, tt * ring_spin);
    vec2 pb = rot(p, tt * band_spin);
    float breath = sin(tt * 0.8 + phase);
    float breath2 = sin(tt * 0.63 + phase * 1.7 + 1.3);
    vec3 pop = pop_color.rgb * pop_strength;"""),
("""    float d_out = mix(abs(r - R_OUTER), sd_star(p, 0.499, 0.452, 12.0), h);
    float d_band = mix(abs(r - R_BAND), sd_star(p, 0.447, 0.412, 6.0), h);""",
"""    float d_out = mix(abs(r - (R_OUTER + breath_amount * breath)), sd_star(po, 0.499, 0.452, 12.0), h);
    float d_band = mix(abs(r - (R_BAND - breath_amount * breath2)), sd_star(pb, 0.447, 0.412, 6.0), h);"""),
("""    float tick_i = floor(ang / (TAU / 72.0) + 0.5);
    float tick_a = tick_i * (TAU / 72.0);
    float tick_d = abs(sin(ang - tick_a)) * r;""",
"""    float tang = bearing(po);
    float tick_i = floor(tang / (TAU / 72.0) + 0.5);
    float tick_a = tick_i * (TAU / 72.0);
    float tick_d = abs(sin(tang - tick_a)) * r;"""),
("""    light += ring_glow * glow_strength * pulse * p_rings;
""",
"""    light += ring_glow * glow_strength * pulse * p_rings;

    // Energy currents: a comet laps the outer ring one way and the band the other.
    float headA = fract(tt * current_speed + phase * 0.159) * TAU;
    float headB = TAU - fract(tt * current_speed * 0.8 + phase * 0.37) * TAU;
    float dA = abs(mod(ang - headA + TAU * 0.5, TAU) - TAU * 0.5);
    float dB = abs(mod(ang - headB + TAU * 0.5, TAU) - TAU * 0.5);
    float cometA = exp(-dA * 2.5);
    float cometB = exp(-dB * 2.5);
    light += pop * (ring_out * cometA + ring_band * cometB) * 1.6 * rsw;
    light += pop * (exp(-d_out / 0.02) * exp(-dA * 6.0) + exp(-d_band / 0.02) * exp(-dB * 6.0)) * 0.45 * p_rings;
"""),
("""        float runes = line_aa(rd * RUNE_H, 0.0016, pix);""",
"""        float runes = line_aa(rd * RUNE_H, 0.0016, pix);
        // Now and then a rune lights up in the energy colour.
        float flick = pow(max(0.0, sin(tt * 1.3 + hash11(cell * 1.7) * TAU)), 14.0);
        light += pop * runes * band * flick * 1.2 * detail * sweep(ang, p_runes);"""),
("""        vec2 cp = rot(p, TIME * cipher_spin);""",
"""        vec2 cp = rot(p, tt * cipher_spin + cipher_sway * sin(tt * 0.45 + phase));"""),
("""            vec3 lit = light_color.rgb * m.r * 1.05
                     + accent_color.rgb * m.g * 1.35
                     + accent_color.rgb * m.b * 0.30;""",
"""            // The stave's colour drifts toward the energy colour and back.
            vec3 stave = mix(light_color.rgb, pop_color.rgb, hue_drift * (0.5 + 0.5 * sin(tt * 0.35 + phase)));
            vec3 lit = stave * m.r * 1.05
                     + accent_color.rgb * m.g * 1.35
                     + accent_color.rgb * m.b * 0.30;

            // Once bound, a pulse rolls out from the hub through the strokes.
            float wr = fract(tt / wave_period + phase * 0.13) * 0.62;
            float wave = exp(-abs(sr - wr) / 0.028) * (1.0 - smoothstep(0.35, 0.62, wr));
            light += pop * (m.r * 0.9 + m.g * 1.2 + g.r * 0.5 + g.g * 0.5) * wave * 1.3
                     * reveal * step(0.999, p_cipher);"""),
])

H = 'Scripts/Systems/Combat/Terrain/HexTile.cs'
edit(H, [
("""    private MeshInstance3D _glyphDecal;
    private ShaderMaterial _glyphDecalMaterial;""",
"""    private MeshInstance3D _glyphDecal;
    private ShaderMaterial _glyphDecalMaterial;
    private MeshInstance3D _glyphAura;
    private ShaderMaterial _glyphAuraMaterial;"""),
("""        _glyphDecalMaterial.SetShaderParameter("core_color", hostile ? GlyphHostileCore : GlyphFriendlyCore);
""",
"""        _glyphDecalMaterial.SetShaderParameter("core_color", hostile ? GlyphHostileCore : GlyphFriendlyCore);
        _glyphDecalMaterial.SetShaderParameter("pop_color", hostile ? GlyphHostilePop : GlyphFriendlyPop);
        if (_glyphAuraMaterial != null)
        {
            _glyphAuraMaterial.SetShaderParameter("aura_color", hostile ? GlyphHostileLight : GlyphFriendlyLight);
            _glyphAuraMaterial.SetShaderParameter("mote_color", hostile ? GlyphHostileCore : GlyphFriendlyCore);
        }
"""),
("""        var decal = _glyphDecal;
        var mat = _glyphDecalMaterial;
        var label = _glyphLabel;""",
"""        var decal = _glyphDecal;
        var mat = _glyphDecalMaterial;
        var label = _glyphLabel;
        var aura = _glyphAura;
        var auraMat = _glyphAuraMaterial;"""),
("""                tw.TweenProperty(mat, "shader_parameter/flash", 0.0f, GlyphFlashSeconds)
                  .From(1.0f)
                  .SetTrans(Tween.TransitionType.Expo)
                  .SetEase(Tween.EaseType.Out);
            });""",
"""                tw.TweenProperty(mat, "shader_parameter/flash", 0.0f, GlyphFlashSeconds)
                  .From(1.0f)
                  .SetTrans(Tween.TransitionType.Expo)
                  .SetEase(Tween.EaseType.Out);

                // The bound spell leaks: a faint column rises once the circle seals.
                if (IsInstanceValid(aura) && auraMat != null)
                {
                    auraMat.SetShaderParameter("progress", 0f);
                    aura.Visible = true;
                    CreateTween()
                        .TweenProperty(auraMat, "shader_parameter/progress", 1.0f, 1.2f)
                        .SetDelay(GlyphInscribeSeconds * 0.85f)
                        .SetTrans(Tween.TransitionType.Sine)
                        .SetEase(Tween.EaseType.Out);
                }
            });"""),
("""    private void ShowFallbackMarker()
    {
        if (_glyphDecal != null)
            _glyphDecal.Visible = false;""",
"""    private void ShowFallbackMarker()
    {
        if (_glyphDecal != null)
            _glyphDecal.Visible = false;
        if (_glyphAura != null)
            _glyphAura.Visible = false;"""),
("""            MaterialOverride = _glyphDecalMaterial,
            Visible = false,
        };
        CallDeferred("add_child", _glyphDecal);""",
"""            MaterialOverride = _glyphDecalMaterial,
            Visible = false,
        };
        CallDeferred("add_child", _glyphDecal);

        // The light column over the glyph. Built once beside the decal and only ever
        // shown and hidden (the node lifetime rule).
        var auraShader = GD.Load<Shader>(GlyphAuraShaderPath);
        if (auraShader != null)
        {
            _glyphAuraMaterial = new ShaderMaterial { Shader = auraShader };
            _glyphAuraMaterial.SetShaderParameter("aura_height", GlyphAuraHeight);
            _glyphAuraMaterial.SetShaderParameter("phase", Mathf.Abs(h % 1000) / 1000f * Mathf.Tau);
            float radius = GlyphDecalSize * 0.5f * 0.88f;
            _glyphAura = new MeshInstance3D
            {
                Name = "GlyphAura",
                Mesh = new CylinderMesh
                {
                    TopRadius = radius * 1.04f,
                    BottomRadius = radius,
                    Height = GlyphAuraHeight,
                    RadialSegments = 32,
                    Rings = 1,
                    CapTop = false,
                    CapBottom = false,
                },
                Position = new Vector3(0f, MeasuredTileTopY() + GlyphDecalHeight + GlyphAuraHeight * 0.5f, 0f),
                CastShadow = GeometryInstance3D.ShadowCastingSetting.Off,
                MaterialOverride = _glyphAuraMaterial,
                Visible = false,
            };
            CallDeferred("add_child", _glyphAura);
        }"""),
("""        if (_glyphDecal != null)
            _glyphDecal.Visible = false;
    }

    /// <summary>Current elemental imbuement""",
"""        if (_glyphDecal != null)
            _glyphDecal.Visible = false;
        if (_glyphAura != null)
            _glyphAura.Visible = false;
    }

    /// <summary>Current elemental imbuement"""),
("""    private static readonly Color GlyphHostileCore    = new Color(1.00f, 0.88f, 0.96f, 1f);""",
"""    private static readonly Color GlyphHostileCore    = new Color(1.00f, 0.88f, 0.96f, 1f);
    // The energy colour that runs through each family: lavender through the blue,
    // amber through the pink, so the pops stand out from the base light.
    private static readonly Color GlyphFriendlyPop    = new Color(0.80f, 0.62f, 1.00f, 1f);
    private static readonly Color GlyphHostilePop     = new Color(1.00f, 0.76f, 0.38f, 1f);

    private const string GlyphAuraShaderPath = "res://Assets/Shaders/glyph_aura.gdshader";
    /// <summary>Height of the light column over a glyph, in world units.</summary>
    private const float GlyphAuraHeight = 1.1f;"""),
])
