#!/usr/bin/env python3
# Slice 8 cards: Chronomancer §4 rewording (Afterimage, Borrowed Time, Decoy of Hours,
# Grand Design bottom, Misdirection top, Split Second top, Temporal Anchor bottom,
# Time Walk bottom (+ top T3/T4 text), Undertow).
import json, sys
C = 'Data/Cards/'
def load(n):
    with open(C + n + '.json', encoding='utf-8') as f: return json.load(f)
def save(n, d):
    with open(C + n + '.json', 'w', encoding='utf-8') as f:
        f.write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
def rung(d, tier, half):
    for u in d['upgrades']:
        if u['tier'] == tier and u['half'] == half: return u
    sys.exit(f"missing rung {d['id']} T{tier} {half}")
def drop(u, half):
    u['changes'] = [c for c in u['changes'] if c['half'] != half]
def ch(half, field, value): return {'half': half, 'field': field, 'value': value}
def seq(*steps): return {'type': 'sequence', 'steps': list(steps)}
def gf(n): return {'type': 'gain_foresight', 'amount': n}
def draw(n=1): return {'type': 'draw', 'count': n}
def dmg(n): return {'type': 'damage', 'amount': n}
def defer(**kw):
    e = {'type': 'defer_intent'}; e.update(kw); return e
def cond(pred, then, els): return {'type': 'conditional', 'if': pred, 'then': then, 'else': els}
def fs(n): return {'type': 'foresight_at_least', 'value': n}
def status(s, d): return {'type': 'apply_status', 'status': s, 'duration': d}

def set_half(d, half, effect=None, text=None, **fields):
    if effect is not None: d[half]['effect'] = effect
    if text is not None: d[half]['rules_text'] = text
    for k, v in fields.items(): d[half][k] = v

def ladder(d, half, rungs):
    """rungs: {tier: (description_or_None, [changes...], name_or_None)}"""
    for tier, (desc, changes, name) in rungs.items():
        if tier == 1:
            u = next((x for x in d['upgrades'] if x['tier'] == 1 and x['half'] in ('both', half)), None)
            if u is None: sys.exit(f"missing rung {d['id']} T1")
        else:
            u = rung(d, tier, half)
        if tier == 1:
            drop(u, half)
            u['changes'] += changes
        else:
            u['changes'] = changes
            if desc: u['description'] = desc
            if name: u['top_name' if half == 'top' else 'bottom_name'] = name

# ── Afterimage ────────────────────────────────────────────────────────
d = load('chronomancer_afterimage')
def sl(turns): return {'type': 'schedule_last', 'turns': turns, 'value_mult': 1.0}
set_half(d, 'top', sl(1), 'Schedule a copy of your last spell. It resolves again, on the same targets, at the start of your next turn.')
ladder(d, 'top', {
  1: (None, [ch('top', 'mana', 1)], None),
  2: ('The copy comes with insight.', [ch('top', 'mana', 1), ch('top', 'effect', seq(sl(1), gf(1))),
      ch('top', 'rules_text', 'Schedule a copy of your last spell for the start of your next turn. Gain 1 Foresight.')], None),
  3: ('Two echoes, a turn apart.', [ch('top', 'mana', 1), ch('top', 'effect', seq(sl(1), sl(2))),
      ch('top', 'rules_text', 'Schedule two copies of your last spell: one at the start of your next turn, one the turn after.')], None),
  4: ('Two echoes and the insight to use them.', [ch('top', 'mana', 1), ch('top', 'effect', seq(sl(1), sl(2), gf(1))),
      ch('top', 'rules_text', 'Schedule two copies of your last spell: one at the start of your next turn, one the turn after. Gain 1 Foresight.')], None),
})
def per(m): return {'type': 'gain_foresight_per_scheduled', 'max': m}
set_half(d, 'bottom', per(3), 'Gain 1 Foresight for each spell you have scheduled (max 3).', mana=1)
ladder(d, 'bottom', {
  1: (None, [ch('bottom', 'mana', 1), ch('bottom', 'effect', seq(per(3), {'type': 'shield', 'amount': 2})),
      ch('bottom', 'rules_text', 'Gain 1 Foresight for each spell you have scheduled (max 3). Gain 2 shield.')], None),
  2: ('Counts further.', [ch('bottom', 'mana', 1), ch('bottom', 'effect', seq(per(4), {'type': 'shield', 'amount': 2})),
      ch('bottom', 'rules_text', 'Gain 1 Foresight for each spell you have scheduled (max 4). Gain 2 shield.')], None),
  3: ('And a card for the wait.', [ch('bottom', 'mana', 1), ch('bottom', 'effect', seq(per(4), draw(1))),
      ch('bottom', 'rules_text', 'Gain 1 Foresight for each spell you have scheduled (max 4). Draw 1 card.')], None),
  4: ('Free.', [ch('bottom', 'mana', 0), ch('bottom', 'effect', seq(per(4), draw(1))),
      ch('bottom', 'rules_text', 'Gain 1 Foresight for each spell you have scheduled (max 4). Draw 1 card.')], None),
})
save('chronomancer_afterimage', d)

# ── Borrowed Time ─────────────────────────────────────────────────────
d = load('chronomancer_borrowed_time')
def move(n): return {'type': 'move', 'tiles': n}
def bt(tiles, draws):
    return {'type': 'choose_one', 'options': [
        {'label': 'Borrow', 'description': f'Move {tiles} tiles, lose 1 Foresight (you may go Overdrawn), draw {draws}.',
         'effect': seq(move(tiles), {'type': 'lose_foresight', 'amount': 1}, draw(draws))},
        {'label': 'Just move', 'description': f'Move {tiles} tiles.', 'effect': move(tiles)},
    ]}
def bt_text(tiles, draws):
    return f'Move {tiles} tiles. You may lose 1 Foresight (you may go Overdrawn) to draw {draws} card{"s" if draws > 1 else ""}.'
set_half(d, 'top', bt(3, 1), bt_text(3, 1))
ladder(d, 'top', {
  1: (None, [ch('top', 'effect', bt(4, 1)), ch('top', 'rules_text', bt_text(4, 1))], None),
  2: ('Borrow deeper.', [ch('top', 'effect', bt(4, 2)), ch('top', 'rules_text', bt_text(4, 2))], None),
  3: ('Further, and deeper.', [ch('top', 'effect', bt(5, 2)), ch('top', 'rules_text', bt_text(5, 2))], None),
  4: ('Free.', [ch('top', 'mana', 0), ch('top', 'effect', bt(5, 2)), ch('top', 'rules_text', bt_text(5, 2))], None),
})
# bottom keeps its base; the ladder loses postpone and redirect (doc §1, §2a)
ladder(d, 'bottom', {
  2: ('Slowed, and its blow waits.', [ch('bottom', 'effect', seq(status('slowed', 2), defer(), gf(1))),
      ch('bottom', 'rules_text', "Target enemy is Slowed for 2 turns and its attack is Deferred. Gain 1 Foresight.")], None),
  3: ('More time banked.', [ch('bottom', 'effect', seq(status('slowed', 2), defer(), gf(2))),
      ch('bottom', 'rules_text', "Target enemy is Slowed for 2 turns and its attack is Deferred. Gain 2 Foresight.")], None),
  4: ('And a card besides.', [ch('bottom', 'effect', seq(status('slowed', 2), defer(), gf(2), draw(1))),
      ch('bottom', 'rules_text', "Target enemy is Slowed for 2 turns and its attack is Deferred. Gain 2 Foresight. Draw 1 card.")], None),
})
# T1 bottom keeps its own changes (Slowed 2 turns)
save('chronomancer_borrowed_time', d)

# ── Decoy of Hours ────────────────────────────────────────────────────
d = load('chronomancer_decoy_of_hours')
def decoy(hp, radius, turns, extra=()):
    return seq({'type': 'summon_decoy', 'hp': hp, 'turns': turns},
               {'type': 'redirect_aura', 'radius': radius, 'turns': turns}, *extra)
def decoy_text(hp, radius, turns, tail=''):
    return (f'Summon an echo of yourself (HP {hp}) on a tile within 3 for {turns} turns. '
            f'Enemies within {radius} of it aim their attacks at it when they next plan.{tail}')
set_half(d, 'top', decoy(10, 2, 3), decoy_text(10, 2, 3))
ladder(d, 'top', {
  1: (None, [ch('top', 'effect', decoy(14, 2, 3)), ch('top', 'rules_text', decoy_text(14, 2, 3))], None),
  2: ('A wider pull.', [ch('top', 'effect', decoy(14, 3, 3)), ch('top', 'rules_text', decoy_text(14, 3, 3))], None),
  3: ('Sturdier, and it lingers.', [ch('top', 'effect', decoy(18, 3, 4)), ch('top', 'rules_text', decoy_text(18, 3, 4))], None),
  4: ('The echo pays you back.', [ch('top', 'effect', decoy(20, 3, 4, (gf(2),))),
      ch('top', 'rules_text', decoy_text(20, 3, 4, ' Gain 2 Foresight.'))], None),
})
def nd(r): return defer(near_decoy=True, radius=r)
set_half(d, 'bottom', nd(1), 'Defer the attack of every enemy adjacent to your echo.', targeting={'type': 'self'})
ladder(d, 'bottom', {
  1: (None, [ch('bottom', 'effect', nd(2)), ch('bottom', 'rules_text', 'Defer the attack of every enemy within 2 of your echo.')], None),
  2: ('And bank the moment.', [ch('bottom', 'effect', seq(nd(2), gf(1))),
      ch('bottom', 'rules_text', 'Defer the attack of every enemy within 2 of your echo. Gain 1 Foresight.')], None),
  3: ('A wider stall.', [ch('bottom', 'effect', seq(nd(3), gf(1))),
      ch('bottom', 'rules_text', 'Defer the attack of every enemy within 3 of your echo. Gain 1 Foresight.')], None),
  4: ('Time stands around it.', [ch('bottom', 'effect', seq(nd(3), gf(2), draw(1))),
      ch('bottom', 'rules_text', 'Defer the attack of every enemy within 3 of your echo. Gain 2 Foresight. Draw 1 card.')], None),
})
save('chronomancer_decoy_of_hours', d)

# ── Grand Design (bottom) ─────────────────────────────────────────────
d = load('chronomancer_grand_design')
all_def = defer(radius=99)
GD_TEXT = 'Defer every enemy attack: they all move first, then every attack lands on its locked tile at the end of the round.'
set_half(d, 'bottom', all_def, GD_TEXT, targeting={'type': 'self'})
ladder(d, 'bottom', {
  1: (None, [ch('bottom', 'effect', seq(all_def, gf(1))), ch('bottom', 'rules_text', GD_TEXT + ' Gain 1 Foresight.')], None),
  2: ('Cheaper.', [ch('bottom', 'mana', 3), ch('bottom', 'effect', seq(all_def, gf(1))),
      ch('bottom', 'rules_text', GD_TEXT + ' Gain 1 Foresight.')], None),
  3: ('More banked.', [ch('bottom', 'mana', 3), ch('bottom', 'effect', seq(all_def, gf(2))),
      ch('bottom', 'rules_text', GD_TEXT + ' Gain 2 Foresight.')], None),
  4: ('And a card.', [ch('bottom', 'mana', 3), ch('bottom', 'effect', seq(all_def, gf(2), draw(1))),
      ch('bottom', 'rules_text', GD_TEXT + ' Gain 2 Foresight. Draw 1 card.')], None),
})
save('chronomancer_grand_design', d)

# ── Misdirection (top) ────────────────────────────────────────────────
d = load('chronomancer_misdirection')
def aim(n): return defer(aimed_within=n)
set_half(d, 'top', aim(0), 'Defer every attack aimed at your tile. Each lands there at the end of the round, so step away first.')
ladder(d, 'top', {
  1: (None, [ch('top', 'mana', 1)], None),
  2: ('And bank the dodge.', [ch('top', 'effect', seq(aim(0), gf(1))),
      ch('top', 'rules_text', 'Defer every attack aimed at your tile to the end of the round. Gain 1 Foresight.')], None),
  3: ('Covers your neighbours.', [ch('top', 'targeting', {'type': 'self'}), ch('top', 'effect', seq(aim(1), gf(1))),
      ch('top', 'rules_text', 'Defer every attack aimed at your tile or a tile next to you. Gain 1 Foresight.')], None),
  4: ('A wide margin.', [ch('top', 'targeting', {'type': 'self'}), ch('top', 'effect', seq(aim(2), gf(2))),
      ch('top', 'rules_text', 'Defer every attack aimed within 2 tiles of you. Gain 2 Foresight.')], None),
})
save('chronomancer_misdirection', d)

# ── Split Second (top) ────────────────────────────────────────────────
d = load('chronomancer_split_second')
def ss(n, rich=None):
    hit = dmg(n) if rich is None else cond(fs(2), dmg(rich), dmg(n))
    return seq(hit, cond(fs(2), draw(1), {'type': 'empty'}))
set_half(d, 'top', ss(4), 'Deal 4 damage. If you have 2+ Foresight, draw 1 card.')
ladder(d, 'top', {
  1: (None, [ch('top', 'effect', ss(5)), ch('top', 'rules_text', 'Deal 5 damage. If you have 2+ Foresight, draw 1 card.')], None),
  2: ('Sharper.', [ch('top', 'effect', ss(6)), ch('top', 'rules_text', 'Deal 6 damage. If you have 2+ Foresight, draw 1 card.')], None),
  3: ('Always a card.', [ch('top', 'effect', seq(dmg(6), draw(1))), ch('top', 'rules_text', 'Deal 6 damage. Draw 1 card.')], None),
  4: ('Foresight sharpens it.', [ch('top', 'effect', seq(cond(fs(2), dmg(9), dmg(7)), draw(1))),
      ch('top', 'rules_text', 'Deal 7 damage (9 if you have 2+ Foresight). Draw 1 card.')], None),
})
save('chronomancer_split_second', d)

# ── Temporal Anchor (bottom: Paradox Bolt) ────────────────────────────
d = load('chronomancer_temporal_anchor')
def pb(lo, hi, draw_at):
    return cond(fs(draw_at), seq(dmg(hi), draw(1)), cond(fs(2), dmg(hi), dmg(lo)))
def pb_text(lo, hi, draw_at):
    tail = 'If you have 4, also draw 1 card.' if draw_at == 4 else f'If you have {draw_at}+, also draw 1 card.'
    return f'Deal {lo} damage. If you have 2+ Foresight, deal {hi} instead. {tail}'
set_half(d, 'bottom', pb(4, 8, 4), pb_text(4, 8, 4))
ladder(d, 'bottom', {
  1: (None, [ch('bottom', 'effect', pb(5, 9, 4)), ch('bottom', 'rules_text', pb_text(5, 9, 4))], None),
  2: ('The card comes sooner.', [ch('bottom', 'effect', pb(5, 9, 3)), ch('bottom', 'rules_text', pb_text(5, 9, 3))], None),
  3: ('Heavier.', [ch('bottom', 'effect', pb(6, 10, 3)), ch('bottom', 'rules_text', pb_text(6, 10, 3))], None),
  4: ('A paradox with weight.', [ch('bottom', 'effect', pb(7, 12, 3)), ch('bottom', 'rules_text', pb_text(7, 12, 3))], None),
})
save('chronomancer_temporal_anchor', d)

# ── Time Walk ─────────────────────────────────────────────────────────
d = load('chronomancer_time_walk')
def tw(st, extra=()): return seq(status(st, 1), defer(), *extra)
def tw_text(r, st, tail=''):
    word = {'slowed': 'Slowed', 'rooted': 'Rooted'}[st]
    return f'Every enemy within {r} of the target point is {word} for 1 turn, and its attack is Deferred to the end of the round.{tail}'
set_half(d, 'bottom', tw('slowed'), tw_text(2, 'slowed'),
         targeting={'type': 'aoe', 'radius': 2, 'enemies_only': True})
ladder(d, 'bottom', {
  1: (None, [ch('bottom', 'targeting', {'type': 'aoe', 'radius': 3, 'enemies_only': True}),
      ch('bottom', 'rules_text', tw_text(3, 'slowed'))], None),
  2: ('Bank the stillness.', [ch('bottom', 'targeting', {'type': 'aoe', 'radius': 3, 'enemies_only': True}),
      ch('bottom', 'effect', tw('slowed', (gf(1),))), ch('bottom', 'rules_text', tw_text(3, 'slowed', ' Gain 1 Foresight.'))], None),
  3: ('Held in place.', [ch('bottom', 'targeting', {'type': 'aoe', 'radius': 3, 'enemies_only': True}),
      ch('bottom', 'effect', tw('rooted', (gf(1),))), ch('bottom', 'rules_text', tw_text(3, 'rooted', ' Gain 1 Foresight.'))], None),
  4: ('Held, and well paid.', [ch('bottom', 'targeting', {'type': 'aoe', 'radius': 3, 'enemies_only': True}),
      ch('bottom', 'effect', tw('rooted', (gf(2),))), ch('bottom', 'rules_text', tw_text(3, 'rooted', ' Gain 2 Foresight.'))], None),
})
# top T3/T4: a schedule fires once; the old text promised a strike every turn
for tier, turns, amt in ((3, 4, 5), (4, 5, 6)):
    u = rung(d, tier, 'top')
    for c in u['changes']:
        if c['field'] == 'rules_text':
            c['value'] = (f'Mark an enemy. In {turns} turns, deal {amt} damage to it wherever it stands. '
                          f'It matures while it waits (+2 per turn).')
save('chronomancer_time_walk', d)

# ── Undertow ──────────────────────────────────────────────────────────
d = load('chronomancer_undertow')
set_half(d, 'top', seq(defer(), gf(1)), "Defer target enemy's attack or spell to the end of the round. Gain 1 Foresight.")
ladder(d, 'top', {
  1: (None, [ch('top', 'effect', seq(defer(radius=1), gf(1))),
      ch('top', 'rules_text', "Defer the attack of target enemy and every enemy within 1 of it. Gain 1 Foresight.")], None),
  2: ('More banked.', [ch('top', 'effect', seq(defer(radius=1), gf(2))),
      ch('top', 'rules_text', "Defer the attack of target enemy and every enemy within 1 of it. Gain 2 Foresight.")], None),
  3: ('A wider current.', [ch('top', 'effect', seq(defer(radius=2), gf(2))),
      ch('top', 'rules_text', "Defer the attack of target enemy and every enemy within 2 of it. Gain 2 Foresight.")], None),
  4: ('And a card.', [ch('top', 'effect', seq(defer(radius=2), gf(2), draw(1))),
      ch('top', 'rules_text', "Defer the attack of target enemy and every enemy within 2 of it. Gain 2 Foresight. Draw 1 card.")], None),
})
riptide = {'type': 'choose_one', 'options': [
    {'label': 'Advance', 'description': 'Your soonest scheduled spell moves one turn closer (it resolves now if it was due next turn).',
     'effect': {'type': 'advance'}},
    {'label': 'Defer', 'description': "Defer target enemy's attack to the end of the round.", 'effect': defer()},
]}
set_half(d, 'bottom', riptide, "Choose one: advance one of your scheduled spells, or Defer target enemy's attack.",
         targeting={'type': 'unit', 'range': 8, 'los': False, 'enemies_only': True})
ladder(d, 'bottom', {
  1: (None, [ch('bottom', 'effect', seq({'type': 'advance'}, defer())),
      ch('bottom', 'rules_text', "Advance one of your scheduled spells AND Defer target enemy's attack.")], None),
  2: ('A wider wake.', [ch('bottom', 'effect', seq({'type': 'advance'}, defer(radius=1))),
      ch('bottom', 'rules_text', "Advance one of your scheduled spells. Defer the attack of target enemy and every enemy within 1 of it.")], None),
  3: ('And bank it.', [ch('bottom', 'effect', seq({'type': 'advance'}, defer(radius=1), gf(1))),
      ch('bottom', 'rules_text', "Advance one of your scheduled spells. Defer the attack of target enemy and every enemy within 1 of it. Gain 1 Foresight.")], None),
  4: ('The tide turns entirely.', [ch('bottom', 'effect', seq({'type': 'fast_forward', 'count': 99, 'foresight_cost': 0}, defer(radius=99))),
      ch('bottom', 'rules_text', "All your scheduled spells resolve now. Defer every enemy's attack.")], None),
})
save('chronomancer_undertow', d)
# ── Stale rung descriptions ───────────────────────────────────────────
for name, tier, half, desc in (
    ('chronomancer_afterimage', 1, 'both', 'Cheaper copies; Recurrence also shields.'),
    ('chronomancer_misdirection', 1, 'both', 'Cheaper defer; sturdier sidestep.'),
    ('chronomancer_undertow', 1, 'both', 'A wider current; Riptide does both.'),
    ('chronomancer_grand_design', 1, 'both', 'Bigger plans; a little Foresight.'),
    ('chronomancer_time_walk', 3, 'top', 'It follows the unit.'),
    ('chronomancer_time_walk', 4, 'top', 'Bigger, and later.'),
):
    d = load(name)
    rung(d, tier, half)['description'] = desc
    save(name, d)
print('slice 8 cards applied')
