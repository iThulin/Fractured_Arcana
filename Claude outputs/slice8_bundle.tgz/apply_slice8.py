#!/usr/bin/env python3
# Slice 8 (code): Chronomancer §4 rewording support.
import sys, os
root = sys.argv[1]
def edit(rel, pairs):
    p = os.path.join(root, rel)
    s = open(p, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        assert n == 1, f"{rel}: expected 1 match, got {n} for:\n{old}"
        s = s.replace(old, new)
    open(p, 'w', encoding='utf-8').write(s)
    print("ok", rel)

edit('Scripts/Cards/Effects/IntentTimeEffects.cs', [
('''/// JSON: { "type": "defer_intent", "radius": n }
/// </summary>
public sealed class DeferIntentEffect : EffectBase
{
    public int Radius;
    public DeferIntentEffect(int radius = 0) { Radius = Math.Max(0, radius); }

    public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
    {
        var primaries = new List<Unit>();
        if (targets?.Items != null)
            foreach (var obj in targets.Items)
                primaries.Add(ResolveTargetUnit(s, obj));

        var victims = IntentTime.Victims(s, primaries, Radius);''',
'''/// Two other ways to pick who (slice 8, §4 rewording):
/// <see cref="AimedWithin"/> (0 or more) takes every enemy whose attack is locked onto a
/// tile within that many tiles of the caster (Misdirection: "every attack aimed at you");
/// <see cref="NearDecoy"/> takes every enemy within <see cref="Radius"/> of one of the
/// caster's echoes (Decoy of Hours) instead of widening around the target.
/// JSON: { "type": "defer_intent", "radius": n, "aimed_within": n, "near_decoy": bool }
/// </summary>
public sealed class DeferIntentEffect : EffectBase
{
    public int Radius;
    /// <summary>-1 = off.</summary>
    public int AimedWithin = -1;
    public bool NearDecoy;
    public DeferIntentEffect(int radius = 0) { Radius = Math.Max(0, radius); }

    public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
    {
        var primaries = new List<Unit>();
        if (targets?.Items != null)
            foreach (var obj in targets.Items)
                primaries.Add(ResolveTargetUnit(s, obj));

        var casterUnit = s?.ActiveCasterUnit;
        int radius = Radius;
        if (AimedWithin >= 0)
        {
            primaries.Clear();
            radius = 0;
            if (casterUnit?.CurrentTile != null && s.Grid != null && s.UnitsInPlay != null)
            {
                var home = casterUnit.CurrentTile.Axial;
                foreach (var u in s.UnitsInPlay)
                {
                    if (u == null || u.TeamId == casterUnit.TeamId || !u.Stats.IsAlive || u.CurrentIntent == null)
                        continue;
                    var tiles = new List<Vector2I>(u.CurrentIntent.ThreatTiles ?? new List<Vector2I>());
                    if (u.CurrentIntent.TargetTile.HasValue)
                        tiles.Add(u.CurrentIntent.TargetTile.Value);
                    if (tiles.Any(t => s.Grid.Distance(home, t) <= AimedWithin))
                        primaries.Add(u);
                }
            }
        }
        else if (NearDecoy)
        {
            primaries.Clear();
            radius = 0;
            if (s?.UnitsInPlay != null && s.Grid != null)
            {
                int team = casterUnit?.TeamId ?? 0;
                var decoys = s.UnitsInPlay.Where(d => d != null && d.IsDecoy && d.Stats.IsAlive
                                                      && d.TeamId == team && d.CurrentTile != null).ToList();
                if (decoys.Count == 0)
                    s.Log("[Defer] You have no echo on the board.");
                foreach (var u in s.UnitsInPlay)
                {
                    if (u == null || u.TeamId == team || u.IsDecoy || !u.Stats.IsAlive || u.CurrentTile == null)
                        continue;
                    if (decoys.Any(d => s.Grid.Distance(d.CurrentTile.Axial, u.CurrentTile.Axial) <= Math.Max(1, Radius)))
                        primaries.Add(u);
                }
            }
        }

        var victims = IntentTime.Victims(s, primaries, radius);'''),
('''using System;
using System.Collections.Generic;
''',
'''using Godot;
using System;
using System.Collections.Generic;
using System.Linq;
'''),
])

edit('Scripts/Cards/Loader/CardScriptRegistry.Chronomancer.cs', [
('''        // { "type": "defer_intent", "radius": n }
        RegisterEffect("defer_intent", n =>
        {
            int radius = n.TryGetProperty("radius", out var r) ? r.GetInt32() : 0;
            return new DeferIntentEffect(radius).WithTag("Control");
        });''',
'''        // { "type": "defer_intent", "radius": n, "aimed_within": n, "near_decoy": bool }
        RegisterEffect("defer_intent", n =>
        {
            int radius = n.TryGetProperty("radius", out var r) ? r.GetInt32() : 0;
            var eff = new DeferIntentEffect(radius);
            if (n.TryGetProperty("aimed_within", out var aw))
                eff.AimedWithin = aw.GetInt32();
            eff.NearDecoy = n.TryGetProperty("near_decoy", out var nd) && nd.GetBoolean();
            return eff.WithTag("Control");
        });

        // Afterimage: schedule a copy of the last resolved spell.
        // { "type": "schedule_last", "turns": n, "value_mult": f }
        RegisterEffect("schedule_last", n =>
        {
            int turns = n.TryGetProperty("turns", out var t) ? t.GetInt32() : 1;
            float mult = n.TryGetProperty("value_mult", out var m) ? (float)m.GetDouble() : 1f;
            return new ScheduleLastEffect(turns, mult).WithTag("Foresight");
        });

        // Recurrence: +1 Foresight per scheduled spell, capped.
        // { "type": "gain_foresight_per_scheduled", "max": n }
        RegisterEffect("gain_foresight_per_scheduled", n =>
        {
            int max = n.TryGetProperty("max", out var m) ? m.GetInt32() : 3;
            return new GainForesightPerScheduledEffect(max).WithTag("Foresight");
        });'''),
])

edit('Scripts/Cards/Loader/JsonCardLoader.cs', [
('''        // Spells cast this turn at least: { "type": "spells_cast_this_turn", "threshold": n }''',
'''        // Chronomancer: Time Bank holds at least N Foresight: { "type": "foresight_at_least", "value": n }
        RegisterPredicate("foresight_at_least", n =>
            new ForesightAtLeastPredicate(n.TryGetProperty("value", out var v) ? v.GetInt32() : 2));

        // Spells cast this turn at least: { "type": "spells_cast_this_turn", "threshold": n }'''),
])
print("slice 8 code applied")
