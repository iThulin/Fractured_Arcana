#!/usr/bin/env python3
# Slice 12a: Enchanter effects + registry (links, network, pillars, mirror ward, anchor, tithe).
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

E = 'Scripts/Cards/Effects/EnchanterEffects.cs'
edit(E, [
# Link: persist + Weave per glyph linked
("""/// <summary>Link up to N friendly glyphs so triggering one triggers the group. { "type":"link_glyphs","count":n,"cumulative_bonus":n }</summary>
public sealed class LinkGlyphsEffect : EffectBase
{
	public int Count, CumulativeBonus;
	public LinkGlyphsEffect(int count, int bonus) { Count = count; CumulativeBonus = bonus; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (s?.Glyphs == null || owner == null)
			return;
		int id = s.Glyphs.Link(owner.TeamId, Count, CumulativeBonus);
		s.Log($"[LinkGlyphs] linked up to {Count} glyph(s) (id {id}).");
	}
}""",
"""/// <summary>Link up to N friendly glyphs so triggering one triggers the group.
/// "persist" keeps the network open for the rest of the fight (later glyphs join it);
/// "on_trigger_weave" pays that much Weave per glyph linked.
/// { "type":"link_glyphs","count":n,"cumulative_bonus":n,"persist":bool,"on_trigger_weave":n }</summary>
public sealed class LinkGlyphsEffect : EffectBase
{
	public int Count, CumulativeBonus, WeavePerGlyph;
	public bool Persist;
	public LinkGlyphsEffect(int count, int bonus, int weavePerGlyph = 0, bool persist = false)
	{ Count = count; CumulativeBonus = bonus; WeavePerGlyph = weavePerGlyph; Persist = persist; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (s?.Glyphs == null || owner == null)
			return;
		int linked;
		if (Persist)
		{
			linked = s.Glyphs.LinkPersistent(owner.TeamId, CumulativeBonus);
			s.Log($"[LinkGlyphs] {linked} glyph(s) linked; the network stays open for the rest of the fight.");
		}
		else
		{
			linked = Math.Min(Count, s.Glyphs.CountFriendly(owner.TeamId));
			int id = s.Glyphs.Link(owner.TeamId, Count, CumulativeBonus);
			s.Log($"[LinkGlyphs] linked {linked} glyph(s) (id {id}).");
		}
		if (WeavePerGlyph > 0 && linked > 0 && owner.Attunement is WeaveAttunement w)
			w.Add(WeavePerGlyph * linked);
	}
}"""),
# TriggerAll: repeat + Weave per glyph fired
("""public sealed class TriggerAllGlyphsEffect : EffectBase
{
	public int BonusPerOther; public bool Consume;
	public TriggerAllGlyphsEffect(int bonus, bool consume) { BonusPerOther = bonus; Consume = consume; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (s?.Glyphs == null || owner == null)
			return;
		s.Glyphs.TriggerAll(s, owner.TeamId, BonusPerOther, Consume);
	}
}""",
"""public sealed class TriggerAllGlyphsEffect : EffectBase
{
	public int BonusPerOther, Repeat = 1, WeavePerGlyph; public bool Consume;
	public TriggerAllGlyphsEffect(int bonus, bool consume, int repeat = 1, int weavePerGlyph = 0)
	{ BonusPerOther = bonus; Consume = consume; Repeat = Math.Max(1, repeat); WeavePerGlyph = weavePerGlyph; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (s?.Glyphs == null || owner == null)
			return;
		int fired = 0;
		for (int i = 0; i < Repeat; i++)
			fired += s.Glyphs.TriggerAll(s, owner.TeamId, BonusPerOther, Consume);
		if (WeavePerGlyph > 0 && fired > 0 && owner.Attunement is WeaveAttunement w)
			w.Add(WeavePerGlyph * fired);
	}
}"""),
# Pillars: real auras
("""public sealed class EnchantPillarEffect : EffectBase
{
	public int Count, AllyAll, EnemyDamageReduction; public string AuraStatus;
	public EnchantPillarEffect(int count, int allyAll, int enemyDr, string aura)
	{ Count = count; AllyAll = allyAll; EnemyDamageReduction = enemyDr; AuraStatus = aura; }""",
"""public sealed class EnchantPillarEffect : EffectBase
{
	public int Count, AllyAll, EnemyDamageReduction, AuraDamage, WeavePerTurn; public string AuraStatus;
	public EnchantPillarEffect(int count, int allyAll, int enemyDr, string aura, int auraDamage = 0, int weavePerTurn = 0)
	{ Count = count; AllyAll = allyAll; EnemyDamageReduction = enemyDr; AuraStatus = aura; AuraDamage = auraDamage; WeavePerTurn = weavePerTurn; }"""),
("""			if (s.Glyphs.Prepare(tile, owner, g =>
			{
				g.Trigger = GlyphTrigger.AllyEnter;
				g.Reusable = true;
				g.DurationTurns = -1;
				g.AllyArmor = AllyAll;
				g.AllyDamage = AllyAll;
				g.AllyShield = AllyAll;
			}) != null)
				placed++;
		}
		s.Log($"[EnchantPillar] raised {placed} permanent pillar(s). (enemy-adjacent aura pending per-turn aura hook)");""",
"""			bool first = placed == 0;
			if (s.Glyphs.Prepare(tile, owner, g =>
			{
				g.Trigger = GlyphTrigger.AllyEnter;
				g.Reusable = true;
				g.DurationTurns = -1;
				g.AllyArmor = AllyAll;
				g.AllyDamage = AllyAll;
				g.AllyShield = AllyAll;
				g.Pillar = true;
				g.AuraDamageReduction = EnemyDamageReduction;
				g.AuraStatus = AuraStatus;
				g.AuraDamage = AuraDamage;
				g.OwnerWeavePerTurn = first ? WeavePerTurn : 0;   // once per casting, not per pillar
			}) != null)
				placed++;
		}
		s.Log($"[EnchantPillar] raised {placed} Sovereign Pillar(s).");"""),
# Mirror Ward: charges, area, duration, bonus
("""public sealed class ReflectWardEffect : EffectBase
{
	public int Triggers, Radius;
	public ReflectWardEffect(int triggers, int radius) { Triggers = triggers; Radius = radius; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (s?.Glyphs == null || targets?.Items == null)
			return;
		var tile = InterfaceHelpers.ResolveTile(s, targets.Items[0]);
		if (tile == null)
			return;
		s.Glyphs.Prepare(tile, owner, g => { g.Trigger = GlyphTrigger.Manual; g.Status = "reflect"; g.StatusDuration = Triggers; g.DurationTurns = 3; });
		s.Log("[ReflectWard] placed. (spell-reflection resolution needs a cast-pipeline hook, see writeup)");
	}
}""",
"""public sealed class ReflectWardEffect : EffectBase
{
	public int Triggers, Radius, Duration;
	public float Bonus;
	public ReflectWardEffect(int triggers, int radius, int duration = 3, float bonus = 0f)
	{ Triggers = Math.Max(1, triggers); Radius = Math.Max(0, radius); Duration = duration; Bonus = bonus; }
	public override void Resolve(GameState s, Entity caster, TargetSet targets, EffectSnapshot snap)
	{
		var owner = FindCasterUnit(s, caster) ?? s.ActiveCasterUnit;
		if (s?.Glyphs == null || targets?.Items == null || targets.Items.Count == 0)
			return;
		var center = InterfaceHelpers.ResolveTile(s, targets.Items[0]);
		if (center == null)
			return;
		int placed = 0;
		foreach (var tile in s.Grid.Tiles.Values)
		{
			if (s.Grid.Distance(center.Axial, tile.Axial) > Radius)
				continue;
			if (s.Glyphs.Prepare(tile, owner, g =>
			{
				g.Trigger = GlyphTrigger.Manual;
				g.Reusable = true;
				g.ReflectCharges = Triggers;
				g.ReflectBonus = Bonus;
				g.DurationTurns = Duration;
			}) != null)
				placed++;
		}
		s.Log($"[ReflectWard] {placed} mirror glyph(s) prepared ({(Triggers >= 99 ? "every" : Triggers.ToString())} hit(s) each).");
	}
}"""),
# Spell Anchor
("""public sealed class SpellAnchorEffect : EffectBase
{
	public int Casts;
	public SpellAnchorEffect(int casts) { Casts = casts; }""",
"""public sealed class SpellAnchorEffect : EffectBase
{
	public int Casts, CostReduction, Weave, Duration = 3;
	public bool Reusable;
	public SpellAnchorEffect(int casts, int costReduction = 0, int weave = 0, int duration = 3, bool reusable = false)
	{ Casts = Math.Max(2, casts); CostReduction = costReduction; Weave = weave; Duration = duration; Reusable = reusable; }"""),
("""		s.Glyphs.Prepare(tile, owner, g => { g.Trigger = GlyphTrigger.SelfStand; g.Status = "anchor"; g.StatusDuration = Casts; g.DurationTurns = 3; });
		s.Log("[SpellAnchor] placed. (cast-twice resolution needs the cast pipeline, see writeup)");""",
"""		s.Glyphs.Prepare(tile, owner, g =>
		{
			g.Trigger = GlyphTrigger.SelfStand;
			g.AnchorCasts = Casts;
			g.AnchorCostReduction = CostReduction;
			g.AnchorWeave = Weave;
			g.Reusable = Reusable;
			g.DurationTurns = Duration;
		});
		s.Log($"[SpellAnchor] placed: the next spell cast standing on it resolves {Casts} times.");"""),
])

G = 'Scripts/Cards/Loader/CardScriptRegistry.Enchanter.cs'
edit(G, [
("""            int count = n.TryGetProperty("count", out var c) ? c.GetInt32() : 2;
            int bonus = n.TryGetProperty("cumulative_bonus", out var b) ? b.GetInt32() : 0;
            return new LinkGlyphsEffect(count, bonus).WithTag("Glyph");""",
"""            int count = n.TryGetProperty("count", out var c) ? c.GetInt32() : 2;
            int bonus = n.TryGetProperty("cumulative_bonus", out var b) ? b.GetInt32() : 0;
            int weave = n.TryGetProperty("on_trigger_weave", out var w) ? w.GetInt32() : 0;
            bool persist = n.TryGetProperty("persist", out var p) && p.ValueKind == JsonValueKind.True;
            return new LinkGlyphsEffect(count, bonus, weave, persist).WithTag("Glyph");"""),
("""            int bonus = n.TryGetProperty("bonus_per_other", out var b) ? b.GetInt32() : 0;
            bool consume = !n.TryGetProperty("consume", out var c) || c.GetBoolean();
            return new TriggerAllGlyphsEffect(bonus, consume).WithTag("Glyph");""",
"""            int bonus = n.TryGetProperty("bonus_per_other", out var b) ? b.GetInt32() : 0;
            bool consume = !n.TryGetProperty("consume", out var c) || c.GetBoolean();
            int repeat = n.TryGetProperty("repeat", out var r) ? r.GetInt32() : 1;
            int weave = n.TryGetProperty("on_trigger_weave", out var w) ? w.GetInt32() : 0;
            return new TriggerAllGlyphsEffect(bonus, consume, repeat, weave).WithTag("Glyph");"""),
("""            string aura = n.TryGetProperty("aura_status", out var au) ? au.GetString() : null;
            return new EnchantPillarEffect(count, allyAll, enemyDr, aura).WithTag("Glyph");""",
"""            string aura = n.TryGetProperty("aura_status", out var au) ? au.GetString() : null;
            int auraDmg = n.TryGetProperty("aura_damage", out var ad) ? ad.GetInt32() : 0;
            int wpt = n.TryGetProperty("weave_per_turn", out var wp) ? wp.GetInt32() : 0;
            return new EnchantPillarEffect(count, allyAll, enemyDr, aura, auraDmg, wpt).WithTag("Glyph");"""),
("""            int triggers = n.TryGetProperty("triggers", out var t) ? t.GetInt32() : 1;
            int radius = n.TryGetProperty("radius", out var r) ? r.GetInt32() : 0;
            return new ReflectWardEffect(triggers, radius).WithTag("Glyph");""",
"""            int triggers = n.TryGetProperty("triggers", out var t) ? t.GetInt32() : 1;
            int radius = n.TryGetProperty("radius", out var r) ? r.GetInt32() : 0;
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 3;
            float bonus = n.TryGetProperty("reflect_bonus", out var rb) ? (float)rb.GetDouble() : 0f;
            return new ReflectWardEffect(triggers, radius, dur, bonus).WithTag("Glyph");"""),
("""            int casts = n.TryGetProperty("casts", out var c) ? c.GetInt32() : 2;
            return new SpellAnchorEffect(casts).WithTag("Glyph");""",
"""            int casts = n.TryGetProperty("casts", out var c) ? c.GetInt32() : 2;
            int cr = n.TryGetProperty("cost_reduction", out var cc) ? cc.GetInt32() : 0;
            int weave = n.TryGetProperty("on_use_weave", out var w) ? w.GetInt32() : 0;
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 3;
            bool reuse = n.TryGetProperty("reusable", out var ru) && ru.ValueKind == JsonValueKind.True;
            return new SpellAnchorEffect(casts, cr, weave, dur, reuse).WithTag("Glyph");"""),
("""        // Mana tithe: status whose cost-up/refund lives in the status system
        // { "type": "mana_tithe", "duration": n }
        RegisterEffect("mana_tithe", n =>
        {
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 3;
            return new StatusApplyEffect("mana_taxed", dur, "(cost-up / mana-refund needs status hook)").WithTag("Control");
        });""",
"""        // Mana Tithe (slice 12a, ruled 2026-10-04): a Name on casting. Enemies have no
        // mana, so the "tax" is pain: if it casts, it takes damage (3 at amount 1, 5 at
        // amount 2, or an explicit "damage"), and its Namer gains the refund in mana and
        // weave_on_cast in Weave. Names punish, never forbid.
        // { "type": "mana_tithe", "amount": n, "refund": n, "weave_on_cast": n, "duration": n, "damage": n }
        RegisterEffect("mana_tithe", n =>
        {
            int dur = n.TryGetProperty("duration", out var d) ? d.GetInt32() : 3;
            int amount = n.TryGetProperty("amount", out var a) ? a.GetInt32() : 1;
            int dmg = n.TryGetProperty("damage", out var dm) ? dm.GetInt32() : 1 + 2 * Math.Max(1, amount);
            int refund = n.TryGetProperty("refund", out var r) ? r.GetInt32() : 1;
            int weave = n.TryGetProperty("weave_on_cast", out var w) ? w.GetInt32() : 0;
            return new NameConditionEffect(NameTrigger.Cast, dmg, dur)
                { OwnerMana = refund, OwnerWeave = weave }.WithTag("Control");
        });"""),
])

N = 'Scripts/Cards/Effects/EnchanterEngine.cs'
edit(N, [
("""    /// <summary>Round of the last break: a Name punishes once per round, not per tile walked.</summary>
    public int BrokenRound = -1;
""",
"""    /// <summary>Round of the last break: a Name punishes once per round, not per tile walked.</summary>
    public int BrokenRound = -1;
    /// <summary>Mana the Namer gains on each break (Mana Tithe's refund).</summary>
    public int OwnerMana;
    /// <summary>Extra Weave the Namer gains on each break, on top of the standard +1.</summary>
    public int OwnerWeave;
"""),
("""            if (name.Damage > 0)
                unit.ApplyDamage(name.Damage);
            NameBroken?.Invoke(unit, name);""",
"""            if (name.Damage > 0)
                unit.ApplyDamage(name.Damage);
            var namer = name.OwnerUnit;
            if (namer != null && GodotObject.IsInstanceValid(namer) && namer.Stats.IsAlive)
            {
                if (name.OwnerMana > 0)
                    namer.GainMana(name.OwnerMana);
                if (name.OwnerWeave > 0 && namer.Attunement is WeaveAttunement nw)
                    nw.Add(name.OwnerWeave);
                if (name.OwnerMana > 0 || name.OwnerWeave > 0)
                    log?.Invoke($"{namer.Name} collects the tithe: +{name.OwnerMana} mana"
                                + (name.OwnerWeave > 0 ? $", +{name.OwnerWeave} Weave." : "."));
            }
            NameBroken?.Invoke(unit, name);"""),
("""public sealed class NameConditionEffect : EffectBase
{
    public NameTrigger Triggers;
    public int Damage;
    public int Duration;
""",
"""public sealed class NameConditionEffect : EffectBase
{
    public NameTrigger Triggers;
    public int Damage;
    public int Duration;
    /// <summary>Payoffs to the Namer on each break (Mana Tithe).</summary>
    public int OwnerMana, OwnerWeave;
"""),
("""                OwnerUnit = owner,
                OwnerTeam = team,
                Source = s.ResolvingAbilityName ?? "a Name",
            }, s.Log);""",
"""                OwnerUnit = owner,
                OwnerTeam = team,
                Source = s.ResolvingAbilityName ?? "a Name",
                OwnerMana = OwnerMana,
                OwnerWeave = OwnerWeave,
            }, s.Log);"""),
])
