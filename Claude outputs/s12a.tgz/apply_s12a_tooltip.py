#!/usr/bin/env python3
# Slice 12a: tooltip tokens for anchors, mirrors and ward heals.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

edit('Scripts/Systems/TooltipManager.cs', [
("""        int sd = g.StatusDuration;
        return text""",
"""        int sd = g.StatusDuration;
        int rc = g.ReflectCharges > 0 ? g.ReflectCharges : sd;
        string nextHits = rc >= 99 ? "every attack or spell"
                        : rc == 1 ? "the next attack or spell"
                        : $"the next {rc} attacks or spells";
        return text"""),
("""            .Replace("{casts}", sd.ToString())
            .Replace("{next_spells}", sd == 1 ? "the next spell" : $"the next {sd} spells")""",
"""            .Replace("{casts}", (g.AnchorCasts > 0 ? g.AnchorCasts : sd).ToString())
            .Replace("{next_spells}", rc == 1 ? "the next spell" : $"the next {rc} spells")
            .Replace("{next_hits}", nextHits)
            .Replace("{heal_turn}", g.AllyHealPerTurn.ToString())"""),
])
