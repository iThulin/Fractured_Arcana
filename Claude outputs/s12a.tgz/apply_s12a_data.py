#!/usr/bin/env python3
# Slice 12a card data: Snare (movement ends), Binding Rune (leave penalty), Mana Tithe (Name on
# casting), Mirror Ward (attacks and spells), ward and Sigil Slide tooltip wording. Repo root.
import json, sys

NAMED = "Named (half damage, cannot move)"
cards = {}
def card(cid):
    if cid not in cards:
        cards[cid] = json.load(open(f"Data/Cards/{cid}.json", encoding='utf-8'))
    return cards[cid]

def with_after(d, after_key, key, value):
    out = {}
    for k, v in d.items():
        if k == key:
            continue
        out[k] = v
        if k == after_key:
            out[key] = value
    if key not in out:
        out[key] = value
    return out

def base(cid, half, field, value):
    d = card(cid)
    if field == "glyph_trigger":
        d[half] = with_after(d[half], "glyph_text", field, value)
    elif field not in d[half]:
        d[half] = with_after(d[half], "rules_text", field, value)
    else:
        d[half][field] = value

def rung(cid, half, tier, field, value, remove=False):
    d = card(cid)
    rs = [u for u in d["upgrades"] if u.get("tier") == tier
          and (u.get("half") == half or (tier == 1 and u.get("half") == "both"))]
    if len(rs) != 1:
        sys.exit(f"{cid} {half} T{tier}: expected one rung, found {len(rs)}")
    ch = rs[0]["changes"]
    idx = [i for i, c in enumerate(ch) if c.get("half") == half and c.get("field") == field]
    if remove:
        for i in reversed(idx):
            ch.pop(i)
        return
    if idx:
        ch[idx[0]]["value"] = value
    else:
        ch.append({"half": half, "field": field, "value": value})

def rung_value(cid, half, tier, field):
    d = card(cid)
    for u in d["upgrades"]:
        if u.get("tier") == tier and (u.get("half") == half or (tier == 1 and u.get("half") == "both")):
            for c in u["changes"]:
                if c.get("half") == half and c.get("field") == field:
                    return c["value"]
    sys.exit(f"{cid} {half} T{tier}: no change for {field}")

# ── Snare Glyph (§4): it takes 4 and its movement ends ────────────────
c = "enchanter_snare_glyph"
e = card(c)["top"]["effect"]
e.pop("status", None); e.pop("status_duration", None); e["halt_movement"] = True
base(c, "top", "rules_text", "Prepare a glyph on a tile within 3. When an enemy enters: it takes 4 damage and its movement ends.")
base(c, "top", "glyph_text", "It takes {damage} damage and its movement ends.")
rung(c, "top", 1, "rules_text", "Prepare a glyph within 3. When an enemy enters, it takes 6 damage and its movement ends.")
rung(c, "top", 2, "rules_text", "Prepare a glyph within 3. When an enemy enters, it takes 6, its movement ends, and it is Weakened for 2 turns.")
rung(c, "top", 2, "glyph_text", "It takes {damage} damage, its movement ends, and it is Weakened for {status_turns}.")
rung(c, "top", 3, "rules_text", "Prepare a reusable glyph within 3. Each enemy entering takes 6, its movement ends, and it is Weakened for 2 turns.")
t4 = rung_value(c, "top", 4, "effect"); t4["halt_movement"] = True
rung(c, "top", 4, "effect", t4)
rung(c, "top", 4, "rules_text", f"Prepare a reusable glyph within 3. Each enemy entering takes 8, its movement ends, and it is {NAMED} for 1 turn.")
rung(c, "top", 4, "glyph_text", f"It takes {{damage}} damage, its movement ends, and it is {NAMED} for {{status_turns}}.")

# ── Binding Rune (§4): 3 now, 3 more if it leaves this turn ───────────
c = "enchanter_binding_rune"
e = card(c)["top"]["effect"]
e.pop("status", None); e.pop("status_duration", None); e["name_on_trigger"] = True
base(c, "top", "rules_text", "Prepare a glyph within 3. An enemy here at the start of its turn takes 3 damage, and 3 more if it leaves this turn. Lasts 2 turns.")
base(c, "top", "glyph_text", "It takes {damage} damage, and {damage} more if it leaves this turn.")
rung(c, "top", 1, "rules_text", "Prepare a glyph within 3. An enemy here at the start of its turn takes 3 damage, and 3 more if it leaves this turn. Lasts 3 turns.")
rung(c, "top", 2, "status_duration", None, remove=True)
rung(c, "top", 2, "effect.status_duration", None, remove=True)
rung(c, "top", 2, "rules_text", "Prepare a glyph within 3. An enemy here at the start of its turn takes 5 damage, and 5 more if it leaves this turn. Lasts 3 turns.")
rung(c, "top", 3, "rules_text", "Prepare a reusable glyph within 3. Each turn an enemy here takes 5 damage, and 5 more if it leaves that turn. Lasts 3 turns.")

# ── Mana Tithe: a Name on casting (ruled 2026-10-04) ──────────────────
c = "enchanter_mana_tithe"
base(c, "top", "rules_text", "Name an enemy for 3 turns: if it casts, it takes 3 damage and you gain 1 mana. Gain 1 Weave.")
rung(c, "top", 1, "rules_text", "Name an enemy for 3 turns: if it casts, it takes 5 damage and you gain 1 mana. Gain 1 Weave.")
rung(c, "top", 2, "rules_text", "Name an enemy for 3 turns: if it casts, it takes 5 damage and you gain 2 mana. Gain 1 Weave.")
rung(c, "top", 3, "rules_text", "Name an enemy for 3 turns: if it casts, it takes 5 damage and you gain 2 mana and 1 Weave. Gain 1 Weave.")
rung(c, "top", 4, "rules_text", "Name every enemy for 3 turns: if one casts, it takes 5 damage and you gain 2 mana and 1 Weave. Gain 2 Weave.")

# ── Mirror Ward: attacks and spells (ruled 2026-10-04) ────────────────
c = "enchanter_mirror_ward"
base(c, "top", "rules_text", "Prepare a glyph within 4. The next attack or spell that hits a unit on this tile is turned back on its attacker. Lasts 3 turns.")
base(c, "top", "glyph_text", "Turns {next_hits} back on the attacker.")
base(c, "top", "glyph_trigger", "When an enemy attack or spell hits a unit on this tile.")
rung(c, "top", 1, "rules_text", "Prepare a glyph within 4. The next 2 attacks or spells that hit a unit on this tile are turned back on their attackers. Lasts 3 turns.")
rung(c, "top", 2, "rules_text", "Prepare mirror glyphs on a 1-tile radius within 4. Each turns back the next 2 attacks or spells on units there. Lasts 3 turns.")
rung(c, "top", 3, "rules_text", "Prepare mirror glyphs (radius 1) within 4. Each turns back the next 2 attacks or spells on units there, for +50% damage. Lasts 3 turns.")
rung(c, "top", 3, "glyph_text", "Turns {next_hits} back on the attacker with +50% damage.")
rung(c, "top", 4, "rules_text", "Prepare mirror glyphs (radius 1) for 3 turns. Every attack or spell on units there is turned back for +50% damage.")
rung(c, "top", 4, "glyph_text", None, remove=True)

# ── Wards are auras now: tooltip wording ──────────────────────────────
W = "While it stands here it has"
c = "enchanter_charm_drift"
base(c, "bottom", "glyph_text", f"{W} +{{armor}} armor.")
rung(c, "bottom", 2, "glyph_text", f"{W} +{{armor}} armor. It gains {{shield}} shield once per round.")
rung(c, "bottom", 3, "glyph_text", f"{W} +{{armor}} armor and +{{ally_damage}} spell damage. It gains {{shield}} shield once per round.")
c = "enchanter_dominion"
base(c, "bottom", "glyph_text", f"{W} +{{armor}} armor. It gains {{shield}} shield once per round.")
rung(c, "bottom", 2, "glyph_text", f"{W} +{{armor}} armor and +{{ally_damage}} spell damage. It gains {{shield}} shield once per round.")
rung(c, "bottom", 3, "glyph_text", f"{W} +{{armor}} armor and +{{ally_damage}} spell damage, and heals {{heal_turn}} HP each turn. It gains {{shield}} shield once per round.")
rung(c, "bottom", 4, "glyph_text", None, remove=True)
for c in ("enchanter_geas", "enchanter_hex_mark"):
    base(c, "bottom", "glyph_text", f"{W} +{{ally_damage}} spell damage.")
    rung(c, "bottom", 2, "glyph_text", f"{W} +{{ally_damage}} spell damage. It gains {{shield}} shield once per round.")
    rung(c, "bottom", 4, "glyph_text", f"{W} +{{ally_damage}} spell damage and +{{armor}} armor. It gains {{shield}} shield once per round.")
c = "enchanter_sovereign_will"
P0 = f"{W} +{{armor}} armor and +{{ally_damage}} spell damage, and it gains {{shield}} shield once per round."
base(c, "top", "glyph_text", P0 + " Adjacent enemies deal 2 less and end their turn Weakened.")
rung(c, "top", 3, "glyph_text", P0 + " Adjacent enemies deal 2 less and end their turn Weakened. You gain 1 Weave each turn.")
rung(c, "top", 4, "glyph_text", P0 + f" Adjacent enemies deal 3 less, take 3 damage and are {NAMED}. You gain 1 Weave each turn.")
c = "enchanter_runic_trap"
rung(c, "bottom", 2, "glyph_text", "It gains {shield} shield and +{ally_damage} damage on its next spell.")
rung(c, "bottom", 4, "glyph_text", f"{W} +{{armor}} armor and +{{ally_damage}} spell damage. It gains {{shield}} shield once per round.")

for cid, d in cards.items():
    open(f"Data/Cards/{cid}.json", 'w', encoding='utf-8').write(json.dumps(d, indent='\t', ensure_ascii=False) + '\n')
    print("patched", cid)
