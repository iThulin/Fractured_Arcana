#!/usr/bin/env python3
# Slice 12a (2026-10-04): Enchanter glyph engine completion, part 1 of 2 (core).
# GlyphData, GlyphManager, loader glyph fields, Unit next-spell bonus. Run from repo root.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

# ── GlyphData ─────────────────────────────────────────────────────────
edit('Scripts/Systems/Combat/Glyphs/GlyphData.cs', [
("""    /// <summary>When &gt; 0, on trigger this glyph re-prepares a copy of itself on this many adjacent tiles (Runic Cascade). The GlyphManager handles the spread in OnGlyphFired.</summary>
    public int CascadeSpread;
""",
"""    /// <summary>When &gt; 0, on trigger this glyph re-prepares a copy of itself on this many adjacent tiles (Runic Cascade). The GlyphManager handles the spread in OnGlyphFired.</summary>
    public int CascadeSpread;

    /// <summary>Cascade copies go off at once on any enemy already standing where they land (Chain Cascade).</summary>
    public bool InstantCopies;

    // ── Slice 12a payloads ─────────────────────────────────────────────
    /// <summary>Enter glyphs: the enemy's movement ends here (Snare Glyph, §4).</summary>
    public bool HaltsMovement;

    /// <summary>When &gt; 0, the enemy that sets it off is also Named for 1 turn: "if it
    /// moves, it takes this" (Binding Rune, §4: "and 3 more if it leaves this turn").</summary>
    public int NameOnTrigger;

    /// <summary>Self-stand (Sigil of Focus): while the OWNER stands on it, spells cost this much less.</summary>
    public int CasterCostReduction;
    /// <summary>Self-stand: while the owner stands on it, their spells deal this much more.</summary>
    public int CasterDamage;
    /// <summary>Self-stand: the owner gains this much Weave at each turn start spent on it.</summary>
    public int CasterWeavePerTurn;

    /// <summary>Spell Anchor: the next spell the owner casts while standing here resolves this
    /// many times in total (0 = not an anchor).</summary>
    public int AnchorCasts;
    /// <summary>Spell Anchor: the anchored spell costs this much less.</summary>
    public int AnchorCostReduction;
    /// <summary>Spell Anchor: Weave each time it is used.</summary>
    public int AnchorWeave;

    /// <summary>Ward aura: an ally standing here at turn start heals this much (Hallowed Ground).</summary>
    public int AllyHealPerTurn;

    /// <summary>Fate Weaver (The Great Loom): each time it goes off, a glyph dealing this much
    /// is also prepared on an empty tile near it.</summary>
    public int SpawnGlyphDamage;

    /// <summary>Mirror Ward: attacks or spells it will still turn back. 99 or more reads as unlimited.</summary>
    public int ReflectCharges;
    /// <summary>Mirror Ward: a reflected hit deals this fraction more (0.5 = +50%).</summary>
    public float ReflectBonus;

    /// <summary>Sovereign Pillar: an indestructible ward with an aura over adjacent enemies.</summary>
    public bool Pillar;
    /// <summary>Pillar: adjacent enemies deal this much less.</summary>
    public int AuraDamageReduction;
    /// <summary>Pillar: status each adjacent enemy carries out of the round (weakened, named).</summary>
    public string AuraStatus;
    /// <summary>Pillar: damage each adjacent enemy takes at each round's turn.</summary>
    public int AuraDamage;
    /// <summary>Weave the owner gains each turn while this glyph stands (Throne of Pillars).</summary>
    public int OwnerWeavePerTurn;

    /// <summary>A reusable ally-enter glyph is a WARD: its armor and spell damage last only
    /// while the ally stands on it, and its shield and mana are granted once per ally per
    /// round. A single-use ally glyph is a gift: everything it grants is kept.</summary>
    public bool IsWardAura => Reusable && Trigger == GlyphTrigger.AllyEnter;
"""),
("""            if (!string.IsNullOrEmpty(Status))
                who.ApplyStatus(Status, StatusDuration);
            if (dmg > 0 || Status != null)
                s.Log($"[Glyph] {who.Name} triggers glyph: {dmg} dmg" + (Status != null ? $", {Status} {StatusDuration}t" : ""));
        }
        else if (friendlyToOwner && who != null)
        {
            if (AllyArmor > 0)""",
"""            if (!string.IsNullOrEmpty(Status))
                who.ApplyStatus(Status, StatusDuration);
            if (dmg > 0 || Status != null)
                s.Log($"[Glyph] {who.Name} triggers glyph: {dmg} dmg" + (Status != null ? $", {Status} {StatusDuration}t" : ""));
            if (HaltsMovement && who.Stats.IsAlive)
            {
                who.MovementInterrupted = true;
                s.Log($"[Glyph] {who.Name}'s movement ends on the glyph.");
            }
            if (NameOnTrigger > 0 && who.Stats.IsAlive)
            {
                Names.Write(who, new NameCondition
                {
                    Triggers = NameTrigger.Move,
                    Damage = NameOnTrigger,
                    TurnsRemaining = 1,
                    OwnerUnit = Owner,
                    OwnerTeam = OwnerTeam,
                    Source = string.IsNullOrEmpty(SourceName) ? "a glyph" : SourceName,
                }, s.Log);
            }
        }
        else if (friendlyToOwner && who != null && IsWardAura && s?.Glyphs != null)
        {
            // Wards are auras: GlyphManager grants and revokes them by position.
            s.Glyphs.GrantWard(who, this, s);
        }
        else if (friendlyToOwner && who != null)
        {
            if (AllyArmor > 0)"""),
("""            if (AllyDamage > 0)
                who.BonusSpellDamage += AllyDamage;
            if (AllyMana > 0)
                who.GainMana(AllyMana);
            who.RefreshHealthBar();
            s.Log($"[Glyph] {who.Name} steps on ward: +{AllyArmor} armor, +{AllyShield} shield, +{AllyDamage} dmg.");""",
"""            // A single-use gift: spell damage is for the ally's NEXT spell, not forever.
            if (AllyDamage > 0)
                who.NextSpellBonusDamage += AllyDamage;
            if (AllyMana > 0)
                who.GainMana(AllyMana);
            who.RefreshHealthBar();
            s.Log($"[Glyph] {who.Name} steps on a glyph: +{AllyArmor} armor, +{AllyShield} shield, +{AllyDamage} damage on its next spell.");"""),
])

# ── Unit: one-spell damage bonus ──────────────────────────────────────
edit('Scripts/Systems/Combat/Core/Unit.cs', [
("""    public int BonusSpellDamage = 0;   // from wizard weapon/trinket
""",
"""    public int BonusSpellDamage = 0;   // from wizard weapon/trinket

    /// <summary>Added to this unit's NEXT card resolution only, then cleared (Sigil Slide's
    /// "+2 damage" gift). Consumed by the stack resolver.</summary>
    public int NextSpellBonusDamage = 0;
"""),
])

# ── Loader: new glyph fields ──────────────────────────────────────────
edit('Scripts/Cards/Loader/JsonCardLoader.cs', [
("""            OwnerWeave = Geti("on_trigger_weave"),
            OwnerHeal = Geti("heal_caster")
        };""",
"""            OwnerWeave = Geti("on_trigger_weave"),
            OwnerHeal = Geti("heal_caster"),
            // Slice 12a
            InstantCopies = Getb("instant_copies"),
            HaltsMovement = Getb("halt_movement"),
            NameOnTrigger = n.TryGetProperty("name_on_trigger", out var nt)
                ? (nt.ValueKind == JsonValueKind.True ? dmg : nt.ValueKind == JsonValueKind.Number ? nt.GetInt32() : 0)
                : 0,
            CasterCostReduction = Geti("caster_cost_reduction"),
            CasterDamage = Geti("caster_damage"),
            CasterWeavePerTurn = Geti("caster_weave_per_turn"),
            AllyHealPerTurn = Geti("ally_heal_per_turn"),
            SpawnGlyphDamage = n.TryGetProperty("on_trigger_spawn_glyph", out var sg)
                ? (sg.ValueKind == JsonValueKind.True ? 3 : sg.ValueKind == JsonValueKind.Number ? sg.GetInt32() : 0)
                : 0,
        };"""),
])

# ── PrepareGlyphEffect carries them ───────────────────────────────────
edit('Scripts/Cards/Effects/EnchanterEffects.cs', [
("""	public int OwnerDraw, OwnerMana, OwnerWeave, OwnerHeal;

	/// <summary>Identity of the half that owns this effect""",
"""	public int OwnerDraw, OwnerMana, OwnerWeave, OwnerHeal;
	// Slice 12a
	public bool InstantCopies, HaltsMovement;
	public int NameOnTrigger, CasterCostReduction, CasterDamage, CasterWeavePerTurn, AllyHealPerTurn, SpawnGlyphDamage;

	/// <summary>Identity of the half that owns this effect"""),
("""		g.OwnerWeave = OwnerWeave;
		g.OwnerHeal = OwnerHeal;
	}""",
"""		g.OwnerWeave = OwnerWeave;
		g.OwnerHeal = OwnerHeal;
		g.InstantCopies = InstantCopies;
		g.HaltsMovement = HaltsMovement;
		g.NameOnTrigger = NameOnTrigger;
		g.CasterCostReduction = CasterCostReduction;
		g.CasterDamage = CasterDamage;
		g.CasterWeavePerTurn = CasterWeavePerTurn;
		g.AllyHealPerTurn = AllyHealPerTurn;
		g.SpawnGlyphDamage = SpawnGlyphDamage;
	}"""),
])
