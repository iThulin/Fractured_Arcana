#!/usr/bin/env python3
# Slice 12a: enemy executor hooks (pillar cut, Mirror Ward reflection, Fate Weaver on enemy casts).
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

# CombatManager.Enchanter.cs needs System for Math.
p = 'Scripts/Systems/Combat/Core/CombatManager.Enchanter.cs'
s = open(p, encoding='utf-8').read()
if 'using System;\n' not in s:
    s = s.replace('using Godot;\n', 'using Godot;\nusing System;\n', 1)
    open(p, 'w', encoding='utf-8').write(s)
    print("patched", p, "(using System)")

edit('Scripts/Systems/Combat/Core/CombatManager.EnemyIntents.cs', [
("""        else
        {
            // §9 reaction grammar: a redirected strike names its interceptor.
            string hit = wasRedirected
                ? UIContent.ReactionRedirectLine(victim.Name, attackerName, noun, damage)
                : $"{attackerName} {verb} {victim.Name} for {damage} damage.";
            GD.Print(hit);
            combatUI?.AppendActionLog(hit);
            CombatPresenter.EmitStrike(attacker, victim, ranged ? Delivery.Bolt : Delivery.Melee);   // spell_vfx_pipeline_v1 §5 phase 2
            victim.ApplyDamage(damage, attacker, ranged ? Delivery.Bolt : Delivery.Melee);
            LastStrikeVictim = victim;
        }""",
"""        else
        {
            // Enchanter (slice 12a): a Sovereign Pillar blunts the blow; a Mirror Ward
            // under the victim turns it back on the attacker instead.
            damage = EnchanterStrikeDamage(attacker, damage);
            if (!TryReflectStrike(attacker, victim, damage))
            {
                // §9 reaction grammar: a redirected strike names its interceptor.
                string hit = wasRedirected
                    ? UIContent.ReactionRedirectLine(victim.Name, attackerName, noun, damage)
                    : $"{attackerName} {verb} {victim.Name} for {damage} damage.";
                GD.Print(hit);
                combatUI?.AppendActionLog(hit);
                CombatPresenter.EmitStrike(attacker, victim, ranged ? Delivery.Bolt : Delivery.Melee);   // spell_vfx_pipeline_v1 §5 phase 2
                victim.ApplyDamage(damage, attacker, ranged ? Delivery.Bolt : Delivery.Melee);
                LastStrikeVictim = victim;
            }
        }"""),
("""                Names.Break(enemy, NameTrigger.Cast, LogName);   // starting a spell is casting
                if (!IsValidActor(enemy))
                    break;""",
"""                Names.Break(enemy, NameTrigger.Cast, LogName);   // starting a spell is casting
                if (!IsValidActor(enemy))
                    break;
                OnEnemySpellCast(enemy);"""),
("""                Names.Break(enemy, NameTrigger.Cast, LogName);
                if (!IsValidActor(enemy))
                    break;
                if (IsRitualist(enemy))
                    await ExecuteRitualRelease(enemy, intent);""",
"""                Names.Break(enemy, NameTrigger.Cast, LogName);
                if (!IsValidActor(enemy))
                    break;
                OnEnemySpellCast(enemy);
                if (IsRitualist(enemy))
                    await ExecuteRitualRelease(enemy, intent);"""),
("""                Names.Break(enemy, NameTrigger.Cast, LogName);
                if (!IsValidActor(enemy))
                    break;
                await ExecuteImbueIntent(enemy, intent);""",
"""                Names.Break(enemy, NameTrigger.Cast, LogName);
                if (!IsValidActor(enemy))
                    break;
                OnEnemySpellCast(enemy);
                await ExecuteImbueIntent(enemy, intent);"""),
])
