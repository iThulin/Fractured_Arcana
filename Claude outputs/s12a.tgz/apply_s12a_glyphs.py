#!/usr/bin/env python3
# Slice 12a: GlyphManager (wards, standing glyphs, anchors, Fate Weaver, cascades, links, pillars).
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

R = 'Scripts/Systems/Combat/Glyphs/GlyphManager.cs'
edit(R, [
# ── Prepare: persistent links, aura grant on an occupied ward tile ──
("""        configure?.Invoke(g);
        // Ownerless glyphs (map events) and cascade copies are not the resolving spell's.
        if (stampFromCast && owner != null)
            StampFromCast(g);
        tile.Glyph = g;

        if (!g.Invisible)
            tile.TileView?.ShowGlyph(g);
        OnGlyphPlaced?.Invoke(tile);

        if (owner?.Attunement is WeaveAttunement w)
            w.OnGlyphPrepared();
        return g;
    }""",
"""        configure?.Invoke(g);
        // Ownerless glyphs (map events) and cascade copies are not the resolving spell's.
        if (stampFromCast && owner != null)
            StampFromCast(g);

        // A standing network ("link all glyphs for the rest of the fight") takes in
        // every glyph its team prepares afterwards.
        if (g.LinkId == 0 && _persistentLinks.TryGetValue(g.OwnerTeam, out var pl))
        {
            g.LinkId = pl.Id;
            g.CumulativeBonus = pl.Bonus;
        }

        tile.Glyph = g;

        if (!g.Invisible)
            tile.TileView?.ShowGlyph(g);
        OnGlyphPlaced?.Invoke(tile);

        if (owner?.Attunement is WeaveAttunement w)
            w.OnGlyphPrepared();

        // A ward prepared under an ally (Sanctuary around you) covers them at once;
        // nobody should have to step off and back on.
        var occ = tile.Occupant;
        if (g.IsWardAura && occ != null && GodotObject.IsInstanceValid(occ)
            && occ.Stats.IsAlive && occ.TeamId == g.OwnerTeam && _state != null)
            GrantWard(occ, g, _state);
        return g;
    }

    // ── Wards: auras by position (slice 12a) ─────────────────────────
    private sealed class WardGrant
    {
        public TileData Tile;
        public GlyphData Glyph;
        public int Armor, Damage;
    }

    private readonly Dictionary<Unit, WardGrant> _wards = new();
    private readonly Dictionary<(Unit, GlyphData), int> _wardConsumableRound = new();

    /// <summary>An ally entered (or stands on) a ward: its armor and spell damage hold while
    /// it stays; its shield and mana come once per ally per round, so stepping off and on
    /// again cannot farm them. Called from <see cref="GlyphData.Fire"/>.</summary>
    public void GrantWard(Unit unit, GlyphData g, GameState s)
    {
        if (unit == null || g == null || !GodotObject.IsInstanceValid(unit))
            return;
        var tile = unit.CurrentTile;
        if (_wards.TryGetValue(unit, out var cur) && cur.Glyph == g && cur.Tile == tile)
            return;   // already covered by this ward
        RevokeWard(unit);

        unit.Stats.Armor += g.AllyArmor;
        unit.BonusSpellDamage += g.AllyDamage;
        _wards[unit] = new WardGrant { Tile = tile, Glyph = g, Armor = g.AllyArmor, Damage = g.AllyDamage };

        var key = (unit, g);
        int shield = 0, mana = 0;
        if (!_wardConsumableRound.TryGetValue(key, out int r) || r != Names.Round)
        {
            _wardConsumableRound[key] = Names.Round;
            shield = g.AllyShield;
            mana = g.AllyMana;
            if (shield > 0)
                unit.Stats.Shield += shield;
            if (mana > 0)
                unit.GainMana(mana);
        }
        unit.RefreshHealthBar();
        s?.Log($"[Ward] {unit.Name} stands on {(string.IsNullOrEmpty(g.SourceName) ? "a ward" : g.SourceName)}: "
             + $"+{g.AllyArmor} armor and +{g.AllyDamage} spell damage while there"
             + (shield > 0 || mana > 0 ? $", +{shield} shield, +{mana} mana." : "."));
    }

    /// <summary>Takes back what a ward lent: the armor (as far as it is still there) and the
    /// spell damage. Shield and mana already granted are kept.</summary>
    public void RevokeWard(Unit unit)
    {
        if (unit == null || !_wards.TryGetValue(unit, out var w))
            return;
        _wards.Remove(unit);
        if (!GodotObject.IsInstanceValid(unit))
            return;
        unit.Stats.Armor = Math.Max(0, unit.Stats.Armor - w.Armor);
        unit.BonusSpellDamage -= w.Damage;
        unit.RefreshHealthBar();
    }

    /// <summary>Every tile entry: a unit that walked off its ward loses the aura.</summary>
    public void OnUnitEntered(Unit unit, TileData tile)
    {
        if (unit != null && _wards.TryGetValue(unit, out var w) && w.Tile != tile)
            RevokeWard(unit);
    }

    private void RevokeWardsOn(TileData tile)
    {
        foreach (var u in _wards.Where(kv => kv.Value.Tile == tile).Select(kv => kv.Key).ToList())
            RevokeWard(u);
    }

    // ── Standing glyphs: Sigil of Focus, Spell Anchor (slice 12a) ────
    /// <summary>The self-stand glyph <paramref name="u"/> owns and stands on, or null.</summary>
    public static GlyphData StandingGlyph(Unit u)
    {
        if (u == null || !GodotObject.IsInstanceValid(u))
            return null;
        var g = u.CurrentTile?.Glyph;
        return g != null && !g.Consumed && g.Trigger == GlyphTrigger.SelfStand && g.Owner == u ? g : null;
    }

    /// <summary>How much cheaper <paramref name="u"/>'s spells are right now from the glyph
    /// under it. Read by ManaCost.EffectiveAmount, so the pips, affordability and payment agree.</summary>
    public static int StandingCostReduction(Unit u)
    {
        var g = StandingGlyph(u);
        return g == null ? 0 : g.CasterCostReduction + (g.AnchorCasts > 0 ? g.AnchorCostReduction : 0);
    }

    /// <summary>Spell damage the glyph under <paramref name="u"/> adds to its casts.</summary>
    public static int StandingDamageBonus(Unit u) => StandingGlyph(u)?.CasterDamage ?? 0;

    /// <summary>The Spell Anchor under <paramref name="u"/>, or null.</summary>
    public static GlyphData StandingAnchor(Unit u)
    {
        var g = StandingGlyph(u);
        return g != null && g.AnchorCasts > 1 ? g : null;
    }

    /// <summary>A spell was anchored: pay out its Weave and, unless the anchor lasts, use it up.</summary>
    public void SpendAnchor(Unit u, GlyphData anchor, GameState s)
    {
        if (u == null || anchor == null)
            return;
        if (anchor.AnchorWeave > 0 && u.Attunement is WeaveAttunement w)
            w.Add(anchor.AnchorWeave);
        if (!anchor.Reusable && u.CurrentTile?.Glyph == anchor)
            Remove(u.CurrentTile);
        s?.Log($"[SpellAnchor] the anchored spell resolves {anchor.AnchorCasts} times.");
    }

    // ── Persistent networks (slice 12a) ──────────────────────────────
    private readonly Dictionary<int, (int Id, int Bonus)> _persistentLinks = new();

    /// <summary>Links every friendly glyph and keeps the network open: glyphs the team
    /// prepares later join it ("for the rest of the fight").</summary>
    public int LinkPersistent(int team, int cumulativeBonus)
    {
        int id = _persistentLinks.TryGetValue(team, out var pl) ? pl.Id : _nextLinkId++;
        _persistentLinks[team] = (id, cumulativeBonus);
        int n = 0;
        foreach (var tile in GetAllFriendly(team))
        {
            tile.Glyph.LinkId = id;
            tile.Glyph.CumulativeBonus = cumulativeBonus;
            n++;
        }
        return n;
    }"""),

# ── Tick: ward heals, standing Weave, pillar auras, owner Weave ──
("""        foreach (var tile in _grid.Tiles.Values.ToList())
        {
            var g = tile.Glyph;
            if (g == null)
                continue;

            // Start-of-turn enemy triggers""",
"""        foreach (var tile in _grid.Tiles.Values.ToList())
        {
            var g = tile.Glyph;
            if (g == null)
                continue;

            TickAuras(tile, g, s);

            // Start-of-turn enemy triggers"""),
("""    /// <summary>
    /// Call from <see cref="Unit.PlaceOnTile"/> immediately after a glyph fires (and before""",
"""    /// <summary>Once per round, per glyph: ward heals, the self-stand Weave, pillar auras
    /// on adjacent enemies, and per-turn Weave for the owner.</summary>
    private void TickAuras(TileData tile, GlyphData g, GameState s)
    {
        var occ = tile.Occupant;
        bool occAlive = occ != null && GodotObject.IsInstanceValid(occ) && occ.Stats.IsAlive;

        if (g.AllyHealPerTurn > 0 && occAlive && occ.TeamId == g.OwnerTeam)
        {
            int before = occ.Stats.Health;
            occ.Stats.Health = Math.Min(occ.Stats.MaxHealth, occ.Stats.Health + g.AllyHealPerTurn);
            occ.RefreshHealthBar();
            if (occ.Stats.Health > before)
                s.Log($"[Ward] {occ.Name} heals {occ.Stats.Health - before} on the ward.");
        }

        if (g.CasterWeavePerTurn > 0 && occAlive && occ == g.Owner && occ.Attunement is WeaveAttunement sw)
        {
            sw.Add(g.CasterWeavePerTurn);
            s.Log($"[Sigil] {occ.Name} holds the sigil: +{g.CasterWeavePerTurn} Weave.");
        }

        if (g.OwnerWeavePerTurn > 0 && g.Owner != null && GodotObject.IsInstanceValid(g.Owner)
            && g.Owner.Stats.IsAlive && g.Owner.Attunement is WeaveAttunement ow)
            ow.Add(g.OwnerWeavePerTurn);

        if (g.Pillar && (g.AuraDamage > 0 || !string.IsNullOrEmpty(g.AuraStatus)) && _grid != null)
        {
            foreach (var n in _grid.GetNeighbors(tile.Axial))
            {
                var e = _grid.GetTile(n)?.Occupant;
                if (e == null || !GodotObject.IsInstanceValid(e) || !e.Stats.IsAlive || e.TeamId == g.OwnerTeam)
                    continue;
                if (g.AuraDamage > 0)
                    e.ApplyDamage(g.AuraDamage);
                if (!string.IsNullOrEmpty(g.AuraStatus) && e.Stats.IsAlive)
                    e.ApplyStatus(g.AuraStatus, 1);
                s.Log($"[Pillar] {e.Name} stands beside a Sovereign Pillar"
                      + (g.AuraDamage > 0 ? $": {g.AuraDamage} damage" : "")
                      + (!string.IsNullOrEmpty(g.AuraStatus) ? $", {g.AuraStatus}." : "."));
            }
        }
    }

    /// <summary>Damage an attack from <paramref name="attacker"/> loses for standing beside
    /// an opposing Sovereign Pillar (the largest reduction applies, not the sum).</summary>
    public int PillarDamageReduction(Unit attacker)
    {
        if (attacker?.CurrentTile == null || _grid == null)
            return 0;
        int best = 0;
        foreach (var n in _grid.GetNeighbors(attacker.CurrentTile.Axial))
        {
            var g = _grid.GetTile(n)?.Glyph;
            if (g != null && g.Pillar && g.OwnerTeam != attacker.TeamId)
                best = Math.Max(best, g.AuraDamageReduction);
        }
        return best;
    }

    /// <summary>
    /// Call from <see cref="Unit.PlaceOnTile"/> immediately after a glyph fires (and before"""),

# ── Cascade: copies inherit InstantCopies and can go off at once ──
("""                    ng.CascadeSpread = sp; // copies spread one fewer to terminate the chain
                }, stampFromCast: false);
                spread++;""",
"""                    ng.CascadeSpread = sp; // copies spread one fewer to terminate the chain
                    ng.InstantCopies = g.InstantCopies;
                }, stampFromCast: false);
                spread++;
                // Chain Cascade: a copy that lands under an enemy goes off at once. The
                // chain ends because every generation spreads one fewer.
                var copy = nbr.Glyph;
                var under = nbr.Occupant;
                if (g.InstantCopies && copy != null && under != null && GodotObject.IsInstanceValid(under)
                    && under.Stats.IsAlive && under.TeamId != copy.OwnerTeam)
                {
                    copy.Fire(under, s);
                    if (!OnGlyphFired(s, nbr, under))
                        Remove(nbr);
                }"""),

# ── Remove revokes wards ──
("""        if (tile?.Glyph == null)
            return;
        tile.Glyph = null;
        tile.TileView?.ClearGlyph();
        OnGlyphRemoved?.Invoke(tile);""",
"""        if (tile?.Glyph == null)
            return;
        RevokeWardsOn(tile);
        tile.Glyph = null;
        tile.TileView?.ClearGlyph();
        OnGlyphRemoved?.Invoke(tile);"""),

# ── Swap / Rearm keep the light circle ──
("""        (a.Glyph, b.Glyph) = (b.Glyph, a.Glyph);
        a.TileView?.ClearGlyph();
        b.TileView?.ClearGlyph();
        if (a.Glyph is { Invisible: false })
            a.TileView?.ShowGlyph();
        if (b.Glyph is { Invisible: false })
            b.TileView?.ShowGlyph();""",
"""        RevokeWardsOn(a);
        RevokeWardsOn(b);
        (a.Glyph, b.Glyph) = (b.Glyph, a.Glyph);
        a.TileView?.ClearGlyph();
        b.TileView?.ClearGlyph();
        if (a.Glyph is { Invisible: false })
            a.TileView?.ShowGlyph(a.Glyph);
        if (b.Glyph is { Invisible: false })
            b.TileView?.ShowGlyph(b.Glyph);"""),
("""            if (empower > 0)
                g.Damage += empower;
            if (!g.Invisible)
                tile.TileView?.ShowGlyph();""",
"""            if (empower > 0)
                g.Damage += empower;
            if (!g.Invisible)
                tile.TileView?.ShowGlyph(g);"""),

# ── Fate Weaver: real hook, owner tiles, spawned threads ──
("""    /// <summary>Fired by the cast pipeline when a spell resolves, to trigger SpellCastNear glyphs in range. Optional: wire from Resolver/CombatManager if you want Fate Weaver to work.</summary>
    public void OnSpellCastAt(GameState s, int casterTeam, Vector2I at)
    {
        if (_grid?.Tiles == null)
            return;
        foreach (var tile in _grid.Tiles.Values.ToList())
        {
            var g = tile.Glyph;
            if (g == null || g.Trigger != GlyphTrigger.SpellCastNear)
                continue;
            if (_grid.Distance(tile.Axial, at) > g.Radius)
                continue;
            g.Fire(null, s);
            if (g.Owner?.Attunement is WeaveAttunement w)
                w.OnGlyphTriggered();
            if (!g.Reusable)
                Remove(tile);
        }
    }""",
"""    /// <summary>A spell was cast (any side). Every SpellCastNear glyph within its radius of
    /// ANY of <paramref name="points"/> (the caster's tile and where it landed) goes off once:
    /// owner payoffs, plus a spawned glyph for The Great Loom. Called by the stack resolver for
    /// card casts and by the enemy executor for spell intents.</summary>
    public void OnSpellCastAt(GameState s, int casterTeam, IEnumerable<Vector2I> points)
    {
        if (_grid?.Tiles == null || points == null)
            return;
        var pts = points.ToList();
        if (pts.Count == 0)
            return;
        foreach (var tile in _grid.Tiles.Values.ToList())
        {
            var g = tile.Glyph;
            if (g == null || g.Trigger != GlyphTrigger.SpellCastNear)
                continue;
            if (!pts.Any(p => _grid.Distance(tile.Axial, p) <= g.Radius))
                continue;
            g.Fire(null, s);
            s?.Log($"[Glyph] {(string.IsNullOrEmpty(g.SourceName) ? "A glyph" : g.SourceName)} answers a spell cast nearby.");
            if (g.Owner?.Attunement is WeaveAttunement w)
                w.OnGlyphTriggered();
            if (g.SpawnGlyphDamage > 0)
                SpawnThread(tile, g, s);
            if (!g.Reusable)
                Remove(tile);
        }
    }

    public void OnSpellCastAt(GameState s, int casterTeam, Vector2I at)
        => OnSpellCastAt(s, casterTeam, new[] { at });

    // The Great Loom: a small enter glyph on the nearest empty tile within 2.
    private void SpawnThread(TileData from, GlyphData parent, GameState s)
    {
        if (_grid == null)
            return;
        var spot = _grid.Tiles.Values
            .Where(t => t != from && t.Glyph == null && !t.IsBlocked && t.Occupant == null && t.IsWalkable
                        && _grid.Distance(from.Axial, t.Axial) <= 2)
            .OrderBy(t => _grid.Distance(from.Axial, t.Axial))
            .ThenBy(t => t.Axial.X).ThenBy(t => t.Axial.Y)
            .FirstOrDefault();
        if (spot == null)
            return;
        int dmg = parent.SpawnGlyphDamage;
        Prepare(spot, parent.Owner, ng =>
        {
            ng.Trigger = GlyphTrigger.Enter;
            ng.Damage = dmg;
            ng.SourceName = "Thread of Fate";
            ng.GlyphText = "It takes {damage} damage.";
            ng.SourceCardId = parent.SourceCardId;
            ng.SourceHalf = parent.SourceHalf;
        }, stampFromCast: false);
        s?.Log($"[Glyph] A thread of fate is prepared at ({spot.Axial.X}, {spot.Axial.Y}).");
    }"""),
])
