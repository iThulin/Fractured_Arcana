#!/usr/bin/env python3
# Slice 12a: resolver (standing glyphs, Spell Anchor, Fate Weaver, next-spell gift), cost, strikes.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

edit('Scripts/Systems/Combat/Core/RulesManager.cs', [
("""            if (schoolItemBonus > 0)
                item.CasterUnit.BonusSpellDamage += schoolItemBonus;
        }
""",
"""            if (schoolItemBonus > 0)
                item.CasterUnit.BonusSpellDamage += schoolItemBonus;
        }

        // Enchanter (slice 12a): a card cast from the caster's own Sigil of Focus gets its
        // spell damage, a Sigil Slide gift adds to this one spell, and a Spell Anchor under
        // the caster is noted BEFORE the effects run, so the spell that prepares an anchor
        // is never the one it repeats. Same pin/unpin shape as Perfected.
        Unit glyphCaster = item.Ability is CardHalf && item.CasterUnit != null
            && GodotObject.IsInstanceValid(item.CasterUnit) ? item.CasterUnit : null;
        int glyphBonus = 0;
        GlyphData anchor = null;
        if (glyphCaster != null)
        {
            glyphBonus = GlyphManager.StandingDamageBonus(glyphCaster) + glyphCaster.NextSpellBonusDamage;
            glyphCaster.NextSpellBonusDamage = 0;
            if (glyphBonus > 0)
                glyphCaster.BonusSpellDamage += glyphBonus;
            anchor = GlyphManager.StandingAnchor(glyphCaster);
        }
"""),
("""            foreach (var eff in item.Ability.Effects)
                eff.Resolve(s, item.Caster, item.Targets, item.Snapshot);
        }
        finally""",
"""            foreach (var eff in item.Ability.Effects)
                eff.Resolve(s, item.Caster, item.Targets, item.Snapshot);

            // Spell Anchor: the same effects again, against the same targets, until the
            // anchor's count is reached. Only if the anchor is still under the caster.
            if (anchor != null && GlyphManager.StandingAnchor(glyphCaster) == anchor)
            {
                for (int rep = 1; rep < anchor.AnchorCasts; rep++)
                    foreach (var eff in item.Ability.Effects)
                        eff.Resolve(s, item.Caster, item.Targets, item.Snapshot);
                s.Glyphs?.SpendAnchor(glyphCaster, anchor, s);
            }

            // Fate Weaver: a card cast near a SpellCastNear glyph sets it off. Measured
            // from the caster's tile and from where the spell landed.
            if (item.Ability is CardHalf && s.Glyphs != null)
            {
                var points = new List<Vector2I>();
                if (item.CasterUnit != null && GodotObject.IsInstanceValid(item.CasterUnit)
                    && item.CasterUnit.CurrentTile != null)
                    points.Add(item.CasterUnit.CurrentTile.Axial);
                if (item.Targets?.Items != null && item.Targets.Items.Count > 0)
                {
                    var landed = InterfaceHelpers.ResolveTile(s, item.Targets.Items[0]);
                    if (landed != null)
                        points.Add(landed.Axial);
                }
                s.Glyphs.OnSpellCastAt(s, item.CasterUnit?.TeamId ?? 0, points);
            }
        }
        finally"""),
("""            if (schoolItemBonus > 0 && item.CasterUnit != null
                && GodotObject.IsInstanceValid(item.CasterUnit))
                item.CasterUnit.BonusSpellDamage -= schoolItemBonus;""",
"""            if (schoolItemBonus > 0 && item.CasterUnit != null
                && GodotObject.IsInstanceValid(item.CasterUnit))
                item.CasterUnit.BonusSpellDamage -= schoolItemBonus;
            if (glyphBonus > 0 && glyphCaster != null && GodotObject.IsInstanceValid(glyphCaster))
                glyphCaster.BonusSpellDamage -= glyphBonus;"""),
])

edit('Scripts/Systems/Combat/Core/RuntimeInterfaces.cs', [
("""        int discount = s.GetCardDiscount(s.CostContextCard);
        if (discount > 0)
            amount = Math.Max(0, amount - discount);

        return amount;""",
"""        int discount = s.GetCardDiscount(s.CostContextCard);
        if (discount > 0)
            amount = Math.Max(0, amount - discount);

        // Enchanter (slice 12a): standing on your own Sigil of Focus or Spell Anchor.
        // Priced here, with the tithe and the per-card discount, so the pips,
        // affordability and payment can never disagree.
        if (u != null && u.IsPlayerControlled)
        {
            int glyphDiscount = GlyphManager.StandingCostReduction(u);
            if (glyphDiscount > 0)
                amount = Math.Max(0, amount - glyphDiscount);
        }

        return amount;"""),
])

C = 'Scripts/Systems/Combat/Core/CombatManager.Enchanter.cs'
edit(C, [
("""    private void OnEnchanterUnitEntered(Unit unit, TileData tile, MovementKind kind)
    {
        if (kind == MovementKind.Walked && unit != null && unit.Names.Count > 0)
            Names.Break(unit, NameTrigger.Move, LogName);
    }""",
"""    private void OnEnchanterUnitEntered(Unit unit, TileData tile, MovementKind kind)
    {
        // A unit that left its ward loses the aura, however it moved.
        State?.Glyphs?.OnUnitEntered(unit, tile);
        if (kind == MovementKind.Walked && unit != null && unit.Names.Count > 0)
            Names.Break(unit, NameTrigger.Move, LogName);
    }

    // ── Strikes (slice 12a) ─────────────────────────────────────────────

    /// <summary>Enchanter adjustments to a strike before it lands: an attacker beside an
    /// opposing Sovereign Pillar deals less.</summary>
    private int EnchanterStrikeDamage(Unit attacker, int damage)
    {
        if (attacker == null || !IsInstanceValid(attacker) || State?.Glyphs == null || damage <= 0)
            return damage;
        int cut = State.Glyphs.PillarDamageReduction(attacker);
        if (cut <= 0)
            return damage;
        combatUI?.AppendActionLog($"A Sovereign Pillar blunts {attacker.Name}'s blow (-{cut}).");
        return Math.Max(0, damage - cut);
    }

    /// <summary>Mirror Ward: a strike on a unit standing on its own team's mirror glyph turns
    /// back on the attacker (with the ward's bonus). Returns true when it did, and the
    /// victim takes nothing. Spends a charge; a spent mirror is removed.</summary>
    private bool TryReflectStrike(Unit attacker, Unit victim, int damage)
    {
        if (attacker == null || victim == null || !IsInstanceValid(attacker) || !IsInstanceValid(victim)
            || damage <= 0 || victim.TeamId == attacker.TeamId)
            return false;
        var tile = victim.CurrentTile;
        var g = tile?.Glyph;
        if (g == null || g.ReflectCharges <= 0 || g.OwnerTeam != victim.TeamId)
            return false;

        int back = (int)Math.Ceiling(damage * (1f + g.ReflectBonus));
        string msg = $"The mirror under {victim.Name} turns {attacker.Name}'s blow back on it: {back} damage.";
        GD.Print(msg);
        combatUI?.AppendActionLog(msg);
        attacker.ApplyDamage(back, victim, Delivery.Bolt);
        if (g.Owner?.Attunement is WeaveAttunement w)
            w.OnGlyphTriggered();
        if (g.ReflectCharges < 99)
        {
            g.ReflectCharges--;
            if (g.ReflectCharges <= 0)
                State.Glyphs.Remove(tile);
        }
        return true;
    }

    /// <summary>An enemy cast a spell (an intent that breaks "if it casts"): Fate Weaver
    /// glyphs near it go off too. "Any spell" means theirs as well.</summary>
    private void OnEnemySpellCast(Unit enemy)
    {
        if (enemy?.CurrentTile == null || State?.Glyphs == null)
            return;
        State.Glyphs.OnSpellCastAt(State, enemy.TeamId, enemy.CurrentTile.Axial);
    }"""),
])
