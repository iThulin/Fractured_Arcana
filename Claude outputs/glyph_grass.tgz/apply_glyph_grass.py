#!/usr/bin/env python3
# Glyph grass press (2026-10-04): the blades around a sigil lie flat and ripple outward.
# Copy GlyphGrassField.cs into Scripts/Systems/Combat/Terrain/ first (cp -n). Repo root.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:200]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

edit('Assets/Shaders/painterly_grass.gdshader', [
("""uniform float wither_strength : hint_range(0.0, 1.0) = 0.80;

group_uniforms;
""",
"""uniform float wither_strength : hint_range(0.0, 1.0) = 0.80;

group_uniforms;

// ---- Glyph press (2026-10-04) ----
// Prepared glyphs press the turf around them flat and push it outward, with a
// ripple running away from the sigil, like grass under a downdraught. Sites come
// from GlyphGrassField.cs: (world x, world z, radius, strength 0..1). With no
// sites every line below is skipped.
group_uniforms glyph_press;

/** Live sites. Set by GlyphGrassField; never edit by hand. */
uniform int   glyph_site_count = 0;
/** (world x, world z, radius, strength). Size must match GlyphGrassField.MaxSites. */
uniform vec4  glyph_sites[24];

/** How far a pressed blade's tip is pushed away from the sigil (world units at full strength). */
uniform float glyph_press_bend : hint_range(0.0, 1.5) = 0.42;
/** How much a pressed blade lies down (0 = upright, 1 = flat). */
uniform float glyph_press_flatten : hint_range(0.0, 1.0) = 0.55;
/** How far past the sigil's radius the press still reaches, as a multiple of it. */
uniform float glyph_press_reach : hint_range(1.0, 2.5) = 1.35;
/** Size of the outward ripple on top of the steady press. */
uniform float glyph_ripple : hint_range(0.0, 1.0) = 0.35;
/** Ripple speed (radians per second). */
uniform float glyph_ripple_speed : hint_range(0.0, 12.0) = 4.0;
/** Ripple spacing (waves per world unit, times TAU). */
uniform float glyph_ripple_freq : hint_range(0.0, 20.0) = 7.0;
/** How much of the ambient wind a fully pressed blade ignores. */
uniform float glyph_press_calm : hint_range(0.0, 1.0) = 0.7;

group_uniforms;
"""),
("""    VERTEX.x += ndir.x * sway;
    VERTEX.z += ndir.y * sway;
    VERTEX.y -= abs(sway) * 0.15 * stiffness;
}""",
"""    // GLYPH PRESS: blades near a prepared glyph are pushed away from its centre
    // and laid down, strongest under the sigil and fading just past its rim, with a
    // ripple travelling outward. Pressed blades mostly ignore the wind.
    vec2 press = vec2(0.0);
    float pressed = 0.0;
    for (int i = 0; i < glyph_site_count; i++)
    {
        if (i >= 24)
            break;
        vec4 gs = glyph_sites[i];
        vec2 off = world_pos.xz - gs.xy;
        float d = length(off);
        float reach = gs.z * glyph_press_reach;
        if (gs.w <= 0.0 || d >= reach)
            continue;
        float fall = 1.0 - smoothstep(gs.z * 0.75, reach, d);
        float ripple = sin(TIME * glyph_ripple_speed - d * glyph_ripple_freq + float(i) * 1.7);
        float amount = gs.w * fall * (1.0 + glyph_ripple * ripple);
        vec2 away = d > 0.001 ? off / d : vec2(1.0, 0.0);
        press += away * amount;
        pressed = max(pressed, gs.w * fall);
    }
    if (pressed > 0.0)
    {
        sway *= 1.0 - pressed * glyph_press_calm;
        VERTEX.x += press.x * glyph_press_bend * stiffness;
        VERTEX.z += press.y * glyph_press_bend * stiffness;
        VERTEX.y *= 1.0 - clamp(pressed * glyph_press_flatten, 0.0, 0.95);
    }

    VERTEX.x += ndir.x * sway;
    VERTEX.z += ndir.y * sway;
    VERTEX.y -= abs(sway) * 0.15 * stiffness;
}"""),
])

edit('Scripts/Systems/Combat/Terrain/HexGridManager.PainterlyGrass.cs', [
("""            ImbuementField.Attach(PainterlyGrassMaterial as ShaderMaterial, this);
            return PainterlyGrassMaterial;""",
"""            ImbuementField.Attach(PainterlyGrassMaterial as ShaderMaterial, this);
            GlyphGrassField.Attach(PainterlyGrassMaterial as ShaderMaterial);
            return PainterlyGrassMaterial;"""),
("""        ImbuementField.Attach(sm, this);
        _painterlyGrassMaterialCache = sm;""",
"""        ImbuementField.Attach(sm, this);
        GlyphGrassField.Attach(sm);
        _painterlyGrassMaterialCache = sm;"""),
])

edit('Scripts/Systems/Combat/Terrain/HexTile.cs', [
("""                mat.SetShaderParameter("mask_tex", tex);
                decal.Visible = true;""",
"""                mat.SetShaderParameter("mask_tex", tex);
                decal.Visible = true;

                // The turf around the sigil yields as the circle is drawn.
                ulong siteId = GetInstanceId();
                GlyphGrassField.Set(siteId, GlobalPosition, GlyphGrassRadius, 0f);
                CreateTween()
                    .TweenMethod(Callable.From<float>(v => GlyphGrassField.SetStrength(siteId, v)),
                                 0f, 1f, GlyphInscribeSeconds * 0.4f)
                    .SetTrans(Tween.TransitionType.Sine)
                    .SetEase(Tween.EaseType.Out);"""),
("""    private const float GlyphFlashSeconds = 0.5f;""",
"""    private const float GlyphFlashSeconds = 0.5f;

    /// <summary>World radius of the grass pressed around a glyph: a little past the sigil's
    /// own radius (half of GlyphDecalSize), so the circle sits in a clearing.</summary>
    private const float GlyphGrassRadius = 0.95f;"""),
("""    public void ClearGlyph()
    {""",
"""    public override void _ExitTree()
    {
        GlyphGrassField.Remove(GetInstanceId());
    }

    public void ClearGlyph()
    {
        GlyphGrassField.Remove(GetInstanceId());"""),
])
