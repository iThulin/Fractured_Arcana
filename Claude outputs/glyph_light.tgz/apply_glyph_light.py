#!/usr/bin/env python3
# Glyph light-circle renderer (2026-10-04). Run from the repo root.
import sys
def edit(rel, pairs):
    s = open(rel, encoding='utf-8').read()
    for old, new in pairs:
        n = s.count(old)
        if n != 1:
            sys.exit(f"{rel}: expected 1 match, found {n}:\n{old[:120]}")
        s = s.replace(old, new)
    open(rel, 'w', encoding='utf-8').write(s)
    print("patched", rel)

# ── GlyphCipherView: LightMask bake mode ──────────────────────────────
edit('Scripts/UI/GlyphCipherView.cs', [
("""    /// <summary>Builds and assigns the glyph for a spell half. Returns false if the half could not be encoded.</summary>""",
"""    /// <summary>
    /// Coverage-mask mode for the tile decal (glyph_sigil.gdshader v2). Strokes are drawn as
    /// pure channels with ADDITIVE canvas blending, so crossings and joints saturate to a
    /// clean union instead of stacking alpha into blotches: R = stave, G = function strokes,
    /// spoke tips, markers and the hub outline, B = hub fill. The rim, backing and pips are
    /// skipped because the shader draws its own rings. Never used for card art.
    /// </summary>
    public bool LightMask
    {
        get => _lightMask;
        set
        {
            if (_lightMask == value) return;
            _lightMask = value;
            Material = value ? new CanvasItemMaterial { BlendMode = CanvasItemMaterial.BlendModeEnum.Add } : null;
            QueueRedraw();
        }
    }
    private bool _lightMask;

    private static readonly Color MaskStave = new Color(1f, 0f, 0f, 1f);
    private static readonly Color MaskFunction = new Color(0f, 1f, 0f, 1f);
    private static readonly Color MaskHubFill = new Color(0f, 0f, 1f, 1f);

    /// <summary>Builds and assigns the glyph for a spell half. Returns false if the half could not be encoded.</summary>"""),
("""        int reveal = Mathf.RoundToInt(_glyph.OrderedCount * _progress);
""",
"""        int reveal = Mathf.RoundToInt(_glyph.OrderedCount * _progress);

        if (_lightMask)
        {
            inkA = MaskStave;
            fn = MaskFunction;
        }
"""),
("""        if (p.BackingAlpha > 0.001f)""",
"""        if (p.BackingAlpha > 0.001f && !_lightMask)"""),
("""        if (p.Pips) DrawPips(ToScreen, radius, fn);""",
"""        if (p.Pips && !_lightMask) DrawPips(ToScreen, radius, fn);"""),
("""            if (s.Layer != CipherLayer.Rim) continue;""",
"""            if (s.Layer != CipherLayer.Rim || _lightMask) continue;"""),
("""            case CipherMark.Hub:
                DrawHub(at, size, col);
                break;""",
"""            case CipherMark.Hub:
                if (_lightMask) DrawHubMask(at, size, lineW);
                else DrawHub(at, size, col);
                break;"""),
("""    /// <summary>
    /// Filled polygon with a softened edge.""",
"""    /// <summary>
    /// The hub for the light mask: the filled shape in B (the shader lights it as a dim
    /// plate) and its outline in G (lit hot, like every other function stroke). The Ally
    /// punch cannot be drawn by subtraction under additive blending, so the Ally fill is
    /// an annulus instead, outlined inside and out.
    /// </summary>
    private void DrawHubMask(Vector2 at, float size, float lineW)
    {
        float edge = Mathf.Max(1.5f, lineW * 0.75f);
        switch (_glyph.Target)
        {
            case CipherTarget.Self:
                DrawCircle(at, size, MaskHubFill, true, -1f, true);
                DrawArc(at, size, 0f, Mathf.Tau, 40, MaskFunction, edge, true);
                break;

            case CipherTarget.Ally:
                DrawArc(at, size * 0.73f, 0f, Mathf.Tau, 40, MaskHubFill, size * 0.54f, true);
                DrawArc(at, size, 0f, Mathf.Tau, 40, MaskFunction, edge, true);
                DrawArc(at, size * 0.46f, 0f, Mathf.Tau, 32, MaskFunction, edge, true);
                break;

            case CipherTarget.Tile:
            {
                var pts = new[]
                {
                    at + new Vector2(0, -size), at + new Vector2(size, 0),
                    at + new Vector2(0, size),  at + new Vector2(-size, 0)
                };
                DrawColoredPolygon(pts, MaskHubFill);
                DrawClosedOutline(pts, MaskFunction, edge);
                break;
            }

            default: // Enemy
            {
                var pts = new[]
                {
                    at + new Vector2(0, -size * 1.05f),
                    at + new Vector2(size * 0.91f, size * 0.58f),
                    at + new Vector2(-size * 0.91f, size * 0.58f)
                };
                DrawColoredPolygon(pts, MaskHubFill);
                DrawClosedOutline(pts, MaskFunction, edge);
                break;
            }
        }
    }

    // A closed outline with round joins. Under additive blending a mitred polyline
    // double-covers each corner, so the corners are stroked as separate segments and
    // capped with discs; the overlap saturates in the mask instead of blotching.
    private void DrawClosedOutline(Vector2[] pts, Color col, float width)
    {
        for (int i = 0; i < pts.Length; i++)
        {
            var a = pts[i];
            var b = pts[(i + 1) % pts.Length];
            DrawLine(a, b, col, width, true);
            DrawCircle(a, width * 0.5f, col, true, -1f, true);
        }
    }

    /// <summary>
    /// Filled polygon with a softened edge."""),
])

# ── GlyphCipherTexture: mask bakes ────────────────────────────────────
edit('Scripts/Systems/Combat/Glyphs/GlyphCipherTexture.cs', [
("""    public async Task<ImageTexture> BakeGlyphAsync(string key, CipherGlyph glyph,
                                                   int px, CipherLod lod, bool dark)
    {""",
"""    public async Task<ImageTexture> BakeGlyphAsync(string key, CipherGlyph glyph,
                                                   int px, CipherLod lod, bool dark,
                                                   bool lightMask = false)
    {"""),
("""                Progress = 1f,
                Position = Vector2.Zero,
                Size = new Vector2(px, px),
            };
            vp.AddChild(view);""",
"""                Progress = 1f,
                Position = Vector2.Zero,
                Size = new Vector2(px, px),
                LightMask = lightMask,
            };
            vp.AddChild(view);"""),
("""    /// <summary>Drops every cached texture.""",
"""    /// <summary>
    /// Requests the COVERAGE MASK bake of a blueprint half for the tile decal
    /// (glyph_sigil.gdshader v2). Channels, not colours: R = stave, G = function strokes
    /// and hub outline, B = hub fill. Cached under its own key, so card art and the
    /// element runes never see it. Bake at <see cref="CipherLod.Card"/> weights: the light
    /// renderer wants thin cores and adds its own bloom, and the shader's mask_gain and
    /// mip bias carry the distance robustness the Tile LOD used to buy with thickness.
    /// </summary>
    public void RequestMaskForBlueprint(string blueprintId, string half, int px,
                                        Action<ImageTexture> onReady)
    {
        if (onReady == null) return;
        var bp = CardDatabase.GetByName(blueprintId);
        var data = half == "bottom" ? bp?.Prebuilt?.BottomHalf : bp?.Prebuilt?.TopHalf;
        if (data == null) { onReady(null); return; }

        px = Mathf.Clamp(px, 32, 1024);
        string key = KeyOf(blueprintId, half, px, CipherLod.Card, true) + "#mask";

        if (_cache.TryGetValue(key, out var hit)) { onReady(hit); return; }
        if (_pending.TryGetValue(key, out var waiters)) { waiters.Add(onReady); return; }

        _pending[key] = new List<Action<ImageTexture>> { onReady };
        _ = BakeGlyphAsync(key, GlyphCipherTags.BuildFor(blueprintId, half, data), px,
                           CipherLod.Card, true, lightMask: true);
    }

    /// <summary>Drops every cached texture."""),
])

# ── HexTile: wire the light circle ────────────────────────────────────
edit('Scripts/Systems/Combat/Terrain/HexTile.cs', [
("""    private const int GlyphDecalPixels = 256;""",
"""    private const int GlyphDecalPixels = 512;"""),
("""    private const float GlyphDecalSize = 1.50f;""",
"""    private const float GlyphDecalSize = 1.68f;"""),
("""    private const float GlyphInscribeSeconds = 0.95f;""",
"""    private const float GlyphInscribeSeconds = 1.35f;

    /// <summary>Seconds for the bright burst that fades out once the circle is sealed.</summary>
    private const float GlyphFlashSeconds = 0.7f;"""),
("""        GlyphCipherTexture.Instance.RequestForBlueprint(
            glyph.SourceCardId, glyph.SourceHalf, GlyphDecalPixels, CipherLod.Tile, true,
            tex =>
            {
                if (tex == null || !IsInstanceValid(decal) || mat == null)
                    return;                       // bake failed; keep the ✦
                mat.SetShaderParameter("sigil_tex", tex);""",
"""        GlyphCipherTexture.Instance.RequestMaskForBlueprint(
            glyph.SourceCardId, glyph.SourceHalf, GlyphDecalPixels,
            tex =>
            {
                if (tex == null || !IsInstanceValid(decal) || mat == null)
                    return;                       // bake failed; keep the ✦
                mat.SetShaderParameter("mask_tex", tex);"""),
("""                mat.SetShaderParameter("progress", 0f);
                CreateTween()
                    .TweenProperty(mat, "shader_parameter/progress", 1.0f, GlyphInscribeSeconds)
                    .SetTrans(Tween.TransitionType.Linear);""",
"""                // The rings, runes and hexagram come first in the shader's own schedule,
                // then the cipher, then a flash as the circle seals.
                mat.SetShaderParameter("progress", 0f);
                mat.SetShaderParameter("flash", 0f);
                var tw = CreateTween();
                tw.TweenProperty(mat, "shader_parameter/progress", 1.0f, GlyphInscribeSeconds)
                  .SetTrans(Tween.TransitionType.Linear);
                tw.TweenProperty(mat, "shader_parameter/flash", 0.0f, GlyphFlashSeconds)
                  .From(1.0f)
                  .SetTrans(Tween.TransitionType.Expo)
                  .SetEase(Tween.EaseType.Out);"""),
("""        _glyphDecalMaterial.SetShaderParameter("glow_color", UITheme.CipherFunction);
        _glyphDecalMaterial.SetShaderParameter("ring_color", UITheme.CipherFunction);
        _glyphDecalMaterial.SetShaderParameter("backing_color", UITheme.CipherTileBacking);
        _glyphDecalMaterial.SetShaderParameter("progress", 0f);""",
"""        // The circle's violet light lives in the shader default; the function layer keeps
        // the Enchanter rose so the spokes and hub match the card art.
        _glyphDecalMaterial.SetShaderParameter("accent_color", UITheme.CipherFunction);
        _glyphDecalMaterial.SetShaderParameter("progress", 0f);"""),
])
